-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: my_xhs_inventory
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '3dc456aa-7b9f-11f1-822d-525400d7fee1:1-274';

--
-- Current Database: `my_xhs_inventory`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `my_xhs_inventory` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `my_xhs_inventory`;

--
-- Table structure for table `t_inventory`
--

DROP TABLE IF EXISTS `t_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory` (
  `id` bigint NOT NULL COMMENT 'ID',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `available_stock` int NOT NULL DEFAULT '0' COMMENT 'å¯ç”¨åº“å­˜',
  `locked_stock` int NOT NULL DEFAULT '0' COMMENT 'é”å®šåº“å­˜',
  `freezing_stock` int NOT NULL DEFAULT '0' COMMENT 'TCCå†»ç»“åº“å­˜',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sku_id` (`sku_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='åº“å­˜è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory`
--

LOCK TABLES `t_inventory` WRITE;
/*!40000 ALTER TABLE `t_inventory` DISABLE KEYS */;
INSERT INTO `t_inventory` VALUES (1,1,1000,0,0,0,'2026-07-10 14:55:53','2026-07-31 15:25:07'),(2,2,150,0,0,0,'2026-07-10 14:55:53','2026-07-10 14:55:53'),(3,3,120,0,0,0,'2026-07-10 14:55:53','2026-07-10 14:55:53'),(4,4,200,0,0,0,'2026-07-10 14:55:53','2026-07-10 14:55:53'),(5,5,180,0,0,0,'2026-07-10 14:55:53','2026-07-10 14:55:53'),(6,6,80,0,0,0,'2026-07-10 14:55:53','2026-07-10 14:55:53'),(7,7,300,0,0,0,'2026-07-10 14:55:53','2026-07-10 14:55:53'),(8,8,200,0,0,0,'2026-07-10 14:55:53','2026-07-10 14:55:53'),(9,9,30,0,0,0,'2026-07-10 14:55:53','2026-07-10 14:55:53'),(10,10,500,0,0,0,'2026-07-10 14:55:53','2026-07-10 14:55:53'),(2081703433129209858,999,675,105,0,0,'2026-07-27 19:29:09','2026-07-31 16:08:35'),(2084116841178959874,27250,1000,0,0,0,'2026-08-03 11:19:10','2026-08-03 11:19:10'),(2084116917020364801,27268,998,0,0,0,'2026-08-03 11:19:28','2026-08-03 11:19:28'),(2084453710731177986,9999,100,0,0,0,'2026-08-04 09:37:46','2026-08-04 09:37:46'),(2084454600686989313,7777,90,0,0,0,'2026-08-04 09:41:18','2026-08-04 09:41:18'),(2084456534189830146,8888,200,30,0,0,'2026-08-04 09:48:59','2026-08-04 09:48:59'),(2084456543153057793,99999,1,0,0,0,'2026-08-04 09:49:01','2026-08-04 09:49:01'),(2084456610073178113,70001,1,0,0,0,'2026-08-04 09:49:17','2026-08-04 09:49:17'),(2084481448628219906,14179,998,0,0,0,'2026-08-04 11:27:59','2026-08-04 11:28:00'),(2084534106416246785,2084534106126888961,499,1,0,0,'2026-08-04 14:57:14','2026-08-04 14:57:14'),(2084534106592407554,2084534106550513665,499,1,0,0,'2026-08-04 14:57:14','2026-08-04 14:57:14'),(2084534106839871490,2084534106726674433,499,1,0,0,'2026-08-04 14:57:14','2026-08-04 14:57:14'),(2084534106986672129,2084534106932195329,500,0,0,0,'2026-08-04 14:57:14','2026-08-04 14:57:14'),(2084534107171221506,2084534107070607362,500,0,0,0,'2026-08-04 14:57:14','2026-08-04 14:57:14'),(2084909770038358017,99999001,70,20,0,0,'2026-08-05 15:49:59','2026-08-05 15:56:47'),(2084911509332328449,99999009,85,10,0,0,'2026-08-05 15:56:54','2026-08-05 15:56:54'),(2085531002052046849,2085530413171785729,983,17,0,0,'2026-08-07 08:58:32','2026-08-07 16:39:19'),(2086000824007274498,2085989641275572226,100,0,0,0,'2026-08-08 16:05:27','2026-08-08 16:35:43');
/*!40000 ALTER TABLE `t_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_compensation`
--

DROP TABLE IF EXISTS `t_inventory_compensation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_compensation` (
  `id` bigint NOT NULL,
  `order_id` bigint NOT NULL,
  `sku_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `action` varchar(32) NOT NULL,
  `status` tinyint DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_compensation`
--

LOCK TABLES `t_inventory_compensation` WRITE;
/*!40000 ALTER TABLE `t_inventory_compensation` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_inventory_compensation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_inventory_outbox`
--

DROP TABLE IF EXISTS `t_inventory_outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_inventory_outbox` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint NOT NULL,
  `sku_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `action` varchar(32) NOT NULL,
  `status` tinyint DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_inventory_outbox`
--

LOCK TABLES `t_inventory_outbox` WRITE;
/*!40000 ALTER TABLE `t_inventory_outbox` DISABLE KEYS */;
INSERT INTO `t_inventory_outbox` VALUES (1,-642450233827882436,2085530413171785729,2,'PRE_DEDUCT',1,'2026-08-07 11:15:31'),(2,5106696622302654743,2085530413171785729,3,'PRE_DEDUCT',1,'2026-08-07 11:16:27'),(3,7977977178882788816,2085530413171785729,3,'PRE_DEDUCT',1,'2026-08-07 11:17:32'),(4,-6497806433803434735,2085530413171785729,2,'PRE_DEDUCT',1,'2026-08-07 12:47:06'),(5,-3709071859810462465,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 12:54:29'),(6,-3539953428162325532,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 13:17:53'),(7,8494058180107556352,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 15:39:12'),(8,8512175291524878075,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 15:39:12'),(9,-7520894822245980509,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 15:39:44'),(10,-9046731851053824090,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 15:43:01'),(11,-2933838997991446723,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 16:04:25'),(12,-4941808358113384720,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 16:07:09'),(13,-907388582076929796,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 16:11:38'),(14,-1214947300513146626,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 16:21:22'),(15,-5998074335427214061,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 16:23:48'),(16,-8748399756399745932,2085530413171785729,1,'PRE_DEDUCT',1,'2026-08-07 16:39:19'),(17,-7909473587627075306,2085989641275572226,2,'PRE_DEDUCT',1,'2026-08-08 16:05:53');
/*!40000 ALTER TABLE `t_inventory_outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_tcc_fence`
--

DROP TABLE IF EXISTS `t_tcc_fence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_tcc_fence` (
  `xid` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'å…¨å±€äº‹åŠ¡ID',
  `branch_id` bigint NOT NULL COMMENT 'åˆ†æ”¯äº‹åŠ¡ID',
  `action_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'TCCæ–¹æ³•å',
  `status` tinyint NOT NULL COMMENT '1-å·²Try 2-å·²Confirm 3-å·²Cancel',
  `gmt_create` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `gmt_modified` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`xid`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='TCCé˜²æ‚¬æŒ‚è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_tcc_fence`
--

LOCK TABLES `t_tcc_fence` WRITE;
/*!40000 ALTER TABLE `t_tcc_fence` DISABLE KEYS */;
INSERT INTO `t_tcc_fence` VALUES ('tcc-confirm-1783835466',1,'tryDeductStock',2,'2026-07-12 13:51:06.297','2026-07-12 13:51:06.317'),('tcc-test-1783834041',1,'tryDeductStock',3,'2026-07-12 13:27:21.009','2026-07-12 13:27:21.033'),('test:1785727150587',1,'tryDeductStock',2,'2026-08-03 11:19:10.737','2026-08-03 11:19:10.768'),('test:1785727151587',2,'tryDeductStock',3,'2026-08-03 11:19:10.785','2026-08-03 11:19:10.823'),('test:1785727168681',1,'tryDeductStock',2,'2026-08-03 11:19:28.834','2026-08-03 11:19:28.847'),('test:1785727169681',2,'tryDeductStock',3,'2026-08-03 11:19:28.863','2026-08-03 11:19:28.879'),('test:1785814079671',1,'tryDeductStock',2,'2026-08-04 11:28:00.009','2026-08-04 11:28:00.048'),('test:1785814080671',2,'tryDeductStock',3,'2026-08-04 11:28:00.064','2026-08-04 11:28:00.120'),('test:tx:001',1001,'tryDeductStock',2,'2026-07-28 09:33:22.092','2026-07-28 09:33:33.283'),('test:tx:002',2001,'tryDeductStock',3,'2026-07-28 09:33:39.967','2026-07-28 09:33:39.997'),('test:tx:003',3001,'tryDeductStock',2,'2026-07-28 10:30:05.778','2026-07-28 10:30:13.870'),('test:tx:004',4001,'tryDeductStock',3,'2026-07-28 10:30:21.051','2026-07-28 10:30:21.086');
/*!40000 ALTER TABLE `t_tcc_fence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_tcc_freeze_detail`
--

DROP TABLE IF EXISTS `t_tcc_freeze_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_tcc_freeze_detail` (
  `id` bigint NOT NULL,
  `xid` varchar(128) NOT NULL,
  `branch_id` bigint NOT NULL,
  `sku_id` bigint NOT NULL,
  `quantity` int NOT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_xid` (`xid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_tcc_freeze_detail`
--

LOCK TABLES `t_tcc_freeze_detail` WRITE;
/*!40000 ALTER TABLE `t_tcc_freeze_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_tcc_freeze_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'my_xhs_inventory'
--

--
-- Dumping routines for database 'my_xhs_inventory'
--
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-08 21:52:06
