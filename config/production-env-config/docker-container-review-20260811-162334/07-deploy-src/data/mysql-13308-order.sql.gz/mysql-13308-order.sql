-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: my_xhs_order
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '3dc78fe8-7b9f-11f1-a092-525400d7fee1:1-955';

--
-- Current Database: `my_xhs_order`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `my_xhs_order` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `my_xhs_order`;

--
-- Table structure for table `t_order_no_mapping`
--

DROP TABLE IF EXISTS `t_order_no_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_no_mapping` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'è‡ªå¢žID',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å·æ˜ å°„è¡¨ï¼ˆéžåˆ†ç‰‡é”®æŸ¥è¯¢è·¯ç”±ï¼‰';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_no_mapping`
--

LOCK TABLES `t_order_no_mapping` WRITE;
/*!40000 ALTER TABLE `t_order_no_mapping` DISABLE KEYS */;
INSERT INTO `t_order_no_mapping` VALUES (1,'ORD2026071211442511000010002',10001,2076150660723761154,'2026-07-12 11:44:25'),(2,'ORD2026071211480262300010003',10001,2076151572980613121,'2026-07-12 11:48:03'),(3,'ORD2026071212591630100010006',10001,2076169498030809089,'2026-07-12 12:59:16'),(4,'ORD2026071212593896300010007',10001,2076169592889188354,'2026-07-12 12:59:38'),(5,'ORD2026071212595117700010008',10001,2076169644114223106,'2026-07-12 12:59:51'),(6,'ORD2026071213163092600010009',10001,2076173837361258497,'2026-07-12 13:16:30'),(7,'ORD2026071213204089200010010',10001,2076174885794652161,'2026-07-12 13:20:40'),(8,'ORD2026071213213487700010011',10001,2076175112224153601,'2026-07-12 13:21:34'),(9,'ORD2026071213232808800010012',10001,2076175587065503746,'2026-07-12 13:23:28'),(10,'ORD2026071213300338400010013',10001,2076177245061292033,'2026-07-12 13:30:03'),(11,'ORD2026071213300341800010014',10001,2076177245199704065,'2026-07-12 13:30:03'),(12,'ORD2026071213300345000010015',10001,2076177245329727490,'2026-07-12 13:30:03'),(13,'ORD2026071213300348000010016',10001,2076177245459750914,'2026-07-12 13:30:03'),(14,'ORD2026071213300351000010017',10001,2076177245581385730,'2026-07-12 13:30:03'),(15,'ORD2026072911210714700010001',20001,2082305390969671681,'2026-07-29 11:21:07'),(16,'ORD2026072911273560200010002',20001,2082307019940876290,'2026-07-29 11:27:35'),(17,'ORD2026072911282362400020003',20002,2082307221355548674,'2026-07-29 11:28:23'),(18,'ORD2026072912530375500030004',20003,2082328528973516802,'2026-07-29 12:53:03'),(19,'ORD2026072912552415000050005',20005,2082329118126428162,'2026-07-29 12:55:25'),(20,'ORD2026072912573675600010006',30001,2082329674207264770,'2026-07-29 12:57:36'),(21,'ORD2026072912580099500010007',40001,2082329775684255745,'2026-07-29 12:58:01'),(22,'ORD2026072914184889400010008',50001,2082350109250617345,'2026-07-29 14:18:48'),(23,'ORD2026072914190155500020009',50002,2082350162350505986,'2026-07-29 14:19:01'),(24,'ORD2026072914205371000010010',60001,2082350632766865409,'2026-07-29 14:20:53'),(25,'ORD2026072914221996400010011',70001,2082350994844397570,'2026-07-29 14:22:21'),(26,'ORD2026072914250161400010012',80001,2082351672551649282,'2026-07-29 14:25:01'),(27,'ORD2026072914251972500010013',80001,2082351748510494721,'2026-07-29 14:25:19'),(28,'ORD2026072914254664200010014',80001,2082351861412769794,'2026-07-29 14:25:46'),(29,'ORD2026072914341083800010015',90001,2082353976164069378,'2026-07-29 14:34:10'),(30,'ORD2026072914342523200010016',90001,2082354036532686850,'2026-07-29 14:34:25'),(31,'ORD2026072914342534300020017',90002,2082354037010837506,'2026-07-29 14:34:25'),(32,'ORD2026072914342545100030018',90003,2082354037455433729,'2026-07-29 14:34:25'),(33,'ORD2026072914342555300040019',90004,2082354037879058433,'2026-07-29 14:34:25'),(34,'ORD2026072914342564100050020',90005,2082354038248157185,'2026-07-29 14:34:25'),(35,'ORD2026072914351123410010021',91001,2082354229479059458,'2026-07-29 14:35:11'),(36,'ORD2026072914351133610020022',91002,2082354229911072770,'2026-07-29 14:35:11'),(37,'ORD2026072914351142610030023',91003,2082354230284365825,'2026-07-29 14:35:11'),(38,'ORD2026072914351152810040024',91004,2082354230712184833,'2026-07-29 14:35:11'),(39,'ORD2026072914351162210050025',91005,2082354231110643714,'2026-07-29 14:35:11'),(40,'ORD2026072914351172410060026',91006,2082354231538462721,'2026-07-29 14:35:11'),(41,'ORD2026072914351181810070027',91007,2082354231928532994,'2026-07-29 14:35:11'),(42,'ORD2026072914351190410080028',91008,2082354232293437442,'2026-07-29 14:35:11'),(43,'ORD2026072914351199610090029',91009,2082354232675119105,'2026-07-29 14:35:12'),(44,'ORD2026072914351208400100030',910010,2082354233048412161,'2026-07-29 14:35:12'),(45,'ORD2026072914362735320010031',92001,2082354549059801089,'2026-07-29 14:36:28'),(46,'ORD2026072914362900620020032',92002,2082354555686801409,'2026-07-29 14:36:29'),(47,'ORD2026072914362915020030033',92003,2082354556286586881,'2026-07-29 14:36:29'),(48,'ORD2026072914362927720040034',92004,2082354556827652097,'2026-07-29 14:36:29'),(49,'ORD2026072914362940120050035',92005,2082354557347745793,'2026-07-29 14:36:29'),(50,'ORD2026072914372700740010036',94001,2082354799459733506,'2026-07-29 14:37:28'),(51,'ORD2026072914373084340020037',94002,2082354815049961473,'2026-07-29 14:37:30'),(52,'ORD2026072914373300140030038',94003,2082354824101269505,'2026-07-29 14:37:33'),(53,'ORD2026072914373312440040039',94004,2082354824617168897,'2026-07-29 14:37:33'),(54,'ORD2026072914373324540050040',94005,2082354825120485377,'2026-07-29 14:37:33'),(55,'ORD2026072914373335540060041',94006,2082354825581858818,'2026-07-29 14:37:33'),(56,'ORD2026072914373345940070042',94007,2082354826018066433,'2026-07-29 14:37:33'),(57,'ORD2026072914373560340080043',94008,2082354835010654210,'2026-07-29 14:37:35'),(58,'ORD2026072914393006000010044',10001,2082355315078107137,'2026-07-29 14:39:30'),(59,'ORD2026072914400750800020045',10002,2082355472142209026,'2026-07-29 14:40:07'),(60,'ORD2026072914402316600030046',10003,2082355537820815361,'2026-07-29 14:40:23'),(61,'ORD2026072914403569600010047',20001,2082355590371250177,'2026-07-29 14:40:35'),(62,'ORD2026072914405153100010048',30001,2082355656792248321,'2026-07-29 14:40:51'),(63,'ORD2026072915284066400010049',10001,2082367690804072449,'2026-07-29 15:28:40'),(64,'ORD2026080314554185467530001',2084171328232906753,2084171330690785282,'2026-08-03 14:55:42'),(65,'ORD2026080314554244067530002',2084171328232906753,2084171332859240449,'2026-08-03 14:55:42'),(66,'ORD2026080314554260167530003',2084171328232906753,2084171333538717698,'2026-08-03 14:55:42'),(67,'ORD2026080314554268067530004',2084171328232906753,2084171333874262017,'2026-08-03 14:55:42'),(68,'ORD2026080314554276167530005',2084171328232906753,2084171334209806338,'2026-08-03 14:55:42'),(69,'ORD2026080314560857914890006',2084171442041151489,2084171442498347010,'2026-08-03 14:56:08'),(70,'ORD2026080314560875714890007',2084171442041151489,2084171443244933121,'2026-08-03 14:56:08'),(71,'ORD2026080314560882814890008',2084171442041151489,2084171443542728705,'2026-08-03 14:56:08'),(72,'ORD2026080314560888314890009',2084171442041151489,2084171443773415425,'2026-08-03 14:56:08'),(73,'ORD2026080314560895014890010',2084171442041151489,2084171444050239489,'2026-08-03 14:56:08'),(74,'ORD2026080315083188359540011',2084174559629565954,2084174560141287426,'2026-08-03 15:08:31'),(75,'ORD2026080315093876005140012',2084174840186560514,2084174840643756033,'2026-08-03 15:09:38'),(76,'ORD2026080317391230939530013',2084212477404413953,2084212478574653441,'2026-08-03 17:39:12'),(77,'ORD2026080317391272639530014',2084212477404413953,2084212480189460482,'2026-08-03 17:39:12'),(78,'ORD2026080410151950355550001',55555,2084463160384868354,'2026-08-04 10:15:19'),(79,'ORD2026080411280119071220002',2084481453887877122,2084481454475104257,'2026-08-04 11:28:01'),(80,'ORD2026080411280143971220003',2084481453887877122,2084481455502708738,'2026-08-04 11:28:01'),(81,'ORD2026080411282193542410004',2084481541045514241,2084481541477552129,'2026-08-04 11:28:21'),(82,'ORD2026080411282211142410005',2084481541045514241,2084481542207361026,'2026-08-04 11:28:22'),(83,'ORD2026080411311933652340006',2084482285106655234,2084482285542887425,'2026-08-04 11:31:19'),(84,'ORD2026080411312806348500007',2084482321718734850,2084482322142384130,'2026-08-04 11:31:28'),(85,'ORD2026080411312823548500008',2084482321718734850,2084482322867998721,'2026-08-04 11:31:28'),(86,'ORD2026080411315416149460009',2084482431185874946,2084482431609524225,'2026-08-04 11:31:54'),(87,'ORD2026080411315431949460010',2084482431185874946,2084482432268029953,'2026-08-04 11:31:54'),(88,'ORD2026080411330372499990011',99999,2084482723373699074,'2026-08-04 11:33:03'),(89,'ORD2026080411334002722100012',2084482875220062210,2084482875643711489,'2026-08-04 11:33:40'),(90,'ORD2026080411334005422100013',2084482875220062210,2084482875756957697,'2026-08-04 11:33:40'),(91,'ORD2026080411334810313130014',2084482909093261313,2084482909516910593,'2026-08-04 11:33:48'),(92,'ORD2026080411334827013130015',2084482909093261313,2084482910217359362,'2026-08-04 11:33:48'),(93,'ORD2026080411351639242580016',2084483279391584258,2084483279827816449,'2026-08-04 11:35:16'),(94,'ORD2026080411351654242580017',2084483279391584258,2084483280456962050,'2026-08-04 11:35:16'),(95,'ORD2026080411362890860330018',2084483583558316033,2084483583981965313,'2026-08-04 11:36:28'),(96,'ORD2026080411362906560330019',2084483583558316033,2084483584636276737,'2026-08-04 11:36:29'),(97,'ORD2026080411374962290900020',2084483922097369090,2084483922516824065,'2026-08-04 11:37:49'),(98,'ORD2026080414571470310010021',1001,2084534107729088513,'2026-08-04 14:57:14'),(99,'ORD2026080414571474810010022',1001,2084534107892666369,'2026-08-04 14:57:14'),(100,'ORD2026080414571477610010023',1001,2084534108052049921,'2026-08-04 14:57:14'),(101,'ORD2026080709020763800010001',10001,2085531903223463938,'2026-08-07 09:02:07'),(102,'ORD2026080709130122500010002',10001,2085534644842811393,'2026-08-07 09:13:02'),(103,'ORD2026080709162895200010003',10001,2085535516037488642,'2026-08-07 09:16:30'),(104,'ORD2026080709233742200010004',10001,2085537313141624834,'2026-08-07 09:23:38'),(105,'ORD2026080709302068800010005',10001,2085539004578545666,'2026-08-07 09:30:22'),(106,'ORD2026080711030903300010006',10001,2085562359503405057,'2026-08-07 11:03:09'),(107,'ORD2026080711034518800010007',10001,2085562511144271874,'2026-08-07 11:03:45'),(108,'ORD2026080711094719400010008',10001,2085564029503291393,'2026-08-07 11:09:47'),(109,'ORD2026080711105185000010009',10001,2085564300690210818,'2026-08-07 11:10:51'),(110,'ORD2026080711153119800010010',10001,2085565472364838913,'2026-08-07 11:15:31'),(111,'ORD2026080712470616100010011',10001,2085588519922712577,'2026-08-07 12:47:06'),(112,'ORD2026080712542826900010012',10001,2085590374643924993,'2026-08-07 12:54:29'),(113,'ORD2026080713093602200010013',10001,2085594181637505025,'2026-08-07 13:09:36'),(114,'ORD2026080713175213900010014',10001,2085596262905774082,'2026-08-07 13:17:53'),(115,'ORD2026080715391193100010015',10001,2085631829332819969,'2026-08-07 15:39:11'),(116,'ORD2026080715391206800010016',10001,2085631829903245313,'2026-08-07 15:39:12'),(117,'ORD2026080715394401900010017',10001,2085631963915452418,'2026-08-07 15:39:44'),(118,'ORD2026080715430162000010018',10001,2085632792714117122,'2026-08-07 15:43:01'),(119,'ORD2026080716042422100010019',10001,2085638172626165762,'2026-08-07 16:04:25'),(120,'ORD2026080716070824900010020',10001,2085638860609470466,'2026-08-07 16:07:09'),(121,'ORD2026080716113731500010021',10001,2085639989166637057,'2026-08-07 16:11:38'),(122,'ORD2026080716212199200010022',10001,2085642441198702594,'2026-08-07 16:21:22'),(123,'ORD2026080716234728200010023',10001,2085643051075674114,'2026-08-07 16:23:48'),(124,'ORD2026080716391961100010024',10001,2085646961035223041,'2026-08-07 16:39:19'),(125,'ORD2026080816055339313780001',2085982901507301378,2086000934497923073,'2026-08-08 16:05:53');
/*!40000 ALTER TABLE `t_order_no_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'my_xhs_order'
--

--
-- Dumping routines for database 'my_xhs_order'
--

--
-- Current Database: `my_xhs_order_0`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `my_xhs_order_0` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `my_xhs_order_0`;

--
-- Table structure for table `t_local_message_0`
--

DROP TABLE IF EXISTS `t_local_message_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_0` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_0`
--

LOCK TABLES `t_local_message_0` WRITE;
/*!40000 ALTER TABLE `t_local_message_0` DISABLE KEYS */;
INSERT INTO `t_local_message_0` VALUES (2082354232318603266,91008,'ORD2026072914351190410080028','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351190410080028\",\"couponId\":0,\"timestamp\":1785306911905,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":91008}',0,0,'2026-07-29 14:35:11','2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_local_message_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_1`
--

DROP TABLE IF EXISTS `t_local_message_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_1` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_1`
--

LOCK TABLES `t_local_message_1` WRITE;
/*!40000 ALTER TABLE `t_local_message_1` DISABLE KEYS */;
INSERT INTO `t_local_message_1` VALUES (2082354037904224258,90004,'ORD2026072914342555300040019','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914342555300040019\",\"couponId\":0,\"timestamp\":1785306865553,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":90004}',0,0,'2026-07-29 14:34:25','2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354556869595137,92004,'ORD2026072914362927720040034','order','ORDER_CREATED','{\"couponId\":0,\"timestamp\":1785306989277,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":92004,\"orderNo\":\"ORD2026072914362927720040034\"}',0,0,'2026-07-29 14:36:29','2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354824663306241,94004,'ORD2026072914373312440040039','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914373312440040039\",\"couponId\":0,\"timestamp\":1785307053124,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":94004}',0,0,'2026-07-29 14:37:33','2026-07-29 14:37:33','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_local_message_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_2`
--

DROP TABLE IF EXISTS `t_local_message_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_2` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_2`
--

LOCK TABLES `t_local_message_2` WRITE;
/*!40000 ALTER TABLE `t_local_message_2` DISABLE KEYS */;
INSERT INTO `t_local_message_2` VALUES (2082354835035820034,94008,'ORD2026072914373560340080043','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914373560340080043\",\"couponId\":0,\"timestamp\":1785307055603,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":94008}',0,0,'2026-07-29 14:37:35','2026-07-29 14:37:35','2026-07-29 14:37:35');
/*!40000 ALTER TABLE `t_local_message_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_3`
--

DROP TABLE IF EXISTS `t_local_message_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_3` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_3`
--

LOCK TABLES `t_local_message_3` WRITE;
/*!40000 ALTER TABLE `t_local_message_3` DISABLE KEYS */;
INSERT INTO `t_local_message_3` VALUES (2082354230737350657,91004,'ORD2026072914351152810040024','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351152810040024\",\"couponId\":0,\"timestamp\":1785306911528,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":91004}',0,0,'2026-07-29 14:35:11','2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_local_message_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_0`
--

DROP TABLE IF EXISTS `t_order_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_0` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_0`
--

LOCK TABLES `t_order_0` WRITE;
/*!40000 ALTER TABLE `t_order_0` DISABLE KEYS */;
INSERT INTO `t_order_0` VALUES (2082354232293437442,91008,'ORD2026072914351190410080028',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_1`
--

DROP TABLE IF EXISTS `t_order_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_1` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_1`
--

LOCK TABLES `t_order_1` WRITE;
/*!40000 ALTER TABLE `t_order_1` DISABLE KEYS */;
INSERT INTO `t_order_1` VALUES (2082354037879058433,90004,'ORD2026072914342555300040019',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354556827652097,92004,'ORD2026072914362927720040034',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354824617168897,94004,'ORD2026072914373312440040039',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:37:33','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_2`
--

DROP TABLE IF EXISTS `t_order_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_2` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_2`
--

LOCK TABLES `t_order_2` WRITE;
/*!40000 ALTER TABLE `t_order_2` DISABLE KEYS */;
INSERT INTO `t_order_2` VALUES (2082354835010654210,94008,'ORD2026072914373560340080043',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:37:35','2026-07-29 14:37:35');
/*!40000 ALTER TABLE `t_order_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_3`
--

DROP TABLE IF EXISTS `t_order_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_3` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_3`
--

LOCK TABLES `t_order_3` WRITE;
/*!40000 ALTER TABLE `t_order_3` DISABLE KEYS */;
INSERT INTO `t_order_3` VALUES (2082354230712184833,91004,'ORD2026072914351152810040024',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_0`
--

DROP TABLE IF EXISTS `t_order_event_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_0` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289233889027244033 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_0`
--

LOCK TABLES `t_order_event_0` WRITE;
/*!40000 ALTER TABLE `t_order_event_0` DISABLE KEYS */;
INSERT INTO `t_order_event_0` VALUES (1289233889027244032,2082354232293437442,91008,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:11.946507507\"}',1,'2026-07-29 14:35:11.952','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_event_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_1`
--

DROP TABLE IF EXISTS `t_order_event_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_1` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289234481443323906 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_1`
--

LOCK TABLES `t_order_event_1` WRITE;
/*!40000 ALTER TABLE `t_order_event_1` DISABLE KEYS */;
INSERT INTO `t_order_event_1` VALUES (1289233694617059329,2082354037879058433,90004,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:34:25.594550646\"}',1,'2026-07-29 14:34:25.600','2026-07-29 14:34:25'),(1289234213666373632,2082354556827652097,92004,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:36:29.341678609\"}',1,'2026-07-29 14:36:29.350','2026-07-29 14:36:29'),(1289234481443323905,2082354824617168897,94004,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:37:33.185787872\"}',1,'2026-07-29 14:37:33.194','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_event_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_2`
--

DROP TABLE IF EXISTS `t_order_event_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_2` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289234491803254786 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_2`
--

LOCK TABLES `t_order_event_2` WRITE;
/*!40000 ALTER TABLE `t_order_event_2` DISABLE KEYS */;
INSERT INTO `t_order_event_2` VALUES (1289234491803254785,2082354835010654210,94008,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"支付失败\",\"cancelTime\":\"2026-07-29T14:37:35.655560255\"}',1,'2026-07-29 14:37:35.663','2026-07-29 14:37:35');
/*!40000 ALTER TABLE `t_order_event_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_3`
--

DROP TABLE IF EXISTS `t_order_event_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_3` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289233887462768641 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_3`
--

LOCK TABLES `t_order_event_3` WRITE;
/*!40000 ALTER TABLE `t_order_event_3` DISABLE KEYS */;
INSERT INTO `t_order_event_3` VALUES (1289233887462768640,2082354230712184833,91004,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:11.573253122\"}',1,'2026-07-29 14:35:11.579','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_event_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_0`
--

DROP TABLE IF EXISTS `t_order_item_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_0` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_0`
--

LOCK TABLES `t_order_item_0` WRITE;
/*!40000 ALTER TABLE `t_order_item_0` DISABLE KEYS */;
INSERT INTO `t_order_item_0` VALUES (2082354232310214657,2082354232293437442,91008,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_item_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_1`
--

DROP TABLE IF EXISTS `t_order_item_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_1` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_1`
--

LOCK TABLES `t_order_item_1` WRITE;
/*!40000 ALTER TABLE `t_order_item_1` DISABLE KEYS */;
INSERT INTO `t_order_item_1` VALUES (2082354037895835650,2082354037879058433,90004,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:34:25'),(2082354556852817921,2082354556827652097,92004,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:36:29'),(2082354824650723330,2082354824617168897,94004,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_item_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_2`
--

DROP TABLE IF EXISTS `t_order_item_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_2` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_2`
--

LOCK TABLES `t_order_item_2` WRITE;
/*!40000 ALTER TABLE `t_order_item_2` DISABLE KEYS */;
INSERT INTO `t_order_item_2` VALUES (2082354835027431426,2082354835010654210,94008,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:37:35');
/*!40000 ALTER TABLE `t_order_item_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_3`
--

DROP TABLE IF EXISTS `t_order_item_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_3` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_3`
--

LOCK TABLES `t_order_item_3` WRITE;
/*!40000 ALTER TABLE `t_order_item_3` DISABLE KEYS */;
INSERT INTO `t_order_item_3` VALUES (2082354230728962049,2082354230712184833,91004,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_item_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_0`
--

DROP TABLE IF EXISTS `t_order_snapshot_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_0` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_0`
--

LOCK TABLES `t_order_snapshot_0` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_0` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_0` VALUES (2082354232356352002,2082354232293437442,91008,'CREATED','{\"timestamp\":\"2026-07-29T14:35:11.922055404\",\"order\":{\"id\":2082354232293437442,\"userId\":91008,\"orderNo\":\"ORD2026072914351190410080028\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354232310214657,\"orderId\":2082354232293437442,\"userId\":91008,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2082354232524124162,2082354232293437442,91008,'PAID','{\"timestamp\":\"2026-07-29T14:35:11.962022211\",\"order\":{\"id\":2082354232293437442,\"userId\":91008,\"orderNo\":\"ORD2026072914351190410080028\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354232310214657,\"orderId\":2082354232293437442,\"userId\":91008,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_snapshot_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_1`
--

DROP TABLE IF EXISTS `t_order_snapshot_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_1` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_1`
--

LOCK TABLES `t_order_snapshot_1` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_1` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_1` VALUES (2082354037946167298,2082354037879058433,90004,'CREATED','{\"timestamp\":\"2026-07-29T14:34:25.571203421\",\"order\":{\"id\":2082354037879058433,\"userId\":90004,\"orderNo\":\"ORD2026072914342555300040019\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354037895835650,\"orderId\":2082354037879058433,\"userId\":90004,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354038105550850,2082354037879058433,90004,'PAID','{\"timestamp\":\"2026-07-29T14:34:25.608996079\",\"order\":{\"id\":2082354037879058433,\"userId\":90004,\"orderNo\":\"ORD2026072914342555300040019\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354037895835650,\"orderId\":2082354037879058433,\"userId\":90004,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354556949286913,2082354556827652097,92004,'CREATED','{\"timestamp\":\"2026-07-29T14:36:29.309984954\",\"order\":{\"id\":2082354556827652097,\"userId\":92004,\"orderNo\":\"ORD2026072914362927720040034\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:29\",\"updatedAt\":\"2026-07-29 14:36:29\"},\"items\":[{\"id\":2082354556852817921,\"orderId\":2082354556827652097,\"userId\":92004,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:29\"}]}','2026-07-29 14:36:29'),(2082354557184167937,2082354556827652097,92004,'PAID','{\"timestamp\":\"2026-07-29T14:36:29.366885038\",\"order\":{\"id\":2082354556827652097,\"userId\":92004,\"orderNo\":\"ORD2026072914362927720040034\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:29\",\"updatedAt\":\"2026-07-29 14:36:29\"},\"items\":[{\"id\":2082354556852817921,\"orderId\":2082354556827652097,\"userId\":92004,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:29\"}]}','2026-07-29 14:36:29'),(2082354824734609410,2082354824617168897,94004,'CREATED','{\"timestamp\":\"2026-07-29T14:37:33.154527319\",\"order\":{\"id\":2082354824617168897,\"userId\":94004,\"orderNo\":\"ORD2026072914373312440040039\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354824650723330,\"orderId\":2082354824617168897,\"userId\":94004,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33'),(2082354824956907521,2082354824617168897,94004,'PAID','{\"timestamp\":\"2026-07-29T14:37:33.206627274\",\"order\":{\"id\":2082354824617168897,\"userId\":94004,\"orderNo\":\"ORD2026072914373312440040039\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354824650723330,\"orderId\":2082354824617168897,\"userId\":94004,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_snapshot_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_2`
--

DROP TABLE IF EXISTS `t_order_snapshot_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_2` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_2`
--

LOCK TABLES `t_order_snapshot_2` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_2` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_2` VALUES (2082354835077763073,2082354835010654210,94008,'CREATED','{\"timestamp\":\"2026-07-29T14:37:35.622352319\",\"order\":{\"id\":2082354835010654210,\"userId\":94008,\"orderNo\":\"ORD2026072914373560340080043\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:35\",\"updatedAt\":\"2026-07-29 14:37:35\"},\"items\":[{\"id\":2082354835027431426,\"orderId\":2082354835010654210,\"userId\":94008,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:35\"}]}','2026-07-29 14:37:35'),(2082354835354587137,2082354835010654210,94008,'CANCELLED','{\"timestamp\":\"2026-07-29T14:37:35.688243751\",\"order\":{\"id\":2082354835010654210,\"userId\":94008,\"orderNo\":\"ORD2026072914373560340080043\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:35\",\"updatedAt\":\"2026-07-29 14:37:35\"},\"items\":[{\"id\":2082354835027431426,\"orderId\":2082354835010654210,\"userId\":94008,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:35\"}]}','2026-07-29 14:37:35');
/*!40000 ALTER TABLE `t_order_snapshot_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_3`
--

DROP TABLE IF EXISTS `t_order_snapshot_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_3` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_3`
--

LOCK TABLES `t_order_snapshot_3` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_3` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_3` VALUES (2082354230783488002,2082354230712184833,91004,'CREATED','{\"timestamp\":\"2026-07-29T14:35:11.546485404\",\"order\":{\"id\":2082354230712184833,\"userId\":91004,\"orderNo\":\"ORD2026072914351152810040024\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354230728962049,\"orderId\":2082354230712184833,\"userId\":91004,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2082354230963843074,2082354230712184833,91004,'PAID','{\"timestamp\":\"2026-07-29T14:35:11.589838885\",\"order\":{\"id\":2082354230712184833,\"userId\":91004,\"orderNo\":\"ORD2026072914351152810040024\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354230728962049,\"orderId\":2082354230712184833,\"userId\":91004,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_snapshot_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'my_xhs_order_0'
--

--
-- Dumping routines for database 'my_xhs_order_0'
--

--
-- Current Database: `my_xhs_order_1`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `my_xhs_order_1` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `my_xhs_order_1`;

--
-- Table structure for table `t_local_message_0`
--

DROP TABLE IF EXISTS `t_local_message_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_0` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_0`
--

LOCK TABLES `t_local_message_0` WRITE;
/*!40000 ALTER TABLE `t_local_message_0` DISABLE KEYS */;
INSERT INTO `t_local_message_0` VALUES (2076150662497951745,10001,'ORD2026071211442511000010002','order','ORDER_CREATED','{\"orderNo\":\"ORD2026071211442511000010002\",\"couponId\":0,\"timestamp\":1783827865112,\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001}',0,0,'2026-07-12 11:44:25','2026-07-12 11:44:25','2026-07-12 11:44:25'),(2076151574691889153,10001,'ORD2026071211480262300010003','order','ORDER_CREATED','{\"userId\":10001,\"orderNo\":\"ORD2026071211480262300010003\",\"couponId\":0,\"timestamp\":1783828082625,\"skuItems\":[{\"skuId\":1,\"quantity\":1}]}',0,0,'2026-07-12 11:48:03','2026-07-12 11:48:03','2026-07-12 11:48:03'),(2076169498081140737,10001,'ORD2026071212591630100010006','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071212591630100010006\",\"couponId\":0,\"timestamp\":1783832356302}',0,0,'2026-07-12 12:59:16','2026-07-12 12:59:16','2026-07-12 12:59:16'),(2076169592914354178,10001,'ORD2026071212593896300010007','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071212593896300010007\",\"couponId\":0,\"timestamp\":1783832378963}',0,0,'2026-07-12 12:59:38','2026-07-12 12:59:38','2026-07-12 12:59:38'),(2076169644143583233,10001,'ORD2026071212595117700010008','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071212595117700010008\",\"couponId\":0,\"timestamp\":1783832391177}',0,0,'2026-07-12 12:59:51','2026-07-12 12:59:51','2026-07-12 12:59:51'),(2076173837386424322,10001,'ORD2026071213163092600010009','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071213163092600010009\",\"couponId\":0,\"timestamp\":1783833390926}',0,0,'2026-07-12 13:16:30','2026-07-12 13:16:30','2026-07-12 13:16:30'),(2076174885819817986,10001,'ORD2026071213204089200010010','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071213204089200010010\",\"couponId\":0,\"timestamp\":1783833640892}',0,0,'2026-07-12 13:20:40','2026-07-12 13:20:40','2026-07-12 13:20:40'),(2076175112253513730,10001,'ORD2026071213213487700010011','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071213213487700010011\",\"couponId\":0,\"timestamp\":1783833694878}',0,0,'2026-07-12 13:21:34','2026-07-12 13:21:34','2026-07-12 13:21:34'),(2076175587090669570,10001,'ORD2026071213232808800010012','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071213232808800010012\",\"couponId\":0,\"timestamp\":1783833808088}',0,0,'2026-07-12 13:23:28','2026-07-12 13:23:28','2026-07-12 13:23:28'),(2076177245090652161,10001,'ORD2026071213300338400010013','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071213300338400010013\",\"couponId\":0,\"timestamp\":1783834203385}',0,0,'2026-07-12 13:30:03','2026-07-12 13:30:03','2026-07-12 13:30:03'),(2076177245216481281,10001,'ORD2026071213300341800010014','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071213300341800010014\",\"couponId\":0,\"timestamp\":1783834203419}',0,0,'2026-07-12 13:30:03','2026-07-12 13:30:03','2026-07-12 13:30:03'),(2076177245342310402,10001,'ORD2026071213300345000010015','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071213300345000010015\",\"couponId\":0,\"timestamp\":1783834203450}',0,0,'2026-07-12 13:30:03','2026-07-12 13:30:03','2026-07-12 13:30:03'),(2076177245480722434,10001,'ORD2026071213300348000010016','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071213300348000010016\",\"couponId\":0,\"timestamp\":1783834203481}',0,0,'2026-07-12 13:30:03','2026-07-12 13:30:03','2026-07-12 13:30:03'),(2076177245593968641,10001,'ORD2026071213300351000010017','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":1,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026071213300351000010017\",\"couponId\":0,\"timestamp\":1783834203510}',0,0,'2026-07-12 13:30:03','2026-07-12 13:30:03','2026-07-12 13:30:03'),(2082305391351353345,20001,'ORD2026072911210714700010001','order','ORDER_CREATED','{\"timestamp\":1785295267154,\"couponId\":0,\"orderNo\":\"ORD2026072911210714700010001\",\"userId\":20001,\"skuItems\":[{\"skuId\":999,\"quantity\":1}]}',0,0,'2026-07-29 11:21:07','2026-07-29 11:21:07','2026-07-29 11:21:07'),(2082307019966042114,20001,'ORD2026072911273560200010002','order','ORDER_CREATED','{\"timestamp\":1785295655602,\"couponId\":0,\"orderNo\":\"ORD2026072911273560200010002\",\"userId\":20001,\"skuItems\":[{\"skuId\":999,\"quantity\":2}]}',0,0,'2026-07-29 11:27:35','2026-07-29 11:27:35','2026-07-29 11:27:35'),(2082329674383425537,30001,'ORD2026072912573675600010006','order','ORDER_CREATED','{\"timestamp\":1785301056758,\"couponId\":0,\"orderNo\":\"ORD2026072912573675600010006\",\"userId\":30001,\"skuItems\":[{\"skuId\":999,\"quantity\":1}]}',0,0,'2026-07-29 12:57:36','2026-07-29 12:57:36','2026-07-29 12:57:36'),(2082329775717810178,40001,'ORD2026072912580099500010007','order','ORDER_CREATED','{\"timestamp\":1785301080995,\"couponId\":0,\"orderNo\":\"ORD2026072912580099500010007\",\"userId\":40001,\"skuItems\":[{\"skuId\":999,\"quantity\":1}]}',0,0,'2026-07-29 12:58:01','2026-07-29 12:58:01','2026-07-29 12:58:01'),(2082350109296754690,50001,'ORD2026072914184889400010008','order','ORDER_CREATED','{\"timestamp\":1785305928894,\"couponId\":0,\"orderNo\":\"ORD2026072914184889400010008\",\"userId\":50001,\"skuItems\":[{\"skuId\":999,\"quantity\":1}]}',0,0,'2026-07-29 14:18:48','2026-07-29 14:18:48','2026-07-29 14:18:48'),(2082350632796225537,60001,'ORD2026072914205371000010010','order','ORDER_CREATED','{\"timestamp\":1785306053710,\"couponId\":0,\"orderNo\":\"ORD2026072914205371000010010\",\"userId\":60001,\"skuItems\":[{\"skuId\":999,\"quantity\":2}]}',0,0,'2026-07-29 14:20:53','2026-07-29 14:20:53','2026-07-29 14:20:53'),(2082350998732517378,70001,'ORD2026072914221996400010011','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914221996400010011\",\"couponId\":0,\"timestamp\":1785306139966,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":70001}',0,0,'2026-07-29 14:22:20','2026-07-29 14:22:20','2026-07-29 14:22:20'),(2082351672589398018,80001,'ORD2026072914250161400010012','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914250161400010012\",\"couponId\":2082351668176924674,\"timestamp\":1785306301614,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":80001}',0,0,'2026-07-29 14:25:01','2026-07-29 14:25:01','2026-07-29 14:25:01'),(2082351748544049153,80001,'ORD2026072914251972500010013','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914251972500010013\",\"couponId\":2082351668176924674,\"timestamp\":1785306319725,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":80001}',0,0,'2026-07-29 14:25:19','2026-07-29 14:25:19','2026-07-29 14:25:19'),(2082351861437935617,80001,'ORD2026072914254664200010014','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914254664200010014\",\"couponId\":2082351668176924674,\"timestamp\":1785306346642,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":80001}',0,0,'2026-07-29 14:25:46','2026-07-29 14:25:46','2026-07-29 14:25:46'),(2082353976189235201,90001,'ORD2026072914341083800010015','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914341083800010015\",\"couponId\":0,\"timestamp\":1785306850838,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":90001}',0,0,'2026-07-29 14:34:10','2026-07-29 14:34:10','2026-07-29 14:34:10'),(2082354036562046977,90001,'ORD2026072914342523200010016','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914342523200010016\",\"couponId\":0,\"timestamp\":1785306865232,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":90001}',0,0,'2026-07-29 14:34:25','2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354232700284930,91009,'ORD2026072914351199610090029','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351199610090029\",\"couponId\":0,\"timestamp\":1785306911996,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":91009}',0,0,'2026-07-29 14:35:12','2026-07-29 14:35:12','2026-07-29 14:35:12'),(2082354553346379777,92001,'ORD2026072914362735320010031','order','ORDER_CREATED','{\"couponId\":0,\"timestamp\":1785306987355,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":92001,\"orderNo\":\"ORD2026072914362735320010031\"}',0,0,'2026-07-29 14:36:28','2026-07-29 14:36:28','2026-07-29 14:36:28'),(2082354803909890049,94001,'ORD2026072914372700740010036','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914372700740010036\",\"couponId\":0,\"timestamp\":1785307047009,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":94001}',0,0,'2026-07-29 14:37:28','2026-07-29 14:37:28','2026-07-29 14:37:28'),(2082355315103272962,10001,'ORD2026072914393006000010044','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914393006000010044\",\"couponId\":0,\"timestamp\":1785307170060,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":10001}',0,0,'2026-07-29 14:39:30','2026-07-29 14:39:30','2026-07-29 14:39:30'),(2082355590392221697,20001,'ORD2026072914403569600010047','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914403569600010047\",\"couponId\":0,\"timestamp\":1785307235696,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":20001}',0,0,'2026-07-29 14:40:35','2026-07-29 14:40:35','2026-07-29 14:40:35'),(2082355656813219841,30001,'ORD2026072914405153100010048','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914405153100010048\",\"couponId\":0,\"timestamp\":1785307251532,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":30001}',0,0,'2026-07-29 14:40:51','2026-07-29 14:40:51','2026-07-29 14:40:51'),(2082367690825043970,10001,'ORD2026072915284066400010049','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072915284066400010049\",\"couponId\":0,\"timestamp\":1785310120664,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":10001}',0,0,'2026-07-29 15:28:40','2026-07-29 15:28:40','2026-07-29 15:28:40'),(2084171331093438465,2084171328232906753,'ORD2026080314554185467530001','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554185467530001\",\"couponId\":0,\"timestamp\":1785740141860}',0,0,'2026-08-03 14:55:42','2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171332880211969,2084171328232906753,'ORD2026080314554244067530002','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554244067530002\",\"couponId\":0,\"timestamp\":1785740142440}',0,0,'2026-08-03 14:55:42','2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171333555494913,2084171328232906753,'ORD2026080314554260167530003','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554260167530003\",\"couponId\":0,\"timestamp\":1785740142601}',0,0,'2026-08-03 14:55:42','2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171333903622145,2084171328232906753,'ORD2026080314554268067530004','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554268067530004\",\"couponId\":0,\"timestamp\":1785740142680}',0,0,'2026-08-03 14:55:42','2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171334226583554,2084171328232906753,'ORD2026080314554276167530005','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554276167530005\",\"couponId\":0,\"timestamp\":1785740142761}',0,0,'2026-08-03 14:55:42','2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171442519318530,2084171442041151489,'ORD2026080314560857914890006','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560857914890006\",\"couponId\":0,\"timestamp\":1785740168579}',0,0,'2026-08-03 14:56:08','2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084171443253321730,2084171442041151489,'ORD2026080314560875714890007','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560875714890007\",\"couponId\":0,\"timestamp\":1785740168757}',0,0,'2026-08-03 14:56:08','2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084171443555311618,2084171442041151489,'ORD2026080314560882814890008','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560882814890008\",\"couponId\":0,\"timestamp\":1785740168828}',0,0,'2026-08-03 14:56:08','2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084171443785998338,2084171442041151489,'ORD2026080314560888314890009','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560888314890009\",\"couponId\":0,\"timestamp\":1785740168883}',0,0,'2026-08-03 14:56:08','2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084171444067016706,2084171442041151489,'ORD2026080314560895014890010','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560895014890010\",\"couponId\":0,\"timestamp\":1785740168950}',0,0,'2026-08-03 14:56:08','2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084212478696288258,2084212477404413953,'ORD2026080317391230939530013','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084212477404413953,\"orderNo\":\"ORD2026080317391230939530013\",\"couponId\":0,\"timestamp\":1785749952310}',0,0,'2026-08-03 17:39:12','2026-08-03 17:39:12','2026-08-03 17:39:12'),(2084212480214626306,2084212477404413953,'ORD2026080317391272639530014','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084212477404413953,\"orderNo\":\"ORD2026080317391272639530014\",\"couponId\":0,\"timestamp\":1785749952727}',0,0,'2026-08-03 17:39:12','2026-08-03 17:39:12','2026-08-03 17:39:12'),(2084481541498523650,2084481541045514241,'ORD2026080411282193542410004','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084481541045514241,\"orderNo\":\"ORD2026080411282193542410004\",\"couponId\":0,\"timestamp\":1785814101935}',0,0,'2026-08-04 11:28:21','2026-08-04 11:28:21','2026-08-04 11:28:21'),(2084481542219943938,2084481541045514241,'ORD2026080411282211142410005','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084481541045514241,\"orderNo\":\"ORD2026080411282211142410005\",\"couponId\":0,\"timestamp\":1785814102112}',0,0,'2026-08-04 11:28:22','2026-08-04 11:28:22','2026-08-04 11:28:22'),(2084482909533687810,2084482909093261313,'ORD2026080411334810313130014','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084482909093261313,\"orderNo\":\"ORD2026080411334810313130014\",\"couponId\":0,\"timestamp\":1785814428104}',0,0,'2026-08-04 11:33:48','2026-08-04 11:33:48','2026-08-04 11:33:48'),(2084482910229942274,2084482909093261313,'ORD2026080411334827013130015','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084482909093261313,\"orderNo\":\"ORD2026080411334827013130015\",\"couponId\":0,\"timestamp\":1785814428270}',0,0,'2026-08-04 11:33:48','2026-08-04 11:33:48','2026-08-04 11:33:48'),(2084483583994548225,2084483583558316033,'ORD2026080411362890860330018','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084483583558316033,\"orderNo\":\"ORD2026080411362890860330018\",\"couponId\":0,\"timestamp\":1785814588908}',0,0,'2026-08-04 11:36:28','2026-08-04 11:36:28','2026-08-04 11:36:28'),(2084483584653053953,2084483583558316033,'ORD2026080411362906560330019','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084483583558316033,\"orderNo\":\"ORD2026080411362906560330019\",\"couponId\":0,\"timestamp\":1785814589065}',0,0,'2026-08-04 11:36:29','2026-08-04 11:36:29','2026-08-04 11:36:29'),(2085531903554813953,10001,'ORD2026080709020763800010001','order','ORDER_CREATED','{\"couponId\":0,\"orderNo\":\"ORD2026080709020763800010001\",\"userId\":10001,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"timestamp\":1786064527643}',0,0,'2026-08-07 09:02:07','2026-08-07 09:02:07','2026-08-07 09:02:07'),(2085534649917919233,10001,'ORD2026080709130122500010002','order','ORDER_CREATED','{\"timestamp\":1786065181227,\"couponId\":0,\"orderNo\":\"ORD2026080709130122500010002\",\"userId\":10001,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}]}',0,0,'2026-08-07 09:13:02','2026-08-07 09:13:02','2026-08-07 09:13:02'),(2085535520437313538,10001,'ORD2026080709162895200010003','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026080709162895200010003\",\"couponId\":0,\"timestamp\":1786065388954}',0,0,'2026-08-07 09:16:30','2026-08-07 09:16:30','2026-08-07 09:16:30'),(2085537317533061121,10001,'ORD2026080709233742200010004','order','ORDER_CREATED','{\"userId\":10001,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"timestamp\":1786065817424,\"couponId\":0,\"orderNo\":\"ORD2026080709233742200010004\"}',0,0,'2026-08-07 09:23:38','2026-08-07 09:23:38','2026-08-07 09:23:38'),(2085539008974176257,10001,'ORD2026080709302068800010005','order','ORDER_CREATED','{\"timestamp\":1786066220690,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026080709302068800010005\",\"couponId\":0}',0,0,'2026-08-07 09:30:21','2026-08-07 09:30:21','2026-08-07 09:30:21'),(2085562359671177217,10001,'ORD2026080711030903300010006','order','ORDER_CREATED','{\"timestamp\":1786071789034,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":2}],\"userId\":10001,\"orderNo\":\"ORD2026080711030903300010006\",\"couponId\":0}',0,0,'2026-08-07 11:03:09','2026-08-07 11:03:09','2026-08-07 11:03:09'),(2085562511169437698,10001,'ORD2026080711034518800010007','order','ORDER_CREATED','{\"timestamp\":1786071825189,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":2}],\"userId\":10001,\"orderNo\":\"ORD2026080711034518800010007\",\"couponId\":0}',0,0,'2026-08-07 11:03:45','2026-08-07 11:03:45','2026-08-07 11:03:45'),(2085564029528457217,10001,'ORD2026080711094719400010008','order','ORDER_CREATED','{\"timestamp\":1786072187195,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":3}],\"userId\":10001,\"orderNo\":\"ORD2026080711094719400010008\",\"couponId\":0}',0,0,'2026-08-07 11:09:47','2026-08-07 11:09:47','2026-08-07 11:09:47'),(2085564300715376642,10001,'ORD2026080711105185000010009','order','ORDER_CREATED','{\"timestamp\":1786072251851,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":3}],\"userId\":10001,\"orderNo\":\"ORD2026080711105185000010009\",\"couponId\":0}',0,0,'2026-08-07 11:10:51','2026-08-07 11:10:51','2026-08-07 11:10:51'),(2085565472394199041,10001,'ORD2026080711153119800010010','order','ORDER_CREATED','{\"timestamp\":1786072531199,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":2}],\"userId\":10001,\"orderNo\":\"ORD2026080711153119800010010\",\"couponId\":0}',0,0,'2026-08-07 11:15:31','2026-08-07 11:15:31','2026-08-07 11:15:31'),(2085588520111456258,10001,'ORD2026080712470616100010011','order','ORDER_CREATED','{\"timestamp\":1786078026162,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":2}],\"userId\":10001,\"orderNo\":\"ORD2026080712470616100010011\",\"couponId\":0}',0,0,'2026-08-07 12:47:06','2026-08-07 12:47:06','2026-08-07 12:47:06'),(2085590379035361281,10001,'ORD2026080712542826900010012','order','ORDER_CREATED','{\"userId\":10001,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"timestamp\":1786078468272,\"couponId\":0,\"orderNo\":\"ORD2026080712542826900010012\"}',0,0,'2026-08-07 12:54:29','2026-08-07 12:54:29','2026-08-07 12:54:29'),(2085594181687836673,10001,'ORD2026080713093602200010013','order','ORDER_CREATED','{\"userId\":10001,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":9999}],\"timestamp\":1786079376023,\"couponId\":0,\"orderNo\":\"ORD2026080713093602200010013\"}',0,0,'2026-08-07 13:09:36','2026-08-07 13:09:36','2026-08-07 13:09:36'),(2085596267259461633,10001,'ORD2026080713175213900010014','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026080713175213900010014\",\"couponId\":0,\"timestamp\":1786079872141}',0,0,'2026-08-07 13:17:53','2026-08-07 13:17:53','2026-08-07 13:17:53'),(2085631829387345921,10001,'ORD2026080715391193100010015','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026080715391193100010015\",\"couponId\":0,\"timestamp\":1786088351932}',0,0,'2026-08-07 15:39:11','2026-08-07 15:39:11','2026-08-07 15:39:11'),(2085631829940994050,10001,'ORD2026080715391206800010016','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026080715391206800010016\",\"couponId\":0,\"timestamp\":1786088352069}',0,0,'2026-08-07 15:39:12','2026-08-07 15:39:12','2026-08-07 15:39:12'),(2085631963944812545,10001,'ORD2026080715394401900010017','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026080715394401900010017\",\"couponId\":0,\"timestamp\":1786088384020}',0,0,'2026-08-07 15:39:44','2026-08-07 15:39:44','2026-08-07 15:39:44'),(2085632792739282945,10001,'ORD2026080715430162000010018','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"userId\":10001,\"orderNo\":\"ORD2026080715430162000010018\",\"couponId\":0,\"timestamp\":1786088581621}',0,0,'2026-08-07 15:43:01','2026-08-07 15:43:01','2026-08-07 15:43:01'),(2085638177046962177,10001,'ORD2026080716042422100010019','order','ORDER_CREATED','{\"timestamp\":1786089864224,\"couponId\":0,\"orderNo\":\"ORD2026080716042422100010019\",\"userId\":10001,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}]}',0,0,'2026-08-07 16:04:25','2026-08-07 16:04:25','2026-08-07 16:04:25'),(2085638864933797889,10001,'ORD2026080716070824900010020','order','ORDER_CREATED','{\"timestamp\":1786090028251,\"couponId\":0,\"orderNo\":\"ORD2026080716070824900010020\",\"userId\":10001,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}]}',0,0,'2026-08-07 16:07:09','2026-08-07 16:07:09','2026-08-07 16:07:09'),(2085639994329825281,10001,'ORD2026080716113731500010021','order','ORDER_CREATED','{\"orderNo\":\"ORD2026080716113731500010021\",\"couponId\":0,\"timestamp\":1786090297317,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"userId\":10001}',0,0,'2026-08-07 16:11:38','2026-08-07 16:11:38','2026-08-07 16:11:38'),(2085642441249034242,10001,'ORD2026080716212199200010022','order','ORDER_CREATED','{\"orderNo\":\"ORD2026080716212199200010022\",\"couponId\":0,\"timestamp\":1786090881994,\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"userId\":10001}',0,0,'2026-08-07 16:21:22','2026-08-07 16:21:22','2026-08-07 16:21:22'),(2085643055660048385,10001,'ORD2026080716234728200010023','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"timestamp\":1786091027286,\"couponId\":0,\"orderNo\":\"ORD2026080716234728200010023\",\"userId\":10001}',0,0,'2026-08-07 16:23:48','2026-08-07 16:23:48','2026-08-07 16:23:48'),(2085646961068777474,10001,'ORD2026080716391961100010024','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2085530413171785729,\"quantity\":1}],\"timestamp\":1786091959612,\"couponId\":0,\"orderNo\":\"ORD2026080716391961100010024\",\"userId\":10001}',0,0,'2026-08-07 16:39:19','2026-08-07 16:39:19','2026-08-07 16:39:19');
/*!40000 ALTER TABLE `t_local_message_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_1`
--

DROP TABLE IF EXISTS `t_local_message_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_1` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_1`
--

LOCK TABLES `t_local_message_1` WRITE;
/*!40000 ALTER TABLE `t_local_message_1` DISABLE KEYS */;
INSERT INTO `t_local_message_1` VALUES (2082329122043908098,20005,'ORD2026072912552415000050005','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"timestamp\":1785300924152,\"couponId\":0,\"orderNo\":\"ORD2026072912552415000050005\",\"userId\":20005}',0,0,'2026-07-29 12:55:25','2026-07-29 12:55:25','2026-07-29 12:55:25'),(2082354038273323009,90005,'ORD2026072914342564100050020','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914342564100050020\",\"couponId\":0,\"timestamp\":1785306865641,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":90005}',0,0,'2026-07-29 14:34:25','2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354557381300226,92005,'ORD2026072914362940120050035','order','ORDER_CREATED','{\"couponId\":0,\"timestamp\":1785306989401,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":92005,\"orderNo\":\"ORD2026072914362940120050035\"}',0,0,'2026-07-29 14:36:29','2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354825145651201,94005,'ORD2026072914373324540050040','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914373324540050040\",\"couponId\":0,\"timestamp\":1785307053245,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":94005}',0,0,'2026-07-29 14:37:33','2026-07-29 14:37:33','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_local_message_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_2`
--

DROP TABLE IF EXISTS `t_local_message_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_2` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_2`
--

LOCK TABLES `t_local_message_2` WRITE;
/*!40000 ALTER TABLE `t_local_message_2` DISABLE KEYS */;
INSERT INTO `t_local_message_2` VALUES (2082354229508419586,91001,'ORD2026072914351123410010021','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351123410010021\",\"couponId\":0,\"timestamp\":1785306911234,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":91001}',0,0,'2026-07-29 14:35:11','2026-07-29 14:35:11','2026-07-29 14:35:11'),(2084534107800391681,1001,'ORD2026080414571470310010021','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2084534106126888961,\"quantity\":1}],\"userId\":1001,\"orderNo\":\"ORD2026080414571470310010021\",\"couponId\":0,\"timestamp\":1785826634705}',0,0,'2026-08-04 14:57:14','2026-08-04 14:57:14','2026-08-04 14:57:14'),(2084534107905249281,1001,'ORD2026080414571474810010022','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2084534106550513665,\"quantity\":1}],\"userId\":1001,\"orderNo\":\"ORD2026080414571474810010022\",\"couponId\":0,\"timestamp\":1785826634748}',0,0,'2026-08-04 14:57:14','2026-08-04 14:57:14','2026-08-04 14:57:14'),(2084534108085604354,1001,'ORD2026080414571477610010023','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2084534106726674433,\"quantity\":1}],\"userId\":1001,\"orderNo\":\"ORD2026080414571477610010023\",\"couponId\":0,\"timestamp\":1785826634781}',0,0,'2026-08-04 14:57:14','2026-08-04 14:57:14','2026-08-04 14:57:14');
/*!40000 ALTER TABLE `t_local_message_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_3`
--

DROP TABLE IF EXISTS `t_local_message_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_3` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_3`
--

LOCK TABLES `t_local_message_3` WRITE;
/*!40000 ALTER TABLE `t_local_message_3` DISABLE KEYS */;
INSERT INTO `t_local_message_3` VALUES (2082354231131615234,91005,'ORD2026072914351162210050025','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351162210050025\",\"couponId\":0,\"timestamp\":1785306911623,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":91005}',0,0,'2026-07-29 14:35:11','2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_local_message_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_0`
--

DROP TABLE IF EXISTS `t_order_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_0` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_0`
--

LOCK TABLES `t_order_0` WRITE;
/*!40000 ALTER TABLE `t_order_0` DISABLE KEYS */;
INSERT INTO `t_order_0` VALUES (2076150660723761154,10001,'ORD2026071211442511000010002',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 11:44:25','2026-07-12 12:14:26'),(2076151572980613121,10001,'ORD2026071211480262300010003',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 11:48:03','2026-07-12 12:18:03'),(2076169498030809089,10001,'ORD2026071212591630100010006',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 12:59:16','2026-07-12 16:47:03'),(2076169592889188354,10001,'ORD2026071212593896300010007',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 12:59:38','2026-07-12 16:47:03'),(2076169644114223106,10001,'ORD2026071212595117700010008',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 12:59:51','2026-07-12 13:00:24'),(2076173837361258497,10001,'ORD2026071213163092600010009',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 13:16:30','2026-07-12 13:46:30'),(2076174885794652161,10001,'ORD2026071213204089200010010',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 13:20:40','2026-07-12 13:50:40'),(2076175112224153601,10001,'ORD2026071213213487700010011',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 13:21:34','2026-07-12 13:51:34'),(2076175587065503746,10001,'ORD2026071213232808800010012',99.00,99.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 13:23:28','2026-07-12 13:43:44'),(2076177245061292033,10001,'ORD2026071213300338400010013',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 13:30:03','2026-07-12 14:00:03'),(2076177245199704065,10001,'ORD2026071213300341800010014',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 13:30:03','2026-07-12 14:00:03'),(2076177245329727490,10001,'ORD2026071213300345000010015',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 13:30:03','2026-07-12 14:00:03'),(2076177245459750914,10001,'ORD2026071213300348000010016',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 13:30:03','2026-07-12 14:00:03'),(2076177245581385730,10001,'ORD2026071213300351000010017',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-12 13:30:03','2026-07-12 14:00:03'),(2082305390969671681,20001,'ORD2026072911210714700010001',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 11:21:07','2026-07-29 11:51:07'),(2082307019940876290,20001,'ORD2026072911273560200010002',198.00,198.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 11:27:35','2026-07-29 11:57:35'),(2082329674207264770,30001,'ORD2026072912573675600010006',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 12:57:36','2026-07-29 12:57:37'),(2082329775684255745,40001,'ORD2026072912580099500010007',99.00,99.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 12:58:01','2026-07-29 12:58:01'),(2082350109250617345,50001,'ORD2026072914184889400010008',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:18:48','2026-07-29 14:18:48'),(2082350632766865409,60001,'ORD2026072914205371000010010',198.00,198.00,0.00,NULL,5,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:20:53','2026-07-29 14:20:53'),(2082350994844397570,70001,'ORD2026072914221996400010011',99.00,99.00,0.00,NULL,5,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:22:20','2026-07-29 14:22:21'),(2082351672551649282,80001,'ORD2026072914250161400010012',99.00,89.00,10.00,2082351668176924674,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:25:01','2026-07-29 14:55:01'),(2082351748510494721,80001,'ORD2026072914251972500010013',99.00,89.00,10.00,2082351668176924674,5,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:25:19','2026-07-29 14:25:31'),(2082351861412769794,80001,'ORD2026072914254664200010014',99.00,89.00,10.00,2082351668176924674,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:25:46','2026-07-29 14:25:46'),(2082353976164069378,90001,'ORD2026072914341083800010015',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:34:10','2026-07-29 14:34:10'),(2082354036532686850,90001,'ORD2026072914342523200010016',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354232675119105,91009,'ORD2026072914351199610090029',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:12','2026-07-29 14:35:12'),(2082354549059801089,92001,'ORD2026072914362735320010031',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:36:28','2026-07-29 14:36:28'),(2082354799459733506,94001,'ORD2026072914372700740010036',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:37:28','2026-07-29 14:37:28'),(2082355315078107137,10001,'ORD2026072914393006000010044',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:39:30','2026-07-29 15:09:30'),(2082355590371250177,20001,'ORD2026072914403569600010047',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:40:35','2026-07-29 14:40:35'),(2082355656792248321,30001,'ORD2026072914405153100010048',99.00,99.00,0.00,NULL,5,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:40:51','2026-07-29 14:40:51'),(2082367690804072449,10001,'ORD2026072915284066400010049',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 15:28:40','2026-07-29 15:58:40'),(2084171330690785282,2084171328232906753,'ORD2026080314554185467530001',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171332859240449,2084171328232906753,'ORD2026080314554244067530002',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171333538717698,2084171328232906753,'ORD2026080314554260167530003',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171333874262017,2084171328232906753,'ORD2026080314554268067530004',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171334209806338,2084171328232906753,'ORD2026080314554276167530005',99.00,99.00,0.00,NULL,5,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171442498347010,2084171442041151489,'ORD2026080314560857914890006',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084171443244933121,2084171442041151489,'ORD2026080314560875714890007',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084171443542728705,2084171442041151489,'ORD2026080314560882814890008',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084171443773415425,2084171442041151489,'ORD2026080314560888314890009',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084171444050239489,2084171442041151489,'ORD2026080314560895014890010',99.00,99.00,0.00,NULL,5,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 14:56:08','2026-08-03 14:56:09'),(2084212478574653441,2084212477404413953,'ORD2026080317391230939530013',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 17:39:12','2026-08-03 17:39:12'),(2084212480189460482,2084212477404413953,'ORD2026080317391272639530014',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 17:39:12','2026-08-03 17:39:12'),(2084481541477552129,2084481541045514241,'ORD2026080411282193542410004',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:28:21','2026-08-04 11:28:22'),(2084481542207361026,2084481541045514241,'ORD2026080411282211142410005',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:28:22','2026-08-04 11:28:22'),(2084482909516910593,2084482909093261313,'ORD2026080411334810313130014',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:33:48','2026-08-04 11:33:48'),(2084482910217359362,2084482909093261313,'ORD2026080411334827013130015',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:33:48','2026-08-04 11:33:48'),(2084483583981965313,2084483583558316033,'ORD2026080411362890860330018',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:36:28','2026-08-04 11:36:29'),(2084483584636276737,2084483583558316033,'ORD2026080411362906560330019',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:36:29','2026-08-04 11:36:29'),(2085531903223463938,10001,'ORD2026080709020763800010001',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 09:32:07',0,'2026-08-07 09:02:07','2026-08-07 09:32:07'),(2085534644842811393,10001,'ORD2026080709130122500010002',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 09:43:02',0,'2026-08-07 09:13:02','2026-08-07 09:43:02'),(2085535516037488642,10001,'ORD2026080709162895200010003',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-07 09:16:30','2026-08-07 09:18:28'),(2085537313141624834,10001,'ORD2026080709233742200010004',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 09:23:47',0,'2026-08-07 09:23:38','2026-08-07 09:23:47'),(2085539004578545666,10001,'ORD2026080709302068800010005',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 09:31:22',0,'2026-08-07 09:30:21','2026-08-07 09:31:22'),(2085562359503405057,10001,'ORD2026080711030903300010006',59.80,59.80,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 11:04:09',0,'2026-08-07 11:03:09','2026-08-07 11:04:09'),(2085562511144271874,10001,'ORD2026080711034518800010007',59.80,59.80,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 11:04:45',0,'2026-08-07 11:03:45','2026-08-07 11:04:45'),(2085564029503291393,10001,'ORD2026080711094719400010008',89.70,89.70,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 11:10:47',0,'2026-08-07 11:09:47','2026-08-07 11:10:47'),(2085564300690210818,10001,'ORD2026080711105185000010009',89.70,89.70,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 11:11:51',0,'2026-08-07 11:10:51','2026-08-07 11:11:51'),(2085565472364838913,10001,'ORD2026080711153119800010010',59.80,59.80,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 11:16:31',0,'2026-08-07 11:15:31','2026-08-07 11:16:31'),(2085588519922712577,10001,'ORD2026080712470616100010011',59.80,59.80,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-07 12:47:06','2026-08-07 12:50:13'),(2085590374643924993,10001,'ORD2026080712542826900010012',29.90,29.90,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,'2026-08-07 12:54:30','2026-08-07 12:54:30','2026-08-07 12:54:45',NULL,0,'2026-08-07 12:54:29','2026-08-07 12:54:45'),(2085594181637505025,10001,'ORD2026080713093602200010013',298970.10,298970.10,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 13:10:36',0,'2026-08-07 13:09:36','2026-08-07 13:10:36'),(2085596262905774082,10001,'ORD2026080713175213900010014',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 13:18:53',0,'2026-08-07 13:17:53','2026-08-07 13:18:53'),(2085631829332819969,10001,'ORD2026080715391193100010015',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 15:40:12',0,'2026-08-07 15:39:11','2026-08-07 15:40:12'),(2085631829903245313,10001,'ORD2026080715391206800010016',29.90,29.90,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,'2026-08-07 15:39:12',NULL,NULL,NULL,0,'2026-08-07 15:39:12','2026-08-07 15:39:12'),(2085631963915452418,10001,'ORD2026080715394401900010017',29.90,29.90,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,'2026-08-07 15:39:46',NULL,NULL,NULL,0,'2026-08-07 15:39:44','2026-08-07 15:39:46'),(2085632792714117122,10001,'ORD2026080715430162000010018',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 15:44:01',0,'2026-08-07 15:43:01','2026-08-07 15:44:01'),(2085638172626165762,10001,'ORD2026080716042422100010019',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 16:05:25',0,'2026-08-07 16:04:25','2026-08-07 16:05:25'),(2085638860609470466,10001,'ORD2026080716070824900010020',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 16:08:09',0,'2026-08-07 16:07:09','2026-08-07 16:08:09'),(2085639989166637057,10001,'ORD2026080716113731500010021',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 16:21:07',0,'2026-08-07 16:11:38','2026-08-07 16:21:07'),(2085642441198702594,10001,'ORD2026080716212199200010022',29.90,29.90,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,'2026-08-07 16:22:22',0,'2026-08-07 16:21:22','2026-08-07 16:22:22'),(2085643051075674114,10001,'ORD2026080716234728200010023',29.90,29.90,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,'2026-08-07 16:30:00',NULL,NULL,NULL,0,'2026-08-07 16:23:48','2026-08-07 16:30:00'),(2085646961035223041,10001,'ORD2026080716391961100010024',29.90,29.90,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,'2026-08-07 16:46:00',NULL,NULL,NULL,0,'2026-08-07 16:39:19','2026-08-07 16:46:00');
/*!40000 ALTER TABLE `t_order_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_1`
--

DROP TABLE IF EXISTS `t_order_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_1` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_1`
--

LOCK TABLES `t_order_1` WRITE;
/*!40000 ALTER TABLE `t_order_1` DISABLE KEYS */;
INSERT INTO `t_order_1` VALUES (2082329118126428162,20005,'ORD2026072912552415000050005',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 12:55:25','2026-07-29 13:25:25'),(2082354038248157185,90005,'ORD2026072914342564100050020',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354557347745793,92005,'ORD2026072914362940120050035',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:36:29','2026-07-29 15:06:29'),(2082354825120485377,94005,'ORD2026072914373324540050040',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:37:33','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_2`
--

DROP TABLE IF EXISTS `t_order_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_2` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_2`
--

LOCK TABLES `t_order_2` WRITE;
/*!40000 ALTER TABLE `t_order_2` DISABLE KEYS */;
INSERT INTO `t_order_2` VALUES (2082354229479059458,91001,'ORD2026072914351123410010021',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2084534107729088513,1001,'ORD2026080414571470310010021',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 14:57:14','2026-08-04 15:27:14'),(2084534107892666369,1001,'ORD2026080414571474810010022',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 14:57:14','2026-08-04 15:27:14'),(2084534108052049921,1001,'ORD2026080414571477610010023',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 14:57:14','2026-08-04 15:27:14');
/*!40000 ALTER TABLE `t_order_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_3`
--

DROP TABLE IF EXISTS `t_order_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_3` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_3`
--

LOCK TABLES `t_order_3` WRITE;
/*!40000 ALTER TABLE `t_order_3` DISABLE KEYS */;
INSERT INTO `t_order_3` VALUES (2082354231110643714,91005,'ORD2026072914351162210050025',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_0`
--

DROP TABLE IF EXISTS `t_order_event_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_0` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1292528299466899458 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_0`
--

LOCK TABLES `t_order_event_0` WRITE;
/*!40000 ALTER TABLE `t_order_event_0` DISABLE KEYS */;
INSERT INTO `t_order_event_0` VALUES (1283037871680077824,2076150660723761154,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T12:14:26.236722690\"}',1,'2026-07-12 12:14:26.285','2026-07-12 12:14:26'),(1283038781122625537,2076151572980613121,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T12:18:03.117547369\"}',1,'2026-07-12 12:18:03.127','2026-07-12 12:18:03'),(1283049442431025152,2076169644114223106,10001,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-07-12T13:00:24.969448943\"}',1,'2026-07-12 13:00:24.981','2026-07-12 13:00:24'),(1283060274145607681,2076175587065503746,10001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-12T13:43:27.450258112\"}',1,'2026-07-12 13:43:27.463','2026-07-12 13:43:27'),(1283060274351128576,2076175587065503746,10001,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"顺丰速运\",\"deliveredTime\":\"2026-07-12T13:43:27.503625881\",\"trackingNo\":\"SF1234567890\"}',2,'2026-07-12 13:43:27.512','2026-07-12 13:43:27'),(1283060344836407297,2076175587065503746,10001,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-07-12T13:43:44.309093762\"}',3,'2026-07-12 13:43:44.317','2026-07-12 13:43:44'),(1283061043880083456,2076173837361258497,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T13:46:30.975341093\"}',1,'2026-07-12 13:46:30.982','2026-07-12 13:46:30'),(1283062092363808769,2076174885794652161,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T13:50:40.948697549\"}',1,'2026-07-12 13:50:40.960','2026-07-12 13:50:40'),(1283062318994636800,2076175112224153601,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T13:51:34.987128441\"}',1,'2026-07-12 13:51:34.993','2026-07-12 13:51:34'),(1283064451747889153,2076177245061292033,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T14:00:03.468818599\"}',1,'2026-07-12 14:00:03.480','2026-07-12 14:00:03'),(1283064451794026496,2076177245199704065,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T14:00:03.468607254\"}',1,'2026-07-12 14:00:03.491','2026-07-12 14:00:03'),(1283064452079239169,2076177245329727490,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T14:00:03.554351402\"}',1,'2026-07-12 14:00:03.560','2026-07-12 14:00:03'),(1283064452196679680,2076177245581385730,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T14:00:03.554372412\"}',1,'2026-07-12 14:00:03.588','2026-07-12 14:00:03'),(1283064452230234113,2076177245459750914,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T14:00:03.554479509\"}',1,'2026-07-12 14:00:03.596','2026-07-12 14:00:03'),(1283106478057406464,2076169498030809089,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T16:47:03.148863292\"}',1,'2026-07-12 16:47:03.300','2026-07-12 16:47:03'),(1283106478057406465,2076169592889188354,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-12T16:47:03.148863282\"}',1,'2026-07-12 16:47:03.324','2026-07-12 16:47:03'),(1289192598159572992,2082305390969671681,20001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-07-29T11:51:07.387917927\",\"cancelReason\":\"超时未支付\"}',1,'2026-07-29 11:51:07.438','2026-07-29 11:51:07'),(1289194226585518081,2082307019940876290,20001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-07-29T11:57:35.679662323\",\"cancelReason\":\"超时未支付\"}',1,'2026-07-29 11:57:35.688','2026-07-29 11:57:35'),(1289209331490570240,2082329674207264770,30001,'ORDER_CANCELLED',0,4,'{\"cancelTime\":\"2026-07-29T12:57:36.907841617\",\"cancelReason\":\"用户主动取消\"}',1,'2026-07-29 12:57:36.976','2026-07-29 12:57:36'),(1289209432522964993,2082329775684255745,40001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T12:58:01.056499079\"}',1,'2026-07-29 12:58:01.066','2026-07-29 12:58:01'),(1289209432749457408,2082329775684255745,40001,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"顺丰\",\"trackingNo\":\"SF123456\",\"deliveredTime\":\"2026-07-29T12:58:01.110296569\"}',2,'2026-07-29 12:58:01.120','2026-07-29 12:58:01'),(1289209432921423873,2082329775684255745,40001,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-07-29T12:58:01.152510559\"}',3,'2026-07-29 12:58:01.161','2026-07-29 12:58:01'),(1289229766059966464,2082350109250617345,50001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:18:48.945010836\"}',1,'2026-07-29 14:18:48.958','2026-07-29 14:18:48'),(1289230289534271489,2082350632766865409,60001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:20:53.754899334\"}',1,'2026-07-29 14:20:53.765','2026-07-29 14:20:53'),(1289230289693655040,2082350632766865409,60001,'ORDER_REFUNDED',1,5,'{\"refundTime\":\"2026-07-29T14:20:53.797445020\"}',2,'2026-07-29 14:20:53.803','2026-07-29 14:20:53'),(1289230657072742400,2082350994844397570,70001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:22:21.328078226\"}',1,'2026-07-29 14:22:21.391','2026-07-29 14:22:21'),(1289230657454424065,2082350994844397570,70001,'ORDER_REFUNDED',1,5,'{\"refundTime\":\"2026-07-29T14:22:21.475159925\"}',2,'2026-07-29 14:22:21.484','2026-07-29 14:22:21'),(1289231453004840960,2082351748510494721,80001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:25:31.148186310\"}',1,'2026-07-29 14:25:31.158','2026-07-29 14:25:31'),(1289231453189390337,2082351748510494721,80001,'ORDER_REFUNDED',1,5,'{\"refundTime\":\"2026-07-29T14:25:31.194035480\"}',2,'2026-07-29 14:25:31.202','2026-07-29 14:25:31'),(1289231518205296640,2082351861412769794,80001,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-07-29T14:25:46.693191907\"}',1,'2026-07-29 14:25:46.703','2026-07-29 14:25:46'),(1289233632969179137,2082353976164069378,90001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:34:10.892449932\"}',1,'2026-07-29 14:34:10.902','2026-07-29 14:34:10'),(1289233693316825088,2082354036532686850,90001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:34:25.282044382\"}',1,'2026-07-29 14:34:25.290','2026-07-29 14:34:25'),(1289233889421508609,2082354232675119105,91009,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:12.038976502\"}',1,'2026-07-29 14:35:12.045','2026-07-29 14:35:12'),(1289234211841851392,2082354549059801089,92001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:36:28.847518982\"}',1,'2026-07-29 14:36:28.913','2026-07-29 14:36:28'),(1289234462522818560,2082354799459733506,94001,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"支付失败\",\"cancelTime\":\"2026-07-29T14:37:28.601965316\"}',1,'2026-07-29 14:37:28.679','2026-07-29 14:37:28'),(1289235247130296320,2082355590371250177,20001,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"支付失败\",\"cancelTime\":\"2026-07-29T14:40:35.740961244\"}',1,'2026-07-29 14:40:35.748','2026-07-29 14:40:35'),(1289235313572265985,2082355656792248321,30001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:40:51.580758620\"}',1,'2026-07-29 14:40:51.589','2026-07-29 14:40:51'),(1289235313723260928,2082355656792248321,30001,'ORDER_REFUNDED',1,5,'{\"refundTime\":\"2026-07-29T14:40:51.620593579\"}',2,'2026-07-29 14:40:51.626','2026-07-29 14:40:51'),(1289238879154290688,2082351672551649282,80001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-29T14:55:01.681314227\"}',1,'2026-07-29 14:55:01.690','2026-07-29 14:55:01'),(1289242521785679873,2082355315078107137,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-29T15:09:30.149669302\"}',1,'2026-07-29 15:09:30.161','2026-07-29 15:09:30'),(1289254897415176192,2082367690804072449,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-29T15:58:40.729507783\"}',1,'2026-07-29 15:58:40.741','2026-07-29 15:58:40'),(1291050988678758400,2084171330690785282,2084171328232906753,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-03T14:55:42.193202392\"}',1,'2026-08-03 14:55:42.266','2026-08-03 14:55:42'),(1291050989114966017,2084171330690785282,2084171328232906753,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-03T14:55:42.364625885\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-03 14:55:42.372','2026-08-03 14:55:42'),(1291050989274349568,2084171330690785282,2084171328232906753,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-03T14:55:42.402648698\"}',3,'2026-08-03 14:55:42.410','2026-08-03 14:55:42'),(1291050989576339457,2084171332859240449,2084171328232906753,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-03T14:55:42.474915068\"}',1,'2026-08-03 14:55:42.482','2026-08-03 14:55:42'),(1291050990272593920,2084171333538717698,2084171328232906753,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-03T14:55:42.642315470\"}',1,'2026-08-03 14:55:42.648','2026-08-03 14:55:42'),(1291050990603943937,2084171333874262017,2084171328232906753,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"支付失败\",\"cancelTime\":\"2026-08-03T14:55:42.721415866\"}',1,'2026-08-03 14:55:42.727','2026-08-03 14:55:42'),(1291050990922711040,2084171334209806338,2084171328232906753,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-03T14:55:42.797361114\"}',1,'2026-08-03 14:55:42.803','2026-08-03 14:55:42'),(1291050991073705985,2084171334209806338,2084171328232906753,'ORDER_REFUNDED',1,5,'{\"refundTime\":\"2026-08-03T14:55:42.832815258\"}',2,'2026-08-03 14:55:42.839','2026-08-03 14:55:42'),(1291051099379023872,2084171442498347010,2084171442041151489,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-03T14:56:08.654386911\"}',1,'2026-08-03 14:56:08.662','2026-08-03 14:56:08'),(1291051099559378945,2084171442498347010,2084171442041151489,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-03T14:56:08.698346758\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-03 14:56:08.704','2026-08-03 14:56:08'),(1291051099689402368,2084171442498347010,2084171442041151489,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-03T14:56:08.728171471\"}',3,'2026-08-03 14:56:08.735','2026-08-03 14:56:08'),(1291051099945254913,2084171443244933121,2084171442041151489,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-03T14:56:08.791852701\"}',1,'2026-08-03 14:56:08.797','2026-08-03 14:56:08'),(1291051100217884672,2084171443542728705,2084171442041151489,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-03T14:56:08.857129578\"}',1,'2026-08-03 14:56:08.862','2026-08-03 14:56:08'),(1291051100448571393,2084171443773415425,2084171442041151489,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"支付失败\",\"cancelTime\":\"2026-08-03T14:56:08.910474850\"}',1,'2026-08-03 14:56:08.916','2026-08-03 14:56:08'),(1291051100733784064,2084171444050239489,2084171442041151489,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-03T14:56:08.979549303\"}',1,'2026-08-03 14:56:08.984','2026-08-03 14:56:08'),(1291051100884779009,2084171444050239489,2084171442041151489,'ORDER_REFUNDED',1,5,'{\"refundTime\":\"2026-08-03T14:56:09.013085634\"}',2,'2026-08-03 14:56:09.019','2026-08-03 14:56:09'),(1291092136017346560,2084212478574653441,2084212477404413953,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-03T17:39:12.523559431\"}',1,'2026-08-03 17:39:12.556','2026-08-03 17:39:12'),(1291092136399028225,2084212478574653441,2084212477404413953,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-03T17:39:12.639208029\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-03 17:39:12.648','2026-08-03 17:39:12'),(1291092136587771904,2084212478574653441,2084212477404413953,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-03T17:39:12.686731300\"}',3,'2026-08-03 17:39:12.694','2026-08-03 17:39:12'),(1291092136965259265,2084212480189460482,2084212477404413953,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-03T17:39:12.774195538\"}',1,'2026-08-03 17:39:12.784','2026-08-03 17:39:12'),(1291361198345633793,2084481541477552129,2084481541045514241,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-04T11:28:22.009375243\"}',1,'2026-08-04 11:28:22.016','2026-08-04 11:28:22'),(1291361198517600256,2084481541477552129,2084481541045514241,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-04T11:28:22.052070631\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-04 11:28:22.057','2026-08-04 11:28:22'),(1291361198651817985,2084481541477552129,2084481541045514241,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-04T11:28:22.083194845\"}',3,'2026-08-04 11:28:22.089','2026-08-04 11:28:22'),(1291361198882504704,2084481542207361026,2084481541045514241,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-04T11:28:22.139494807\"}',1,'2026-08-04 11:28:22.144','2026-08-04 11:28:22'),(1291362566364020737,2084482909516910593,2084482909093261313,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-04T11:33:48.170434968\"}',1,'2026-08-04 11:33:48.177','2026-08-04 11:33:48'),(1291362566535987200,2084482909516910593,2084482909093261313,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-04T11:33:48.213173474\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-04 11:33:48.218','2026-08-04 11:33:48'),(1291362566653427713,2084482909516910593,2084482909093261313,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-04T11:33:48.241296548\"}',3,'2026-08-04 11:33:48.246','2026-08-04 11:33:48'),(1291362566892503040,2084482910217359362,2084482909093261313,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-04T11:33:48.298785578\"}',1,'2026-08-04 11:33:48.303','2026-08-04 11:33:48'),(1291363240816492545,2084483583981965313,2084483583558316033,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-04T11:36:28.972759472\"}',1,'2026-08-04 11:36:28.979','2026-08-04 11:36:28'),(1291363240975876096,2084483583981965313,2084483583558316033,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-04T11:36:29.013180205\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-04 11:36:29.018','2026-08-04 11:36:29'),(1291363241093316609,2084483583981965313,2084483583558316033,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-04T11:36:29.040970104\"}',3,'2026-08-04 11:36:29.045','2026-08-04 11:36:29'),(1291363241298837504,2084483584636276737,2084483583558316033,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-04T11:36:29.090074328\"}',1,'2026-08-04 11:36:29.094','2026-08-04 11:36:29'),(1292415673273499648,2085535516037488642,10001,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-07T09:18:28.368171100\"}',1,'2026-08-07 09:18:28.428','2026-08-07 09:18:28'),(1292417010556026880,2085537313141624834,10001,'ORDER_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T09:23:47.213477568\",\"cancelReason\":\"用户主动取消\"}',1,'2026-08-07 09:23:47.261','2026-08-07 09:23:47'),(1292418917928353792,2085539004578545666,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T09:31:21.966773594\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 09:31:22.014','2026-08-07 09:31:22'),(1292419110367215617,2085531903223463938,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T09:32:07.886864352\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 09:32:07.897','2026-08-07 09:32:07'),(1292421856529039360,2085534644842811393,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T09:43:02.623195816\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 09:43:02.633','2026-08-07 09:43:02'),(1292442268289810433,2085562359503405057,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T11:04:09.162975185\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 11:04:09.176','2026-08-07 11:04:09'),(1292442419804848128,2085562511144271874,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T11:04:45.292399340\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 11:04:45.300','2026-08-07 11:04:45'),(1292443938126118913,2085564029503291393,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T11:10:47.286417587\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 11:10:47.296','2026-08-07 11:10:47'),(1292444209359175680,2085564300690210818,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T11:11:51.938704536\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 11:11:51.963','2026-08-07 11:11:51'),(1292445380870225921,2085565472364838913,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T11:16:31.265017632\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 11:16:31.273','2026-08-07 11:16:31'),(1292468325449547776,2085588519922712577,10001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-07T12:47:41.666267042\"}',1,'2026-08-07 12:47:41.687','2026-08-07 12:47:41'),(1292468960991461377,2085588519922712577,10001,'ORDER_DELIVERED',1,2,'{\"trackingNo\":\"SF123456789\",\"logisticsCompany\":\"顺丰\",\"deliveredTime\":\"2026-08-07T12:50:13.199824971\"}',2,'2026-08-07 12:50:13.211','2026-08-07 12:50:13'),(1292468961176010752,2085588519922712577,10001,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-07T12:50:13.248094542\"}',3,'2026-08-07 12:50:13.256','2026-08-07 12:50:13'),(1292470038130671616,2085590374643924993,10001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-07T12:54:29.936164573\"}',1,'2026-08-07 12:54:30.018','2026-08-07 12:54:30'),(1292470038709485569,2085590374643924993,10001,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"顺丰\",\"trackingNo\":\"SF999\",\"deliveredTime\":\"2026-08-07T12:54:30.143896017\"}',2,'2026-08-07 12:54:30.159','2026-08-07 12:54:30'),(1292470104111267840,2085590374643924993,10001,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-07T12:54:45.742619566\"}',3,'2026-08-07 12:54:45.753','2026-08-07 12:54:45'),(1292474090386178049,2085594181637505025,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T13:10:36.145278754\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 13:10:36.154','2026-08-07 13:10:36'),(1292476176146448384,2085596262905774082,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-07T13:18:53.363478954\"}',1,'2026-08-07 13:18:53.437','2026-08-07 13:18:53'),(1292511486913888257,2085631829903245313,10001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-07T15:39:12.167596247\"}',1,'2026-08-07 15:39:12.181','2026-08-07 15:39:12'),(1292511629159514112,2085631963915452418,10001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-07T15:39:46.087891664\"}',1,'2026-08-07 15:39:46.096','2026-08-07 15:39:46'),(1292511737838125057,2085631829332819969,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-07T15:40:11.998966939\"}',1,'2026-08-07 15:40:12.007','2026-08-07 15:40:12'),(1292512701252976640,2085632792714117122,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-07T15:44:01.692479968\"}',1,'2026-08-07 15:44:01.702','2026-08-07 15:44:01'),(1292518085858508800,2085638172626165762,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-08-07T16:05:25.443013539\",\"cancelReason\":\"超时未支付\"}',1,'2026-08-07 16:05:25.491','2026-08-07 16:05:25'),(1292518773871165440,2085638860609470466,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-07T16:08:09.475726244\"}',1,'2026-08-07 16:08:09.526','2026-08-07 16:08:09'),(1292522036788019200,2085639989166637057,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-07T16:21:07.302401401\"}',1,'2026-08-07 16:21:07.422','2026-08-07 16:21:07'),(1292522349754400769,2085642441198702594,10001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-07T16:22:22.074863011\"}',1,'2026-08-07 16:22:22.084','2026-08-07 16:22:22'),(1292524274147213312,2085643051075674114,10001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-07T16:30:00.837355724\"}',1,'2026-08-07 16:30:00.893','2026-08-07 16:30:00'),(1292528299466899457,2085646961035223041,10001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-07T16:46:00.595947652\"}',1,'2026-08-07 16:46:00.606','2026-08-07 16:46:00');
/*!40000 ALTER TABLE `t_order_event_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_1`
--

DROP TABLE IF EXISTS `t_order_event_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_1` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289241764084662273 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_1`
--

LOCK TABLES `t_order_event_1` WRITE;
/*!40000 ALTER TABLE `t_order_event_1` DISABLE KEYS */;
INSERT INTO `t_order_event_1` VALUES (1289216328759853057,2082329118126428162,20005,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-07-29T13:25:25.249020480\",\"cancelReason\":\"超时未支付\"}',1,'2026-07-29 13:25:25.257','2026-07-29 13:25:25'),(1289233695007129600,2082354038248157185,90005,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:34:25.686973922\"}',1,'2026-07-29 14:34:25.693','2026-07-29 14:34:25'),(1289234481925668864,2082354825120485377,94005,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:37:33.301411905\"}',1,'2026-07-29 14:37:33.309','2026-07-29 14:37:33'),(1289241764084662272,2082354557347745793,92005,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-29T15:06:29.504944476\"}',1,'2026-07-29 15:06:29.511','2026-07-29 15:06:29');
/*!40000 ALTER TABLE `t_order_event_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_2`
--

DROP TABLE IF EXISTS `t_order_event_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_2` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1291421314692497409 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_2`
--

LOCK TABLES `t_order_event_2` WRITE;
/*!40000 ALTER TABLE `t_order_event_2` DISABLE KEYS */;
INSERT INTO `t_order_event_2` VALUES (1289233886263197697,2082354229479059458,91001,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:11.281569071\"}',1,'2026-07-29 14:35:11.292','2026-07-29 14:35:11'),(1291421314365341696,2084534107892666369,1001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-04T15:27:14.767057985\"}',1,'2026-08-04 15:27:14.791','2026-08-04 15:27:14'),(1291421314424061953,2084534107729088513,1001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-04T15:27:14.767651515\"}',1,'2026-08-04 15:27:14.807','2026-08-04 15:27:14'),(1291421314692497408,2084534108052049921,1001,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-04T15:27:14.864722071\"}',1,'2026-08-04 15:27:14.870','2026-08-04 15:27:14');
/*!40000 ALTER TABLE `t_order_event_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_3`
--

DROP TABLE IF EXISTS `t_order_event_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_3` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289233887882199042 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_3`
--

LOCK TABLES `t_order_event_3` WRITE;
/*!40000 ALTER TABLE `t_order_event_3` DISABLE KEYS */;
INSERT INTO `t_order_event_3` VALUES (1289233887882199041,2082354231110643714,91005,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:11.670427888\"}',1,'2026-07-29 14:35:11.677','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_event_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_0`
--

DROP TABLE IF EXISTS `t_order_item_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_0` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_0`
--

LOCK TABLES `t_order_item_0` WRITE;
/*!40000 ALTER TABLE `t_order_item_0` DISABLE KEYS */;
INSERT INTO `t_order_item_0` VALUES (2076150662460203010,2076150660723761154,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 11:44:25'),(2076151574658334722,2076151572980613121,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 11:48:03'),(2076169498060169217,2076169498030809089,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 12:59:16'),(2076169592905965569,2076169592889188354,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 12:59:38'),(2076169644135194626,2076169644114223106,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 12:59:51'),(2076173837382230017,2076173837361258497,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 13:16:30'),(2076174885811429377,2076174885794652161,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 13:20:40'),(2076175112240930817,2076175112224153601,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 13:21:34'),(2076175587082280961,2076175587065503746,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 13:23:28'),(2076177245082263553,2076177245061292033,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 13:30:03'),(2076177245208092674,2076177245199704065,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 13:30:03'),(2076177245338116098,2076177245329727490,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 13:30:03'),(2076177245472333825,2076177245459750914,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 13:30:03'),(2076177245589774338,2076177245581385730,10001,1,1,'Mock商品-1','https://img.mock.com/sku/1.jpg',99.00,1,99.00,'2026-07-12 13:30:03'),(2082305391326187521,2082305390969671681,20001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 11:21:07'),(2082307019961847809,2082307019940876290,20001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-07-29 11:27:35'),(2082329674362454018,2082329674207264770,30001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 12:57:36'),(2082329775709421569,2082329775684255745,40001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 12:58:01'),(2082350109288366081,2082350109250617345,50001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:18:48'),(2082350632787836930,2082350632766865409,60001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-07-29 14:20:53'),(2082350998682185729,2082350994844397570,70001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:22:20'),(2082351672576815105,2082351672551649282,80001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:25:01'),(2082351748531466242,2082351748510494721,80001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:25:19'),(2082351861429547010,2082351861412769794,80001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:25:46'),(2082353976180846593,2082353976164069378,90001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:34:10'),(2082354036549464065,2082354036532686850,90001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:34:25'),(2082354232691896322,2082354232675119105,91009,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:12'),(2082354553304436738,2082354549059801089,92001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:36:28'),(2082354803863752705,2082354799459733506,94001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:37:28'),(2082355315094884354,2082355315078107137,10001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:39:30'),(2082355590388027393,2082355590371250177,20001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:40:35'),(2082355656804831233,2082355656792248321,30001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:40:51'),(2082367690816655362,2082367690804072449,10001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 15:28:40'),(2084171331055689729,2084171330690785282,2084171328232906753,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-03 14:55:42'),(2084171332876017665,2084171332859240449,2084171328232906753,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 14:55:42'),(2084171333551300610,2084171333538717698,2084171328232906753,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 14:55:42'),(2084171333895233537,2084171333874262017,2084171328232906753,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 14:55:42'),(2084171334222389249,2084171334209806338,2084171328232906753,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 14:55:42'),(2084171442510929922,2084171442498347010,2084171442041151489,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-03 14:56:08'),(2084171443249127425,2084171443244933121,2084171442041151489,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 14:56:08'),(2084171443551117314,2084171443542728705,2084171442041151489,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 14:56:08'),(2084171443781804033,2084171443773415425,2084171442041151489,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 14:56:08'),(2084171444062822401,2084171444050239489,2084171442041151489,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 14:56:08'),(2084212478675316737,2084212478574653441,2084212477404413953,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-03 17:39:12'),(2084212480206237698,2084212480189460482,2084212477404413953,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 17:39:12'),(2084481541490135041,2084481541477552129,2084481541045514241,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-04 11:28:21'),(2084481542215749633,2084481542207361026,2084481541045514241,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-04 11:28:22'),(2084482909529493506,2084482909516910593,2084482909093261313,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-04 11:33:48'),(2084482910225747970,2084482910217359362,2084482909093261313,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-04 11:33:48'),(2084483583990353922,2084483583981965313,2084483583558316033,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-04 11:36:28'),(2084483584648859649,2084483584636276737,2084483583558316033,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-04 11:36:29'),(2085531903487705090,2085531903223463938,10001,2085530413171785729,2085530413171785729,'Mock商品-2085530413171785729','https://img.mock.com/sku/2085530413171785729.jpg',99.00,1,99.00,'2026-08-07 09:02:07'),(2085534649875976194,2085534644842811393,10001,2085530413171785729,2085530413171785729,'Mock商品-2085530413171785729','https://img.mock.com/sku/2085530413171785729.jpg',99.00,1,99.00,'2026-08-07 09:13:02'),(2085535520399564802,2085535516037488642,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 09:16:30'),(2085537317495312385,2085537313141624834,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 09:23:38'),(2085539008940621825,2085539004578545666,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 09:30:21'),(2085562359637622786,2085562359503405057,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,2,59.80,'2026-08-07 11:03:09'),(2085562511161049089,2085562511144271874,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,2,59.80,'2026-08-07 11:03:45'),(2085564029520068609,2085564029503291393,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,3,89.70,'2026-08-07 11:09:47'),(2085564300706988034,2085564300690210818,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,3,89.70,'2026-08-07 11:10:51'),(2085565472385810434,2085565472364838913,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,2,59.80,'2026-08-07 11:15:31'),(2085588520077901825,2085588519922712577,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,2,59.80,'2026-08-07 12:47:06'),(2085590378985029633,2085590374643924993,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 12:54:29'),(2085594181675253761,2085594181637505025,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,9999,298970.10,'2026-08-07 13:09:36'),(2085596267225907201,2085596262905774082,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 13:17:53'),(2085631829362180098,2085631829332819969,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 15:39:11'),(2085631829928411138,2085631829903245313,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 15:39:12'),(2085631963932229633,2085631963915452418,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 15:39:44'),(2085632792730894337,2085632792714117122,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 15:43:01'),(2085638177005019137,2085638172626165762,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 16:04:25'),(2085638864900243458,2085638860609470466,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 16:07:09'),(2085639994279493633,2085639989166637057,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 16:11:38'),(2085642441228062721,2085642441198702594,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 16:21:22'),(2085643055618105345,2085643051075674114,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 16:23:48'),(2085646961052000257,2085646961035223041,10001,2085530413171785729,2085352027803664385,'P06测试SKU',NULL,29.90,1,29.90,'2026-08-07 16:39:19');
/*!40000 ALTER TABLE `t_order_item_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_1`
--

DROP TABLE IF EXISTS `t_order_item_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_1` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_1`
--

LOCK TABLES `t_order_item_1` WRITE;
/*!40000 ALTER TABLE `t_order_item_1` DISABLE KEYS */;
INSERT INTO `t_order_item_1` VALUES (2082329122001965058,2082329118126428162,20005,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 12:55:25'),(2082354038264934401,2082354038248157185,90005,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:34:25'),(2082354557368717314,2082354557347745793,92005,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:36:29'),(2082354825137262594,2082354825120485377,94005,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_item_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_2`
--

DROP TABLE IF EXISTS `t_order_item_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_2` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_2`
--

LOCK TABLES `t_order_item_2` WRITE;
/*!40000 ALTER TABLE `t_order_item_2` DISABLE KEYS */;
INSERT INTO `t_order_item_2` VALUES (2082354229500030977,2082354229479059458,91001,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:11'),(2084534107771031554,2084534107729088513,1001,2084534106126888961,2084534106126888961,'Mock商品-2084534106126888961','https://img.mock.com/sku/2084534106126888961.jpg',99.00,1,99.00,'2026-08-04 14:57:14'),(2084534107901054977,2084534107892666369,1001,2084534106550513665,2084534106550513665,'Mock商品-2084534106550513665','https://img.mock.com/sku/2084534106550513665.jpg',99.00,1,99.00,'2026-08-04 14:57:14'),(2084534108081410050,2084534108052049921,1001,2084534106726674433,2084534106726674433,'Mock商品-2084534106726674433','https://img.mock.com/sku/2084534106726674433.jpg',99.00,1,99.00,'2026-08-04 14:57:14');
/*!40000 ALTER TABLE `t_order_item_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_3`
--

DROP TABLE IF EXISTS `t_order_item_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_3` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_3`
--

LOCK TABLES `t_order_item_3` WRITE;
/*!40000 ALTER TABLE `t_order_item_3` DISABLE KEYS */;
INSERT INTO `t_order_item_3` VALUES (2082354231123226626,2082354231110643714,91005,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_item_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_0`
--

DROP TABLE IF EXISTS `t_order_snapshot_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_0` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_0`
--

LOCK TABLES `t_order_snapshot_0` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_0` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_0` VALUES (2076158215696982017,2076150660723761154,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076150660723761154,\"userId\":10001,\"orderNo\":\"ORD2026071211442511000010002\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 11:44:25\",\"updatedAt\":\"2026-07-12 12:14:26\"},\"items\":[{\"id\":2076150662460203010,\"orderId\":2076150660723761154,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 11:44:25\"}],\"timestamp\":\"2026-07-12T12:14:26.424082480\"}','2026-07-12 12:14:26'),(2076159124657184770,2076151572980613121,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076151572980613121,\"userId\":10001,\"orderNo\":\"ORD2026071211480262300010003\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 11:48:03\",\"updatedAt\":\"2026-07-12 12:18:03\"},\"items\":[{\"id\":2076151574658334722,\"orderId\":2076151572980613121,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 11:48:03\"}],\"timestamp\":\"2026-07-12T12:18:03.146820490\"}','2026-07-12 12:18:03'),(2076169498177609729,2076169498030809089,10001,'CREATED','{\"order\":{\"id\":2076169498030809089,\"userId\":10001,\"orderNo\":\"ORD2026071212591630100010006\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 12:59:16\",\"updatedAt\":\"2026-07-12 12:59:16\"},\"items\":[{\"id\":2076169498060169217,\"orderId\":2076169498030809089,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 12:59:16\"}],\"timestamp\":\"2026-07-12T12:59:16.386762718\"}','2026-07-12 12:59:16'),(2076169592973074434,2076169592889188354,10001,'CREATED','{\"order\":{\"id\":2076169592889188354,\"userId\":10001,\"orderNo\":\"ORD2026071212593896300010007\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 12:59:38\",\"updatedAt\":\"2026-07-12 12:59:38\"},\"items\":[{\"id\":2076169592905965569,\"orderId\":2076169592889188354,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 12:59:38\"}],\"timestamp\":\"2026-07-12T12:59:38.987789465\"}','2026-07-12 12:59:38'),(2076169644198109185,2076169644114223106,10001,'CREATED','{\"order\":{\"id\":2076169644114223106,\"userId\":10001,\"orderNo\":\"ORD2026071212595117700010008\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 12:59:51\",\"updatedAt\":\"2026-07-12 12:59:51\"},\"items\":[{\"id\":2076169644135194626,\"orderId\":2076169644114223106,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 12:59:51\"}],\"timestamp\":\"2026-07-12T12:59:51.200541482\"}','2026-07-12 12:59:51'),(2076169785961390082,2076169644114223106,10001,'CANCELLED','{\"order\":{\"id\":2076169644114223106,\"userId\":10001,\"orderNo\":\"ORD2026071212595117700010008\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 12:59:51\",\"updatedAt\":\"2026-07-12 13:00:24\"},\"items\":[{\"id\":2076169644135194626,\"orderId\":2076169644114223106,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 12:59:51\"}],\"timestamp\":\"2026-07-12T13:00:24.999005376\"}','2026-07-12 13:00:25'),(2076173837428367362,2076173837361258497,10001,'CREATED','{\"order\":{\"id\":2076173837361258497,\"userId\":10001,\"orderNo\":\"ORD2026071213163092600010009\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:16:30\",\"updatedAt\":\"2026-07-12 13:16:30\"},\"items\":[{\"id\":2076173837382230017,\"orderId\":2076173837361258497,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:16:30\"}],\"timestamp\":\"2026-07-12T13:16:30.944422130\"}','2026-07-12 13:16:30'),(2076174885861761026,2076174885794652161,10001,'CREATED','{\"order\":{\"id\":2076174885794652161,\"userId\":10001,\"orderNo\":\"ORD2026071213204089200010010\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:20:40\",\"updatedAt\":\"2026-07-12 13:20:40\"},\"items\":[{\"id\":2076174885811429377,\"orderId\":2076174885794652161,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:20:40\"}],\"timestamp\":\"2026-07-12T13:20:40.910603327\"}','2026-07-12 13:20:40'),(2076175112291262465,2076175112224153601,10001,'CREATED','{\"order\":{\"id\":2076175112224153601,\"userId\":10001,\"orderNo\":\"ORD2026071213213487700010011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:21:34\",\"updatedAt\":\"2026-07-12 13:21:34\"},\"items\":[{\"id\":2076175112240930817,\"orderId\":2076175112224153601,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:21:34\"}],\"timestamp\":\"2026-07-12T13:21:34.895501767\"}','2026-07-12 13:21:34'),(2076175587128418305,2076175587065503746,10001,'CREATED','{\"order\":{\"id\":2076175587065503746,\"userId\":10001,\"orderNo\":\"ORD2026071213232808800010012\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:23:28\",\"updatedAt\":\"2026-07-12 13:23:28\"},\"items\":[{\"id\":2076175587082280961,\"orderId\":2076175587065503746,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:23:28\"}],\"timestamp\":\"2026-07-12T13:23:28.105688626\"}','2026-07-12 13:23:28'),(2076177245124206593,2076177245061292033,10001,'CREATED','{\"order\":{\"id\":2076177245061292033,\"userId\":10001,\"orderNo\":\"ORD2026071213300338400010013\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 13:30:03\"},\"items\":[{\"id\":2076177245082263553,\"orderId\":2076177245061292033,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T13:30:03.402958499\"}','2026-07-12 13:30:03'),(2076177245262618625,2076177245199704065,10001,'CREATED','{\"order\":{\"id\":2076177245199704065,\"userId\":10001,\"orderNo\":\"ORD2026071213300341800010014\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 13:30:03\"},\"items\":[{\"id\":2076177245208092674,\"orderId\":2076177245199704065,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T13:30:03.435298065\"}','2026-07-12 13:30:03'),(2076177245384253442,2076177245329727490,10001,'CREATED','{\"order\":{\"id\":2076177245329727490,\"userId\":10001,\"orderNo\":\"ORD2026071213300345000010015\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 13:30:03\"},\"items\":[{\"id\":2076177245338116098,\"orderId\":2076177245329727490,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T13:30:03.464599372\"}','2026-07-12 13:30:03'),(2076177245514276865,2076177245459750914,10001,'CREATED','{\"order\":{\"id\":2076177245459750914,\"userId\":10001,\"orderNo\":\"ORD2026071213300348000010016\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 13:30:03\"},\"items\":[{\"id\":2076177245472333825,\"orderId\":2076177245459750914,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T13:30:03.495200232\"}','2026-07-12 13:30:03'),(2076177245627523074,2076177245581385730,10001,'CREATED','{\"order\":{\"id\":2076177245581385730,\"userId\":10001,\"orderNo\":\"ORD2026071213300351000010017\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 13:30:03\"},\"items\":[{\"id\":2076177245589774338,\"orderId\":2076177245581385730,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T13:30:03.522661455\"}','2026-07-12 13:30:03'),(2076180617655001090,2076175587065503746,10001,'PAID','{\"order\":{\"id\":2076175587065503746,\"userId\":10001,\"orderNo\":\"ORD2026071213232808800010012\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:23:28\",\"updatedAt\":\"2026-07-12 13:43:27\"},\"items\":[{\"id\":2076175587082280961,\"orderId\":2076175587065503746,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:23:28\"}],\"timestamp\":\"2026-07-12T13:43:27.474156407\"}','2026-07-12 13:43:27'),(2076180617839550465,2076175587065503746,10001,'DELIVERED','{\"order\":{\"id\":2076175587065503746,\"userId\":10001,\"orderNo\":\"ORD2026071213232808800010012\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:23:28\",\"updatedAt\":\"2026-07-12 13:43:27\"},\"items\":[{\"id\":2076175587082280961,\"orderId\":2076175587065503746,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:23:28\"}],\"timestamp\":\"2026-07-12T13:43:27.520537595\"}','2026-07-12 13:43:27'),(2076180688329023490,2076175587065503746,10001,'COMPLETED','{\"order\":{\"id\":2076175587065503746,\"userId\":10001,\"orderNo\":\"ORD2026071213232808800010012\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:23:28\",\"updatedAt\":\"2026-07-12 13:43:44\"},\"items\":[{\"id\":2076175587082280961,\"orderId\":2076175587065503746,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:23:28\"}],\"timestamp\":\"2026-07-12T13:43:44.326947297\"}','2026-07-12 13:43:44'),(2076181387381088257,2076173837361258497,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076173837361258497,\"userId\":10001,\"orderNo\":\"ORD2026071213163092600010009\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:16:30\",\"updatedAt\":\"2026-07-12 13:46:30\"},\"items\":[{\"id\":2076173837382230017,\"orderId\":2076173837361258497,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:16:30\"}],\"timestamp\":\"2026-07-12T13:46:30.993780637\"}','2026-07-12 13:46:30'),(2076182435873202178,2076174885794652161,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076174885794652161,\"userId\":10001,\"orderNo\":\"ORD2026071213204089200010010\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:20:40\",\"updatedAt\":\"2026-07-12 13:50:40\"},\"items\":[{\"id\":2076174885811429377,\"orderId\":2076174885794652161,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:20:40\"}],\"timestamp\":\"2026-07-12T13:50:40.973655541\"}','2026-07-12 13:50:40'),(2076182662495641602,2076175112224153601,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076175112224153601,\"userId\":10001,\"orderNo\":\"ORD2026071213213487700010011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:21:34\",\"updatedAt\":\"2026-07-12 13:51:34\"},\"items\":[{\"id\":2076175112240930817,\"orderId\":2076175112224153601,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:21:34\"}],\"timestamp\":\"2026-07-12T13:51:35.004655302\"}','2026-07-12 13:51:35'),(2076184795282448386,2076177245061292033,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076177245061292033,\"userId\":10001,\"orderNo\":\"ORD2026071213300338400010013\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 14:00:03\"},\"items\":[{\"id\":2076177245082263553,\"orderId\":2076177245061292033,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T14:00:03.500309801\"}','2026-07-12 14:00:03'),(2076184795290836994,2076177245199704065,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076177245199704065,\"userId\":10001,\"orderNo\":\"ORD2026071213300341800010014\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 14:00:03\"},\"items\":[{\"id\":2076177245208092674,\"orderId\":2076177245199704065,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T14:00:03.502819311\"}','2026-07-12 14:00:03'),(2076184795659935746,2076177245329727490,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076177245329727490,\"userId\":10001,\"orderNo\":\"ORD2026071213300345000010015\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 14:00:03\"},\"items\":[{\"id\":2076177245338116098,\"orderId\":2076177245329727490,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T14:00:03.590629857\"}','2026-07-12 14:00:03'),(2076184795697684482,2076177245581385730,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076177245581385730,\"userId\":10001,\"orderNo\":\"ORD2026071213300351000010017\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 14:00:03\"},\"items\":[{\"id\":2076177245589774338,\"orderId\":2076177245581385730,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T14:00:03.599069178\"}','2026-07-12 14:00:03'),(2076184795727044610,2076177245459750914,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2076177245459750914,\"userId\":10001,\"orderNo\":\"ORD2026071213300348000010016\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 13:30:03\",\"updatedAt\":\"2026-07-12 14:00:03\"},\"items\":[{\"id\":2076177245472333825,\"orderId\":2076177245459750914,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 13:30:03\"}],\"timestamp\":\"2026-07-12T14:00:03.606644797\"}','2026-07-12 14:00:03'),(2076226823718498306,2076169592889188354,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-07-12T16:47:03.845831416\",\"items\":[{\"id\":2076169592905965569,\"orderId\":2076169592889188354,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 12:59:38\"}],\"order\":{\"id\":2076169592889188354,\"userId\":10001,\"orderNo\":\"ORD2026071212593896300010007\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 12:59:38\",\"updatedAt\":\"2026-07-12 16:47:03\"}}','2026-07-12 16:47:03'),(2076226823718498307,2076169498030809089,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-07-12T16:47:03.845831477\",\"items\":[{\"id\":2076169498060169217,\"orderId\":2076169498030809089,\"userId\":10001,\"skuId\":1,\"spuId\":1,\"skuName\":\"Mock商品-1\",\"skuImage\":\"https://img.mock.com/sku/1.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-12 12:59:16\"}],\"order\":{\"id\":2076169498030809089,\"userId\":10001,\"orderNo\":\"ORD2026071212591630100010006\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-12 12:59:16\",\"updatedAt\":\"2026-07-12 16:47:03\"}}','2026-07-12 16:47:03'),(2082305391703674882,2082305390969671681,20001,'CREATED','{\"items\":[{\"id\":2082305391326187521,\"orderId\":2082305390969671681,\"userId\":20001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 11:21:07\"}],\"order\":{\"id\":2082305390969671681,\"userId\":20001,\"orderNo\":\"ORD2026072911210714700010001\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 11:21:07\",\"updatedAt\":\"2026-07-29 11:21:07\"},\"timestamp\":\"2026-07-29T11:21:07.391479517\"}','2026-07-29 11:21:07'),(2082307020058316802,2082307019940876290,20001,'CREATED','{\"items\":[{\"id\":2082307019961847809,\"orderId\":2082307019940876290,\"userId\":20001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-07-29 11:27:35\"}],\"order\":{\"id\":2082307019940876290,\"userId\":20001,\"orderNo\":\"ORD2026072911273560200010002\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 11:27:35\",\"updatedAt\":\"2026-07-29 11:27:35\"},\"timestamp\":\"2026-07-29T11:27:35.632553360\"}','2026-07-29 11:27:35'),(2082312942113574914,2082305390969671681,20001,'TIMEOUT_CANCELLED','{\"items\":[{\"id\":2082305391326187521,\"orderId\":2082305390969671681,\"userId\":20001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 11:21:07\"}],\"order\":{\"id\":2082305390969671681,\"userId\":20001,\"orderNo\":\"ORD2026072911210714700010001\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 11:21:07\",\"updatedAt\":\"2026-07-29 11:51:07\"},\"timestamp\":\"2026-07-29T11:51:07.560309469\"}','2026-07-29 11:51:07'),(2082314570094923778,2082307019940876290,20001,'TIMEOUT_CANCELLED','{\"items\":[{\"id\":2082307019961847809,\"orderId\":2082307019940876290,\"userId\":20001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-07-29 11:27:35\"}],\"order\":{\"id\":2082307019940876290,\"userId\":20001,\"orderNo\":\"ORD2026072911273560200010002\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 11:27:35\",\"updatedAt\":\"2026-07-29 11:57:35\"},\"timestamp\":\"2026-07-29T11:57:35.701661752\"}','2026-07-29 11:57:35'),(2082329674492477441,2082329674207264770,30001,'CREATED','{\"order\":{\"id\":2082329674207264770,\"userId\":30001,\"orderNo\":\"ORD2026072912573675600010006\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:57:36\",\"updatedAt\":\"2026-07-29 12:57:36\"},\"timestamp\":\"2026-07-29T12:57:36.868571340\",\"items\":[{\"id\":2082329674362454018,\"orderId\":2082329674207264770,\"userId\":30001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:57:36\"}]}','2026-07-29 12:57:36'),(2082329675394252802,2082329674207264770,30001,'CANCELLED','{\"order\":{\"id\":2082329674207264770,\"userId\":30001,\"orderNo\":\"ORD2026072912573675600010006\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:57:36\",\"updatedAt\":\"2026-07-29 12:57:37\"},\"timestamp\":\"2026-07-29T12:57:37.085390952\",\"items\":[{\"id\":2082329674362454018,\"orderId\":2082329674207264770,\"userId\":30001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:57:36\"}]}','2026-07-29 12:57:37'),(2082329775780724738,2082329775684255745,40001,'CREATED','{\"order\":{\"id\":2082329775684255745,\"userId\":40001,\"orderNo\":\"ORD2026072912580099500010007\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:58:01\",\"updatedAt\":\"2026-07-29 12:58:01\"},\"timestamp\":\"2026-07-29T12:58:01.020363749\",\"items\":[{\"id\":2082329775709421569,\"orderId\":2082329775684255745,\"userId\":40001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:58:01\"}]}','2026-07-29 12:58:01'),(2082329776036577281,2082329775684255745,40001,'PAID','{\"order\":{\"id\":2082329775684255745,\"userId\":40001,\"orderNo\":\"ORD2026072912580099500010007\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:58:01\",\"updatedAt\":\"2026-07-29 12:58:01\"},\"timestamp\":\"2026-07-29T12:58:01.080385998\",\"items\":[{\"id\":2082329775709421569,\"orderId\":2082329775684255745,\"userId\":40001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:58:01\"}]}','2026-07-29 12:58:01'),(2082329776258875393,2082329775684255745,40001,'DELIVERED','{\"order\":{\"id\":2082329775684255745,\"userId\":40001,\"orderNo\":\"ORD2026072912580099500010007\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:58:01\",\"updatedAt\":\"2026-07-29 12:58:01\"},\"timestamp\":\"2026-07-29T12:58:01.133637530\",\"items\":[{\"id\":2082329775709421569,\"orderId\":2082329775684255745,\"userId\":40001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:58:01\"}]}','2026-07-29 12:58:01'),(2082329776435036162,2082329775684255745,40001,'COMPLETED','{\"order\":{\"id\":2082329775684255745,\"userId\":40001,\"orderNo\":\"ORD2026072912580099500010007\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:58:01\",\"updatedAt\":\"2026-07-29 12:58:01\"},\"timestamp\":\"2026-07-29T12:58:01.174182882\",\"items\":[{\"id\":2082329775709421569,\"orderId\":2082329775684255745,\"userId\":40001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:58:01\"}]}','2026-07-29 12:58:01'),(2082350109347086337,2082350109250617345,50001,'CREATED','{\"order\":{\"id\":2082350109250617345,\"userId\":50001,\"orderNo\":\"ORD2026072914184889400010008\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:18:48\",\"updatedAt\":\"2026-07-29 14:18:48\"},\"timestamp\":\"2026-07-29T14:18:48.919454083\",\"items\":[{\"id\":2082350109288366081,\"orderId\":2082350109250617345,\"userId\":50001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:18:48\"}]}','2026-07-29 14:18:48'),(2082350109565190146,2082350109250617345,50001,'PAID','{\"order\":{\"id\":2082350109250617345,\"userId\":50001,\"orderNo\":\"ORD2026072914184889400010008\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:18:48\",\"updatedAt\":\"2026-07-29 14:18:48\"},\"timestamp\":\"2026-07-29T14:18:48.970896236\",\"items\":[{\"id\":2082350109288366081,\"orderId\":2082350109250617345,\"userId\":50001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:18:48\"}]}','2026-07-29 14:18:48'),(2082350632838168578,2082350632766865409,60001,'CREATED','{\"order\":{\"id\":2082350632766865409,\"userId\":60001,\"orderNo\":\"ORD2026072914205371000010010\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:20:53\",\"updatedAt\":\"2026-07-29 14:20:53\"},\"timestamp\":\"2026-07-29T14:20:53.729730473\",\"items\":[{\"id\":2082350632787836930,\"orderId\":2082350632766865409,\"userId\":60001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-07-29 14:20:53\"}]}','2026-07-29 14:20:53'),(2082350633035300865,2082350632766865409,60001,'PAID','{\"order\":{\"id\":2082350632766865409,\"userId\":60001,\"orderNo\":\"ORD2026072914205371000010010\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:20:53\",\"updatedAt\":\"2026-07-29 14:20:53\"},\"timestamp\":\"2026-07-29T14:20:53.776945477\",\"items\":[{\"id\":2082350632787836930,\"orderId\":2082350632766865409,\"userId\":60001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-07-29 14:20:53\"}]}','2026-07-29 14:20:53'),(2082350633207267329,2082350632766865409,60001,'REFUNDED','{\"order\":{\"id\":2082350632766865409,\"userId\":60001,\"orderNo\":\"ORD2026072914205371000010010\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":5,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:20:53\",\"updatedAt\":\"2026-07-29 14:20:53\"},\"timestamp\":\"2026-07-29T14:20:53.817748967\",\"items\":[{\"id\":2082350632787836930,\"orderId\":2082350632766865409,\"userId\":60001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-07-29 14:20:53\"}]}','2026-07-29 14:20:53'),(2082350999869173762,2082350994844397570,70001,'CREATED','{\"timestamp\":\"2026-07-29T14:22:21.228166763\",\"order\":{\"id\":2082350994844397570,\"userId\":70001,\"orderNo\":\"ORD2026072914221996400010011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:22:20\",\"updatedAt\":\"2026-07-29 14:22:20\"},\"items\":[{\"id\":2082350998682185729,\"orderId\":2082350994844397570,\"userId\":70001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:22:20\"}]}','2026-07-29 14:22:21'),(2082351000703840257,2082350994844397570,70001,'PAID','{\"timestamp\":\"2026-07-29T14:22:21.435567543\",\"order\":{\"id\":2082350994844397570,\"userId\":70001,\"orderNo\":\"ORD2026072914221996400010011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:22:20\",\"updatedAt\":\"2026-07-29 14:22:21\"},\"items\":[{\"id\":2082350998682185729,\"orderId\":2082350994844397570,\"userId\":70001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:22:20\"}]}','2026-07-29 14:22:21'),(2082351001236516865,2082350994844397570,70001,'REFUNDED','{\"timestamp\":\"2026-07-29T14:22:21.562721127\",\"order\":{\"id\":2082350994844397570,\"userId\":70001,\"orderNo\":\"ORD2026072914221996400010011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":5,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:22:20\",\"updatedAt\":\"2026-07-29 14:22:21\"},\"items\":[{\"id\":2082350998682185729,\"orderId\":2082350994844397570,\"userId\":70001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:22:20\"}]}','2026-07-29 14:22:21'),(2082351672643923970,2082351672551649282,80001,'CREATED','{\"timestamp\":\"2026-07-29T14:25:01.638924530\",\"order\":{\"id\":2082351672551649282,\"userId\":80001,\"orderNo\":\"ORD2026072914250161400010012\",\"totalAmount\":99.00,\"payAmount\":89.00,\"discountAmount\":10.00,\"couponId\":2082351668176924674,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:25:01\",\"updatedAt\":\"2026-07-29 14:25:01\"},\"items\":[{\"id\":2082351672576815105,\"orderId\":2082351672551649282,\"userId\":80001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:25:01\"}]}','2026-07-29 14:25:01'),(2082351748615352322,2082351748510494721,80001,'CREATED','{\"timestamp\":\"2026-07-29T14:25:19.751298297\",\"order\":{\"id\":2082351748510494721,\"userId\":80001,\"orderNo\":\"ORD2026072914251972500010013\",\"totalAmount\":99.00,\"payAmount\":89.00,\"discountAmount\":10.00,\"couponId\":2082351668176924674,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:25:19\",\"updatedAt\":\"2026-07-29 14:25:19\"},\"items\":[{\"id\":2082351748531466242,\"orderId\":2082351748510494721,\"userId\":80001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:25:19\"}]}','2026-07-29 14:25:19'),(2082351796518498305,2082351748510494721,80001,'PAID','{\"timestamp\":\"2026-07-29T14:25:31.171544672\",\"order\":{\"id\":2082351748510494721,\"userId\":80001,\"orderNo\":\"ORD2026072914251972500010013\",\"totalAmount\":99.00,\"payAmount\":89.00,\"discountAmount\":10.00,\"couponId\":2082351668176924674,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:25:19\",\"updatedAt\":\"2026-07-29 14:25:31\"},\"items\":[{\"id\":2082351748531466242,\"orderId\":2082351748510494721,\"userId\":80001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:25:19\"}]}','2026-07-29 14:25:31'),(2082351796795322369,2082351748510494721,80001,'REFUNDED','{\"timestamp\":\"2026-07-29T14:25:31.236662322\",\"order\":{\"id\":2082351748510494721,\"userId\":80001,\"orderNo\":\"ORD2026072914251972500010013\",\"totalAmount\":99.00,\"payAmount\":89.00,\"discountAmount\":10.00,\"couponId\":2082351668176924674,\"status\":5,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:25:19\",\"updatedAt\":\"2026-07-29 14:25:31\"},\"items\":[{\"id\":2082351748531466242,\"orderId\":2082351748510494721,\"userId\":80001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:25:19\"}]}','2026-07-29 14:25:31'),(2082351861496655873,2082351861412769794,80001,'CREATED','{\"timestamp\":\"2026-07-29T14:25:46.662087674\",\"order\":{\"id\":2082351861412769794,\"userId\":80001,\"orderNo\":\"ORD2026072914254664200010014\",\"totalAmount\":99.00,\"payAmount\":89.00,\"discountAmount\":10.00,\"couponId\":2082351668176924674,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:25:46\",\"updatedAt\":\"2026-07-29 14:25:46\"},\"items\":[{\"id\":2082351861429547010,\"orderId\":2082351861412769794,\"userId\":80001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:25:46\"}]}','2026-07-29 14:25:46'),(2082351861760897026,2082351861412769794,80001,'CANCELLED','{\"timestamp\":\"2026-07-29T14:25:46.727298843\",\"order\":{\"id\":2082351861412769794,\"userId\":80001,\"orderNo\":\"ORD2026072914254664200010014\",\"totalAmount\":99.00,\"payAmount\":89.00,\"discountAmount\":10.00,\"couponId\":2082351668176924674,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:25:46\",\"updatedAt\":\"2026-07-29 14:25:46\"},\"items\":[{\"id\":2082351861429547010,\"orderId\":2082351861412769794,\"userId\":80001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:25:46\"}]}','2026-07-29 14:25:46'),(2082353976256344066,2082353976164069378,90001,'CREATED','{\"timestamp\":\"2026-07-29T14:34:10.863000866\",\"order\":{\"id\":2082353976164069378,\"userId\":90001,\"orderNo\":\"ORD2026072914341083800010015\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:10\",\"updatedAt\":\"2026-07-29 14:34:10\"},\"items\":[{\"id\":2082353976180846593,\"orderId\":2082353976164069378,\"userId\":90001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:10\"}]}','2026-07-29 14:34:10'),(2082353976474447874,2082353976164069378,90001,'PAID','{\"timestamp\":\"2026-07-29T14:34:10.914631700\",\"order\":{\"id\":2082353976164069378,\"userId\":90001,\"orderNo\":\"ORD2026072914341083800010015\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:10\",\"updatedAt\":\"2026-07-29 14:34:10\"},\"items\":[{\"id\":2082353976180846593,\"orderId\":2082353976164069378,\"userId\":90001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:10\"}]}','2026-07-29 14:34:10'),(2082354036616572930,2082354036532686850,90001,'CREATED','{\"timestamp\":\"2026-07-29T14:34:25.253649264\",\"order\":{\"id\":2082354036532686850,\"userId\":90001,\"orderNo\":\"ORD2026072914342523200010016\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354036549464065,\"orderId\":2082354036532686850,\"userId\":90001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354036813705218,2082354036532686850,90001,'PAID','{\"timestamp\":\"2026-07-29T14:34:25.301226185\",\"order\":{\"id\":2082354036532686850,\"userId\":90001,\"orderNo\":\"ORD2026072914342523200010016\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354036549464065,\"orderId\":2082354036532686850,\"userId\":90001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354232742227970,2082354232675119105,91009,'CREATED','{\"timestamp\":\"2026-07-29T14:35:12.013995919\",\"order\":{\"id\":2082354232675119105,\"userId\":91009,\"orderNo\":\"ORD2026072914351199610090029\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:12\",\"updatedAt\":\"2026-07-29 14:35:12\"},\"items\":[{\"id\":2082354232691896322,\"orderId\":2082354232675119105,\"userId\":91009,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:12\"}]}','2026-07-29 14:35:12'),(2082354232910000130,2082354232675119105,91009,'PAID','{\"timestamp\":\"2026-07-29T14:35:12.054126763\",\"order\":{\"id\":2082354232675119105,\"userId\":91009,\"orderNo\":\"ORD2026072914351199610090029\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:12\",\"updatedAt\":\"2026-07-29 14:35:12\"},\"items\":[{\"id\":2082354232691896322,\"orderId\":2082354232675119105,\"userId\":91009,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:12\"}]}','2026-07-29 14:35:12'),(2082354554600476673,2082354549059801089,92001,'CREATED','{\"timestamp\":\"2026-07-29T14:36:28.742401509\",\"order\":{\"id\":2082354549059801089,\"userId\":92001,\"orderNo\":\"ORD2026072914362735320010031\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:28\",\"updatedAt\":\"2026-07-29 14:36:28\"},\"items\":[{\"id\":2082354553304436738,\"orderId\":2082354549059801089,\"userId\":92001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:28\"}]}','2026-07-29 14:36:28'),(2082354555498057729,2082354549059801089,92001,'PAID','{\"timestamp\":\"2026-07-29T14:36:28.963588256\",\"order\":{\"id\":2082354549059801089,\"userId\":92001,\"orderNo\":\"ORD2026072914362735320010031\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:28\",\"updatedAt\":\"2026-07-29 14:36:28\"},\"items\":[{\"id\":2082354553304436738,\"orderId\":2082354549059801089,\"userId\":92001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:28\"}]}','2026-07-29 14:36:28'),(2082354805117849601,2082354799459733506,94001,'CREATED','{\"timestamp\":\"2026-07-29T14:37:28.470017024\",\"order\":{\"id\":2082354799459733506,\"userId\":94001,\"orderNo\":\"ORD2026072914372700740010036\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:28\",\"updatedAt\":\"2026-07-29 14:37:28\"},\"items\":[{\"id\":2082354803863752705,\"orderId\":2082354799459733506,\"userId\":94001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:28\"}]}','2026-07-29 14:37:28'),(2082354806380335106,2082354799459733506,94001,'CANCELLED','{\"timestamp\":\"2026-07-29T14:37:28.780022696\",\"order\":{\"id\":2082354799459733506,\"userId\":94001,\"orderNo\":\"ORD2026072914372700740010036\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:28\",\"updatedAt\":\"2026-07-29 14:37:28\"},\"items\":[{\"id\":2082354803863752705,\"orderId\":2082354799459733506,\"userId\":94001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:28\"}]}','2026-07-29 14:37:28'),(2082355315149410305,2082355315078107137,10001,'CREATED','{\"timestamp\":\"2026-07-29T14:39:30.080307737\",\"order\":{\"id\":2082355315078107137,\"userId\":10001,\"orderNo\":\"ORD2026072914393006000010044\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:39:30\",\"updatedAt\":\"2026-07-29 14:39:30\"},\"items\":[{\"id\":2082355315094884354,\"orderId\":2082355315078107137,\"userId\":10001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:39:30\"}]}','2026-07-29 14:39:30'),(2082355590438359041,2082355590371250177,20001,'CREATED','{\"timestamp\":\"2026-07-29T14:40:35.712687804\",\"order\":{\"id\":2082355590371250177,\"userId\":20001,\"orderNo\":\"ORD2026072914403569600010047\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:35\",\"updatedAt\":\"2026-07-29 14:40:35\"},\"items\":[{\"id\":2082355590388027393,\"orderId\":2082355590371250177,\"userId\":20001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:35\"}]}','2026-07-29 14:40:35'),(2082355590656462850,2082355590371250177,20001,'CANCELLED','{\"timestamp\":\"2026-07-29T14:40:35.766131614\",\"order\":{\"id\":2082355590371250177,\"userId\":20001,\"orderNo\":\"ORD2026072914403569600010047\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:35\",\"updatedAt\":\"2026-07-29 14:40:35\"},\"items\":[{\"id\":2082355590388027393,\"orderId\":2082355590371250177,\"userId\":20001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:35\"}]}','2026-07-29 14:40:35'),(2082355656888717314,2082355656792248321,30001,'CREATED','{\"timestamp\":\"2026-07-29T14:40:51.556937764\",\"order\":{\"id\":2082355656792248321,\"userId\":30001,\"orderNo\":\"ORD2026072914405153100010048\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:51\",\"updatedAt\":\"2026-07-29 14:40:51\"},\"items\":[{\"id\":2082355656804831233,\"orderId\":2082355656792248321,\"userId\":30001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:51\"}]}','2026-07-29 14:40:51'),(2082355657069072386,2082355656792248321,30001,'PAID','{\"timestamp\":\"2026-07-29T14:40:51.599973162\",\"order\":{\"id\":2082355656792248321,\"userId\":30001,\"orderNo\":\"ORD2026072914405153100010048\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:51\",\"updatedAt\":\"2026-07-29 14:40:51\"},\"items\":[{\"id\":2082355656804831233,\"orderId\":2082355656792248321,\"userId\":30001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:51\"}]}','2026-07-29 14:40:51'),(2082355657253621762,2082355656792248321,30001,'REFUNDED','{\"timestamp\":\"2026-07-29T14:40:51.643670729\",\"order\":{\"id\":2082355656792248321,\"userId\":30001,\"orderNo\":\"ORD2026072914405153100010048\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":5,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:51\",\"updatedAt\":\"2026-07-29 14:40:51\"},\"items\":[{\"id\":2082355656804831233,\"orderId\":2082355656792248321,\"userId\":30001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:51\"}]}','2026-07-29 14:40:51'),(2082359222718205953,2082351672551649282,80001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-07-29T14:55:01.716978059\",\"order\":{\"id\":2082351672551649282,\"userId\":80001,\"orderNo\":\"ORD2026072914250161400010012\",\"totalAmount\":99.00,\"payAmount\":89.00,\"discountAmount\":10.00,\"couponId\":2082351668176924674,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:25:01\",\"updatedAt\":\"2026-07-29 14:55:01\"},\"items\":[{\"id\":2082351672576815105,\"orderId\":2082351672551649282,\"userId\":80001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:25:01\"}]}','2026-07-29 14:55:01'),(2082362865320235009,2082355315078107137,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-07-29T15:09:30.180559161\",\"order\":{\"id\":2082355315078107137,\"userId\":10001,\"orderNo\":\"ORD2026072914393006000010044\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:39:30\",\"updatedAt\":\"2026-07-29 15:09:30\"},\"items\":[{\"id\":2082355315094884354,\"orderId\":2082355315078107137,\"userId\":10001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:39:30\"}]}','2026-07-29 15:09:30'),(2082367690858598401,2082367690804072449,10001,'CREATED','{\"timestamp\":\"2026-07-29T15:28:40.678962027\",\"order\":{\"id\":2082367690804072449,\"userId\":10001,\"orderNo\":\"ORD2026072915284066400010049\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 15:28:40\",\"updatedAt\":\"2026-07-29 15:28:40\"},\"items\":[{\"id\":2082367690816655362,\"orderId\":2082367690804072449,\"userId\":10001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 15:28:40\"}]}','2026-07-29 15:28:40'),(2082375240966508545,2082367690804072449,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-07-29T15:58:40.765094901\",\"order\":{\"id\":2082367690804072449,\"userId\":10001,\"orderNo\":\"ORD2026072915284066400010049\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 15:28:40\",\"updatedAt\":\"2026-07-29 15:58:40\"},\"items\":[{\"id\":2082367690816655362,\"orderId\":2082367690804072449,\"userId\":10001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 15:28:40\"}]}','2026-07-29 15:58:40'),(2084171331286376450,2084171330690785282,2084171328232906753,'CREATED','{\"order\":{\"id\":2084171330690785282,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554185467530001\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171331055689729,\"orderId\":2084171330690785282,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.058810552\"}','2026-08-03 14:55:42'),(2084171332360118274,2084171330690785282,2084171328232906753,'PAID','{\"order\":{\"id\":2084171330690785282,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554185467530001\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171331055689729,\"orderId\":2084171330690785282,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.321905793\"}','2026-08-03 14:55:42'),(2084171332615970818,2084171330690785282,2084171328232906753,'DELIVERED','{\"order\":{\"id\":2084171330690785282,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554185467530001\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171331055689729,\"orderId\":2084171330690785282,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.383422516\"}','2026-08-03 14:55:42'),(2084171332771160066,2084171330690785282,2084171328232906753,'COMPLETED','{\"order\":{\"id\":2084171330690785282,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554185467530001\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171331055689729,\"orderId\":2084171330690785282,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.420061845\"}','2026-08-03 14:55:42'),(2084171332909572097,2084171332859240449,2084171328232906753,'CREATED','{\"order\":{\"id\":2084171332859240449,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554244067530002\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171332876017665,\"orderId\":2084171332859240449,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.453279033\"}','2026-08-03 14:55:42'),(2084171333454831618,2084171332859240449,2084171328232906753,'CANCELLED','{\"order\":{\"id\":2084171332859240449,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554244067530002\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171332876017665,\"orderId\":2084171332859240449,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.582115642\"}','2026-08-03 14:55:42'),(2084171333597437954,2084171333538717698,2084171328232906753,'CREATED','{\"order\":{\"id\":2084171333538717698,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554260167530003\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171333551300610,\"orderId\":2084171333538717698,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.614552275\"}','2026-08-03 14:55:42'),(2084171333773598721,2084171333538717698,2084171328232906753,'PAID','{\"order\":{\"id\":2084171333538717698,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554260167530003\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171333551300610,\"orderId\":2084171333538717698,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.658471282\"}','2026-08-03 14:55:42'),(2084171333941370882,2084171333874262017,2084171328232906753,'CREATED','{\"order\":{\"id\":2084171333874262017,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554268067530004\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171333895233537,\"orderId\":2084171333874262017,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.699680303\"}','2026-08-03 14:55:42'),(2084171334134308865,2084171333874262017,2084171328232906753,'CANCELLED','{\"order\":{\"id\":2084171333874262017,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554268067530004\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171333895233537,\"orderId\":2084171333874262017,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.745457924\"}','2026-08-03 14:55:42'),(2084171334260137985,2084171334209806338,2084171328232906753,'CREATED','{\"order\":{\"id\":2084171334209806338,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554276167530005\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171334222389249,\"orderId\":2084171334209806338,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.774973104\"}','2026-08-03 14:55:42'),(2084171334419521538,2084171334209806338,2084171328232906753,'PAID','{\"order\":{\"id\":2084171334209806338,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554276167530005\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171334222389249,\"orderId\":2084171334209806338,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.813415689\"}','2026-08-03 14:55:42'),(2084171334612459522,2084171334209806338,2084171328232906753,'REFUNDED','{\"order\":{\"id\":2084171334209806338,\"userId\":2084171328232906753,\"orderNo\":\"ORD2026080314554276167530005\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":5,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:55:42\",\"updatedAt\":\"2026-08-03 14:55:42\"},\"items\":[{\"id\":2084171334222389249,\"orderId\":2084171334209806338,\"userId\":2084171328232906753,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:55:42\"}],\"timestamp\":\"2026-08-03T14:55:42.859248469\"}','2026-08-03 14:55:42'),(2084171442569650178,2084171442498347010,2084171442041151489,'CREATED','{\"order\":{\"id\":2084171442498347010,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560857914890006\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171442510929922,\"orderId\":2084171442498347010,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.598017618\"}','2026-08-03 14:56:08'),(2084171442867445762,2084171442498347010,2084171442041151489,'PAID','{\"order\":{\"id\":2084171442498347010,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560857914890006\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171442510929922,\"orderId\":2084171442498347010,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.669345558\"}','2026-08-03 14:56:08'),(2084171443047800833,2084171442498347010,2084171442041151489,'DELIVERED','{\"order\":{\"id\":2084171442498347010,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560857914890006\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171442510929922,\"orderId\":2084171442498347010,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.712530709\"}','2026-08-03 14:56:08'),(2084171443169435649,2084171442498347010,2084171442041151489,'COMPLETED','{\"order\":{\"id\":2084171442498347010,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560857914890006\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171442510929922,\"orderId\":2084171442498347010,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.741846223\"}','2026-08-03 14:56:08'),(2084171443295264770,2084171443244933121,2084171442041151489,'CREATED','{\"order\":{\"id\":2084171443244933121,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560875714890007\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171443249127425,\"orderId\":2084171443244933121,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.771565110\"}','2026-08-03 14:56:08'),(2084171443471425537,2084171443244933121,2084171442041151489,'CANCELLED','{\"order\":{\"id\":2084171443244933121,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560875714890007\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171443249127425,\"orderId\":2084171443244933121,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.812895227\"}','2026-08-03 14:56:08'),(2084171443580477441,2084171443542728705,2084171442041151489,'CREATED','{\"order\":{\"id\":2084171443542728705,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560882814890008\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171443551117314,\"orderId\":2084171443542728705,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.839141411\"}','2026-08-03 14:56:08'),(2084171443706306562,2084171443542728705,2084171442041151489,'PAID','{\"order\":{\"id\":2084171443542728705,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560882814890008\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171443551117314,\"orderId\":2084171443542728705,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.868928087\"}','2026-08-03 14:56:08'),(2084171443811164162,2084171443773415425,2084171442041151489,'CREATED','{\"order\":{\"id\":2084171443773415425,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560888314890009\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171443781804033,\"orderId\":2084171443773415425,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.894071483\"}','2026-08-03 14:56:08'),(2084171443974742018,2084171443773415425,2084171442041151489,'CANCELLED','{\"order\":{\"id\":2084171443773415425,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560888314890009\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171443781804033,\"orderId\":2084171443773415425,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.932987638\"}','2026-08-03 14:56:08'),(2084171444087988226,2084171444050239489,2084171442041151489,'CREATED','{\"order\":{\"id\":2084171444050239489,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560895014890010\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171444062822401,\"orderId\":2084171444050239489,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.960902930\"}','2026-08-03 14:56:08'),(2084171444226400257,2084171444050239489,2084171442041151489,'PAID','{\"order\":{\"id\":2084171444050239489,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560895014890010\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:08\"},\"items\":[{\"id\":2084171444062822401,\"orderId\":2084171444050239489,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:08.992961710\"}','2026-08-03 14:56:08'),(2084171444406755329,2084171444050239489,2084171442041151489,'REFUNDED','{\"order\":{\"id\":2084171444050239489,\"userId\":2084171442041151489,\"orderNo\":\"ORD2026080314560895014890010\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":5,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 14:56:08\",\"updatedAt\":\"2026-08-03 14:56:09\"},\"items\":[{\"id\":2084171444062822401,\"orderId\":2084171444050239489,\"userId\":2084171442041151489,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 14:56:08\"}],\"timestamp\":\"2026-08-03T14:56:09.036394147\"}','2026-08-03 14:56:09'),(2084212478834700289,2084212478574653441,2084212477404413953,'CREATED','{\"order\":{\"id\":2084212478574653441,\"userId\":2084212477404413953,\"orderNo\":\"ORD2026080317391230939530013\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 17:39:12\",\"updatedAt\":\"2026-08-03 17:39:12\"},\"items\":[{\"id\":2084212478675316737,\"orderId\":2084212478574653441,\"userId\":2084212477404413953,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 17:39:12\"}],\"timestamp\":\"2026-08-03T17:39:12.402522750\"}','2026-08-03 17:39:12'),(2084212479614840834,2084212478574653441,2084212477404413953,'PAID','{\"order\":{\"id\":2084212478574653441,\"userId\":2084212477404413953,\"orderNo\":\"ORD2026080317391230939530013\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 17:39:12\",\"updatedAt\":\"2026-08-03 17:39:12\"},\"items\":[{\"id\":2084212478675316737,\"orderId\":2084212478574653441,\"userId\":2084212477404413953,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 17:39:12\"}],\"timestamp\":\"2026-08-03T17:39:12.591904184\"}','2026-08-03 17:39:12'),(2084212479908442113,2084212478574653441,2084212477404413953,'DELIVERED','{\"order\":{\"id\":2084212478574653441,\"userId\":2084212477404413953,\"orderNo\":\"ORD2026080317391230939530013\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 17:39:12\",\"updatedAt\":\"2026-08-03 17:39:12\"},\"items\":[{\"id\":2084212478675316737,\"orderId\":2084212478574653441,\"userId\":2084212477404413953,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 17:39:12\"}],\"timestamp\":\"2026-08-03T17:39:12.662539343\"}','2026-08-03 17:39:12'),(2084212480092991490,2084212478574653441,2084212477404413953,'COMPLETED','{\"order\":{\"id\":2084212478574653441,\"userId\":2084212477404413953,\"orderNo\":\"ORD2026080317391230939530013\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 17:39:12\",\"updatedAt\":\"2026-08-03 17:39:12\"},\"items\":[{\"id\":2084212478675316737,\"orderId\":2084212478574653441,\"userId\":2084212477404413953,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-03 17:39:12\"}],\"timestamp\":\"2026-08-03T17:39:12.706440463\"}','2026-08-03 17:39:12'),(2084212480269152258,2084212480189460482,2084212477404413953,'CREATED','{\"order\":{\"id\":2084212480189460482,\"userId\":2084212477404413953,\"orderNo\":\"ORD2026080317391272639530014\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 17:39:12\",\"updatedAt\":\"2026-08-03 17:39:12\"},\"items\":[{\"id\":2084212480206237698,\"orderId\":2084212480189460482,\"userId\":2084212477404413953,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 17:39:12\"}],\"timestamp\":\"2026-08-03T17:39:12.748163247\"}','2026-08-03 17:39:12'),(2084212481493889025,2084212480189460482,2084212477404413953,'CANCELLED','{\"order\":{\"id\":2084212480189460482,\"userId\":2084212477404413953,\"orderNo\":\"ORD2026080317391272639530014\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 17:39:12\",\"updatedAt\":\"2026-08-03 17:39:12\"},\"items\":[{\"id\":2084212480206237698,\"orderId\":2084212480189460482,\"userId\":2084212477404413953,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 17:39:12\"}],\"timestamp\":\"2026-08-03T17:39:13.040020848\"}','2026-08-03 17:39:13'),(2084481541527883777,2084481541477552129,2084481541045514241,'CREATED','{\"order\":{\"id\":2084481541477552129,\"userId\":2084481541045514241,\"orderNo\":\"ORD2026080411282193542410004\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:21\",\"updatedAt\":\"2026-08-04 11:28:21\"},\"items\":[{\"id\":2084481541490135041,\"orderId\":2084481541477552129,\"userId\":2084481541045514241,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:28:21\"}],\"timestamp\":\"2026-08-04T11:28:21.951453423\"}','2026-08-04 11:28:21'),(2084481541829873666,2084481541477552129,2084481541045514241,'PAID','{\"order\":{\"id\":2084481541477552129,\"userId\":2084481541045514241,\"orderNo\":\"ORD2026080411282193542410004\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:21\",\"updatedAt\":\"2026-08-04 11:28:22\"},\"items\":[{\"id\":2084481541490135041,\"orderId\":2084481541477552129,\"userId\":2084481541045514241,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:28:21\"}],\"timestamp\":\"2026-08-04T11:28:22.023559116\"}','2026-08-04 11:28:22'),(2084481542018617346,2084481541477552129,2084481541045514241,'DELIVERED','{\"order\":{\"id\":2084481541477552129,\"userId\":2084481541045514241,\"orderNo\":\"ORD2026080411282193542410004\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:21\",\"updatedAt\":\"2026-08-04 11:28:22\"},\"items\":[{\"id\":2084481541490135041,\"orderId\":2084481541477552129,\"userId\":2084481541045514241,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:28:21\"}],\"timestamp\":\"2026-08-04T11:28:22.068430352\"}','2026-08-04 11:28:22'),(2084481542144446465,2084481541477552129,2084481541045514241,'COMPLETED','{\"order\":{\"id\":2084481541477552129,\"userId\":2084481541045514241,\"orderNo\":\"ORD2026080411282193542410004\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:21\",\"updatedAt\":\"2026-08-04 11:28:22\"},\"items\":[{\"id\":2084481541490135041,\"orderId\":2084481541477552129,\"userId\":2084481541045514241,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:28:21\"}],\"timestamp\":\"2026-08-04T11:28:22.098077004\"}','2026-08-04 11:28:22'),(2084481542245109761,2084481542207361026,2084481541045514241,'CREATED','{\"order\":{\"id\":2084481542207361026,\"userId\":2084481541045514241,\"orderNo\":\"ORD2026080411282211142410005\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:22\",\"updatedAt\":\"2026-08-04 11:28:22\"},\"items\":[{\"id\":2084481542215749633,\"orderId\":2084481542207361026,\"userId\":2084481541045514241,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:28:22\"}],\"timestamp\":\"2026-08-04T11:28:22.122484148\"}','2026-08-04 11:28:22'),(2084481542412881921,2084481542207361026,2084481541045514241,'CANCELLED','{\"order\":{\"id\":2084481542207361026,\"userId\":2084481541045514241,\"orderNo\":\"ORD2026080411282211142410005\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:22\",\"updatedAt\":\"2026-08-04 11:28:22\"},\"items\":[{\"id\":2084481542215749633,\"orderId\":2084481542207361026,\"userId\":2084481541045514241,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:28:22\"}],\"timestamp\":\"2026-08-04T11:28:22.161882760\"}','2026-08-04 11:28:22'),(2084482909558853633,2084482909516910593,2084482909093261313,'CREATED','{\"order\":{\"id\":2084482909516910593,\"userId\":2084482909093261313,\"orderNo\":\"ORD2026080411334810313130014\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:48\",\"updatedAt\":\"2026-08-04 11:33:48\"},\"items\":[{\"id\":2084482909529493506,\"orderId\":2084482909516910593,\"userId\":2084482909093261313,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:33:48\"}],\"timestamp\":\"2026-08-04T11:33:48.115236342\"}','2026-08-04 11:33:48'),(2084482909856649218,2084482909516910593,2084482909093261313,'PAID','{\"order\":{\"id\":2084482909516910593,\"userId\":2084482909093261313,\"orderNo\":\"ORD2026080411334810313130014\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:48\",\"updatedAt\":\"2026-08-04 11:33:48\"},\"items\":[{\"id\":2084482909529493506,\"orderId\":2084482909516910593,\"userId\":2084482909093261313,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:33:48\"}],\"timestamp\":\"2026-08-04T11:33:48.186130671\"}','2026-08-04 11:33:48'),(2084482910028615682,2084482909516910593,2084482909093261313,'DELIVERED','{\"order\":{\"id\":2084482909516910593,\"userId\":2084482909093261313,\"orderNo\":\"ORD2026080411334810313130014\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:48\",\"updatedAt\":\"2026-08-04 11:33:48\"},\"items\":[{\"id\":2084482909529493506,\"orderId\":2084482909516910593,\"userId\":2084482909093261313,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:33:48\"}],\"timestamp\":\"2026-08-04T11:33:48.227095364\"}','2026-08-04 11:33:48'),(2084482910137667585,2084482909516910593,2084482909093261313,'COMPLETED','{\"order\":{\"id\":2084482909516910593,\"userId\":2084482909093261313,\"orderNo\":\"ORD2026080411334810313130014\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:48\",\"updatedAt\":\"2026-08-04 11:33:48\"},\"items\":[{\"id\":2084482909529493506,\"orderId\":2084482909516910593,\"userId\":2084482909093261313,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:33:48\"}],\"timestamp\":\"2026-08-04T11:33:48.253214316\"}','2026-08-04 11:33:48'),(2084482910255108098,2084482910217359362,2084482909093261313,'CREATED','{\"order\":{\"id\":2084482910217359362,\"userId\":2084482909093261313,\"orderNo\":\"ORD2026080411334827013130015\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:48\",\"updatedAt\":\"2026-08-04 11:33:48\"},\"items\":[{\"id\":2084482910225747970,\"orderId\":2084482910217359362,\"userId\":2084482909093261313,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:33:48\"}],\"timestamp\":\"2026-08-04T11:33:48.281186180\"}','2026-08-04 11:33:48'),(2084482910410297345,2084482910217359362,2084482909093261313,'CANCELLED','{\"order\":{\"id\":2084482910217359362,\"userId\":2084482909093261313,\"orderNo\":\"ORD2026080411334827013130015\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:48\",\"updatedAt\":\"2026-08-04 11:33:48\"},\"items\":[{\"id\":2084482910225747970,\"orderId\":2084482910217359362,\"userId\":2084482909093261313,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:33:48\"}],\"timestamp\":\"2026-08-04T11:33:48.318654531\"}','2026-08-04 11:33:48'),(2084483584028102658,2084483583981965313,2084483583558316033,'CREATED','{\"order\":{\"id\":2084483583981965313,\"userId\":2084483583558316033,\"orderNo\":\"ORD2026080411362890860330018\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:36:28\",\"updatedAt\":\"2026-08-04 11:36:28\"},\"items\":[{\"id\":2084483583990353922,\"orderId\":2084483583981965313,\"userId\":2084483583558316033,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:36:28\"}],\"timestamp\":\"2026-08-04T11:36:28.920739765\"}','2026-08-04 11:36:28'),(2084483584296538114,2084483583981965313,2084483583558316033,'PAID','{\"order\":{\"id\":2084483583981965313,\"userId\":2084483583558316033,\"orderNo\":\"ORD2026080411362890860330018\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:36:28\",\"updatedAt\":\"2026-08-04 11:36:28\"},\"items\":[{\"id\":2084483583990353922,\"orderId\":2084483583981965313,\"userId\":2084483583558316033,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:36:28\"}],\"timestamp\":\"2026-08-04T11:36:28.985615932\"}','2026-08-04 11:36:28'),(2084483584472698881,2084483583981965313,2084483583558316033,'DELIVERED','{\"order\":{\"id\":2084483583981965313,\"userId\":2084483583558316033,\"orderNo\":\"ORD2026080411362890860330018\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:36:28\",\"updatedAt\":\"2026-08-04 11:36:29\"},\"items\":[{\"id\":2084483583990353922,\"orderId\":2084483583981965313,\"userId\":2084483583558316033,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:36:28\"}],\"timestamp\":\"2026-08-04T11:36:29.027251891\"}','2026-08-04 11:36:29'),(2084483584581750785,2084483583981965313,2084483583558316033,'COMPLETED','{\"order\":{\"id\":2084483583981965313,\"userId\":2084483583558316033,\"orderNo\":\"ORD2026080411362890860330018\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:36:28\",\"updatedAt\":\"2026-08-04 11:36:29\"},\"items\":[{\"id\":2084483583990353922,\"orderId\":2084483583981965313,\"userId\":2084483583558316033,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:36:28\"}],\"timestamp\":\"2026-08-04T11:36:29.052786474\"}','2026-08-04 11:36:29'),(2084483584674025474,2084483584636276737,2084483583558316033,'CREATED','{\"order\":{\"id\":2084483584636276737,\"userId\":2084483583558316033,\"orderNo\":\"ORD2026080411362906560330019\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:36:29\",\"updatedAt\":\"2026-08-04 11:36:29\"},\"items\":[{\"id\":2084483584648859649,\"orderId\":2084483584636276737,\"userId\":2084483583558316033,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:36:29\"}],\"timestamp\":\"2026-08-04T11:36:29.075536972\"}','2026-08-04 11:36:29'),(2084483584812437505,2084483584636276737,2084483583558316033,'CANCELLED','{\"order\":{\"id\":2084483584636276737,\"userId\":2084483583558316033,\"orderNo\":\"ORD2026080411362906560330019\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:36:29\",\"updatedAt\":\"2026-08-04 11:36:29\"},\"items\":[{\"id\":2084483584648859649,\"orderId\":2084483584636276737,\"userId\":2084483583558316033,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:36:29\"}],\"timestamp\":\"2026-08-04T11:36:29.108456680\"}','2026-08-04 11:36:29'),(2085531903718391810,2085531903223463938,10001,'CREATED','{\"items\":[{\"id\":2085531903487705090,\"orderId\":2085531903223463938,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085530413171785729,\"skuName\":\"Mock商品-2085530413171785729\",\"skuImage\":\"https://img.mock.com/sku/2085530413171785729.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-07 09:02:07\"}],\"order\":{\"id\":2085531903223463938,\"userId\":10001,\"orderNo\":\"ORD2026080709020763800010001\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 09:02:07\",\"updatedAt\":\"2026-08-07 09:02:07\"},\"timestamp\":\"2026-08-07T09:02:07.806492771\"}','2026-08-07 09:02:07'),(2085534651062964225,2085534644842811393,10001,'CREATED','{\"timestamp\":\"2026-08-07T09:13:02.823680686\",\"items\":[{\"id\":2085534649875976194,\"orderId\":2085534644842811393,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085530413171785729,\"skuName\":\"Mock商品-2085530413171785729\",\"skuImage\":\"https://img.mock.com/sku/2085530413171785729.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-07 09:13:02\"}],\"order\":{\"id\":2085534644842811393,\"userId\":10001,\"orderNo\":\"ORD2026080709130122500010002\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 09:13:02\",\"updatedAt\":\"2026-08-07 09:13:02\"}}','2026-08-07 09:13:02'),(2085535521599135745,2085535516037488642,10001,'CREATED','{\"order\":{\"id\":2085535516037488642,\"userId\":10001,\"orderNo\":\"ORD2026080709162895200010003\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 09:16:30\",\"updatedAt\":\"2026-08-07 09:16:30\"},\"items\":[{\"id\":2085535520399564802,\"orderId\":2085535516037488642,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 09:16:30\"}],\"timestamp\":\"2026-08-07T09:16:30.374531840\"}','2026-08-07 09:16:30'),(2085536017118404609,2085535516037488642,10001,'CANCELLED','{\"order\":{\"id\":2085535516037488642,\"userId\":10001,\"orderNo\":\"ORD2026080709162895200010003\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 09:16:30\",\"updatedAt\":\"2026-08-07 09:18:28\"},\"items\":[{\"id\":2085535520399564802,\"orderId\":2085535516037488642,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 09:16:30\"}],\"timestamp\":\"2026-08-07T09:18:28.523067329\"}','2026-08-07 09:18:28'),(2085537318590025730,2085537313141624834,10001,'CREATED','{\"items\":[{\"id\":2085537317495312385,\"orderId\":2085537313141624834,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 09:23:38\"}],\"order\":{\"id\":2085537313141624834,\"userId\":10001,\"orderNo\":\"ORD2026080709233742200010004\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 09:23:38\",\"updatedAt\":\"2026-08-07 09:23:38\"},\"timestamp\":\"2026-08-07T09:23:38.812342913\"}','2026-08-07 09:23:38'),(2085537354413576194,2085537313141624834,10001,'CANCELLED','{\"items\":[{\"id\":2085537317495312385,\"orderId\":2085537313141624834,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 09:23:38\"}],\"order\":{\"id\":2085537313141624834,\"userId\":10001,\"orderNo\":\"ORD2026080709233742200010004\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 09:23:47\",\"deleted\":0,\"createdAt\":\"2026-08-07 09:23:38\",\"updatedAt\":\"2026-08-07 09:23:47\"},\"timestamp\":\"2026-08-07T09:23:47.358873735\"}','2026-08-07 09:23:47'),(2085539010085666818,2085539004578545666,10001,'CREATED','{\"timestamp\":\"2026-08-07T09:30:22.095198321\",\"order\":{\"id\":2085539004578545666,\"userId\":10001,\"orderNo\":\"ORD2026080709302068800010005\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 09:30:21\",\"updatedAt\":\"2026-08-07 09:30:21\"},\"items\":[{\"id\":2085539008940621825,\"orderId\":2085539004578545666,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 09:30:21\"}]}','2026-08-07 09:30:22'),(2085539261739712513,2085539004578545666,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T09:31:22.101208125\",\"order\":{\"id\":2085539004578545666,\"userId\":10001,\"orderNo\":\"ORD2026080709302068800010005\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 09:31:22\",\"deleted\":0,\"createdAt\":\"2026-08-07 09:30:21\",\"updatedAt\":\"2026-08-07 09:31:22\"},\"items\":[{\"id\":2085539008940621825,\"orderId\":2085539004578545666,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 09:30:21\"}]}','2026-08-07 09:31:22'),(2085539453935304705,2085531903223463938,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T09:32:07.924510607\",\"order\":{\"id\":2085531903223463938,\"userId\":10001,\"orderNo\":\"ORD2026080709020763800010001\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 09:32:07\",\"deleted\":0,\"createdAt\":\"2026-08-07 09:02:07\",\"updatedAt\":\"2026-08-07 09:32:07\"},\"items\":[{\"id\":2085531903487705090,\"orderId\":2085531903223463938,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085530413171785729,\"skuName\":\"Mock商品-2085530413171785729\",\"skuImage\":\"https://img.mock.com/sku/2085530413171785729.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-07 09:02:07\"}]}','2026-08-07 09:32:07'),(2085542200101322753,2085534644842811393,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T09:43:02.660967269\",\"order\":{\"id\":2085534644842811393,\"userId\":10001,\"orderNo\":\"ORD2026080709130122500010002\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 09:43:02\",\"deleted\":0,\"createdAt\":\"2026-08-07 09:13:02\",\"updatedAt\":\"2026-08-07 09:43:02\"},\"items\":[{\"id\":2085534649875976194,\"orderId\":2085534644842811393,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085530413171785729,\"skuName\":\"Mock商品-2085530413171785729\",\"skuImage\":\"https://img.mock.com/sku/2085530413171785729.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-07 09:13:02\"}]}','2026-08-07 09:43:02'),(2085562359792812033,2085562359503405057,10001,'CREATED','{\"timestamp\":\"2026-08-07T11:03:09.105621418\",\"order\":{\"id\":2085562359503405057,\"userId\":10001,\"orderNo\":\"ORD2026080711030903300010006\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 11:03:09\",\"updatedAt\":\"2026-08-07 11:03:09\"},\"items\":[{\"id\":2085562359637622786,\"orderId\":2085562359503405057,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 11:03:09\"}]}','2026-08-07 11:03:09'),(2085562511240740865,2085562511144271874,10001,'CREATED','{\"timestamp\":\"2026-08-07T11:03:45.214286552\",\"order\":{\"id\":2085562511144271874,\"userId\":10001,\"orderNo\":\"ORD2026080711034518800010007\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 11:03:45\",\"updatedAt\":\"2026-08-07 11:03:45\"},\"items\":[{\"id\":2085562511161049089,\"orderId\":2085562511144271874,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 11:03:45\"}]}','2026-08-07 11:03:45'),(2085562611874676738,2085562359503405057,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T11:04:09.207397340\",\"order\":{\"id\":2085562359503405057,\"userId\":10001,\"orderNo\":\"ORD2026080711030903300010006\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 11:04:09\",\"deleted\":0,\"createdAt\":\"2026-08-07 11:03:09\",\"updatedAt\":\"2026-08-07 11:04:09\"},\"items\":[{\"id\":2085562359637622786,\"orderId\":2085562359503405057,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 11:03:09\"}]}','2026-08-07 11:04:09'),(2085562763364548609,2085562511144271874,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T11:04:45.325174066\",\"order\":{\"id\":2085562511144271874,\"userId\":10001,\"orderNo\":\"ORD2026080711034518800010007\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 11:04:45\",\"deleted\":0,\"createdAt\":\"2026-08-07 11:03:45\",\"updatedAt\":\"2026-08-07 11:04:45\"},\"items\":[{\"id\":2085562511161049089,\"orderId\":2085562511144271874,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 11:03:45\"}]}','2026-08-07 11:04:45'),(2085564029574594561,2085564029503291393,10001,'CREATED','{\"timestamp\":\"2026-08-07T11:09:47.213451353\",\"order\":{\"id\":2085564029503291393,\"userId\":10001,\"orderNo\":\"ORD2026080711094719400010008\",\"totalAmount\":89.70,\"payAmount\":89.70,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 11:09:47\",\"updatedAt\":\"2026-08-07 11:09:47\"},\"items\":[{\"id\":2085564029520068609,\"orderId\":2085564029503291393,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":3,\"totalAmount\":89.70,\"createdAt\":\"2026-08-07 11:09:47\"}]}','2026-08-07 11:09:47'),(2085564281673236482,2085564029503291393,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T11:10:47.318731702\",\"order\":{\"id\":2085564029503291393,\"userId\":10001,\"orderNo\":\"ORD2026080711094719400010008\",\"totalAmount\":89.70,\"payAmount\":89.70,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 11:10:47\",\"deleted\":0,\"createdAt\":\"2026-08-07 11:09:47\",\"updatedAt\":\"2026-08-07 11:10:47\"},\"items\":[{\"id\":2085564029520068609,\"orderId\":2085564029503291393,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":3,\"totalAmount\":89.70,\"createdAt\":\"2026-08-07 11:09:47\"}]}','2026-08-07 11:10:47'),(2085564300769902594,2085564300690210818,10001,'CREATED','{\"timestamp\":\"2026-08-07T11:10:51.870873801\",\"order\":{\"id\":2085564300690210818,\"userId\":10001,\"orderNo\":\"ORD2026080711105185000010009\",\"totalAmount\":89.70,\"payAmount\":89.70,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 11:10:51\",\"updatedAt\":\"2026-08-07 11:10:51\"},\"items\":[{\"id\":2085564300706988034,\"orderId\":2085564300690210818,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":3,\"totalAmount\":89.70,\"createdAt\":\"2026-08-07 11:10:51\"}]}','2026-08-07 11:10:51'),(2085564552906293249,2085564300690210818,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T11:11:51.985621892\",\"order\":{\"id\":2085564300690210818,\"userId\":10001,\"orderNo\":\"ORD2026080711105185000010009\",\"totalAmount\":89.70,\"payAmount\":89.70,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 11:11:51\",\"deleted\":0,\"createdAt\":\"2026-08-07 11:10:51\",\"updatedAt\":\"2026-08-07 11:11:51\"},\"items\":[{\"id\":2085564300706988034,\"orderId\":2085564300690210818,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":3,\"totalAmount\":89.70,\"createdAt\":\"2026-08-07 11:10:51\"}]}','2026-08-07 11:11:51'),(2085565472448724994,2085565472364838913,10001,'CREATED','{\"timestamp\":\"2026-08-07T11:15:31.221817285\",\"order\":{\"id\":2085565472364838913,\"userId\":10001,\"orderNo\":\"ORD2026080711153119800010010\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 11:15:31\",\"updatedAt\":\"2026-08-07 11:15:31\"},\"items\":[{\"id\":2085565472385810434,\"orderId\":2085565472364838913,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 11:15:31\"}]}','2026-08-07 11:15:31'),(2085565724425732098,2085565472364838913,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T11:16:31.297338879\",\"order\":{\"id\":2085565472364838913,\"userId\":10001,\"orderNo\":\"ORD2026080711153119800010010\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 11:16:31\",\"deleted\":0,\"createdAt\":\"2026-08-07 11:15:31\",\"updatedAt\":\"2026-08-07 11:16:31\"},\"items\":[{\"id\":2085565472385810434,\"orderId\":2085565472364838913,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 11:15:31\"}]}','2026-08-07 11:16:31'),(2085588520287617026,2085588519922712577,10001,'CREATED','{\"timestamp\":\"2026-08-07T12:47:06.254127981\",\"order\":{\"id\":2085588519922712577,\"userId\":10001,\"orderNo\":\"ORD2026080712470616100010011\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 12:47:06\",\"updatedAt\":\"2026-08-07 12:47:06\"},\"items\":[{\"id\":2085588520077901825,\"orderId\":2085588519922712577,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 12:47:06\"}]}','2026-08-07 12:47:06'),(2085588669021831170,2085588519922712577,10001,'PAID','{\"timestamp\":\"2026-08-07T12:47:41.715010784\",\"order\":{\"id\":2085588519922712577,\"userId\":10001,\"orderNo\":\"ORD2026080712470616100010011\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 12:47:06\",\"updatedAt\":\"2026-08-07 12:47:41\"},\"items\":[{\"id\":2085588520077901825,\"orderId\":2085588519922712577,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 12:47:06\"}]}','2026-08-07 12:47:41'),(2085589304500830210,2085588519922712577,10001,'DELIVERED','{\"timestamp\":\"2026-08-07T12:50:13.225341599\",\"order\":{\"id\":2085588519922712577,\"userId\":10001,\"orderNo\":\"ORD2026080712470616100010011\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 12:47:06\",\"updatedAt\":\"2026-08-07 12:50:13\"},\"items\":[{\"id\":2085588520077901825,\"orderId\":2085588519922712577,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 12:47:06\"}]}','2026-08-07 12:50:13'),(2085589304685379585,2085588519922712577,10001,'COMPLETED','{\"timestamp\":\"2026-08-07T12:50:13.269660608\",\"order\":{\"id\":2085588519922712577,\"userId\":10001,\"orderNo\":\"ORD2026080712470616100010011\",\"totalAmount\":59.80,\"payAmount\":59.80,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 12:47:06\",\"updatedAt\":\"2026-08-07 12:50:13\"},\"items\":[{\"id\":2085588520077901825,\"orderId\":2085588519922712577,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":2,\"totalAmount\":59.80,\"createdAt\":\"2026-08-07 12:47:06\"}]}','2026-08-07 12:50:13'),(2085590380490784770,2085590374643924993,10001,'CREATED','{\"items\":[{\"id\":2085590378985029633,\"orderId\":2085590374643924993,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 12:54:29\"}],\"order\":{\"id\":2085590374643924993,\"userId\":10001,\"orderNo\":\"ORD2026080712542826900010012\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 12:54:29\",\"updatedAt\":\"2026-08-07 12:54:29\"},\"timestamp\":\"2026-08-07T12:54:29.753469265\"}','2026-08-07 12:54:29'),(2085590381862322178,2085590374643924993,10001,'PAID','{\"items\":[{\"id\":2085590378985029633,\"orderId\":2085590374643924993,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 12:54:29\"}],\"order\":{\"id\":2085590374643924993,\"userId\":10001,\"orderNo\":\"ORD2026080712542826900010012\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":\"2026-08-07 12:54:30\",\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 12:54:29\",\"updatedAt\":\"2026-08-07 12:54:30\"},\"timestamp\":\"2026-08-07T12:54:30.088631214\"}','2026-08-07 12:54:30'),(2085590382264975362,2085590374643924993,10001,'DELIVERED','{\"items\":[{\"id\":2085590378985029633,\"orderId\":2085590374643924993,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 12:54:29\"}],\"order\":{\"id\":2085590374643924993,\"userId\":10001,\"orderNo\":\"ORD2026080712542826900010012\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":\"2026-08-07 12:54:30\",\"deliveredAt\":\"2026-08-07 12:54:30\",\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 12:54:29\",\"updatedAt\":\"2026-08-07 12:54:30\"},\"timestamp\":\"2026-08-07T12:54:30.183961400\"}','2026-08-07 12:54:30'),(2085590447629008898,2085590374643924993,10001,'COMPLETED','{\"items\":[{\"id\":2085590378985029633,\"orderId\":2085590374643924993,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 12:54:29\"}],\"order\":{\"id\":2085590374643924993,\"userId\":10001,\"orderNo\":\"ORD2026080712542826900010012\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":\"2026-08-07 12:54:30\",\"deliveredAt\":\"2026-08-07 12:54:30\",\"completedAt\":\"2026-08-07 12:54:45\",\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 12:54:29\",\"updatedAt\":\"2026-08-07 12:54:45\"},\"timestamp\":\"2026-08-07T12:54:45.768444059\"}','2026-08-07 12:54:45'),(2085594181754945538,2085594181637505025,10001,'CREATED','{\"items\":[{\"id\":2085594181675253761,\"orderId\":2085594181637505025,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":9999,\"totalAmount\":298970.10,\"createdAt\":\"2026-08-07 13:09:36\"}],\"order\":{\"id\":2085594181637505025,\"userId\":10001,\"orderNo\":\"ORD2026080713093602200010013\",\"totalAmount\":298970.10,\"payAmount\":298970.10,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 13:09:36\",\"updatedAt\":\"2026-08-07 13:09:36\"},\"timestamp\":\"2026-08-07T13:09:36.053300442\"}','2026-08-07 13:09:36'),(2085594433975222273,2085594181637505025,10001,'TIMEOUT_CANCELLED','{\"items\":[{\"id\":2085594181675253761,\"orderId\":2085594181637505025,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":9999,\"totalAmount\":298970.10,\"createdAt\":\"2026-08-07 13:09:36\"}],\"order\":{\"id\":2085594181637505025,\"userId\":10001,\"orderNo\":\"ORD2026080713093602200010013\",\"totalAmount\":298970.10,\"payAmount\":298970.10,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 13:10:36\",\"deleted\":0,\"createdAt\":\"2026-08-07 13:09:36\",\"updatedAt\":\"2026-08-07 13:10:36\"},\"timestamp\":\"2026-08-07T13:10:36.187596357\"}','2026-08-07 13:10:36'),(2085596268266094594,2085596262905774082,10001,'CREATED','{\"order\":{\"id\":2085596262905774082,\"userId\":10001,\"orderNo\":\"ORD2026080713175213900010014\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 13:17:53\",\"updatedAt\":\"2026-08-07 13:17:53\"},\"items\":[{\"id\":2085596267225907201,\"orderId\":2085596262905774082,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 13:17:53\"}],\"timestamp\":\"2026-08-07T13:17:53.509575665\"}','2026-08-07 13:17:53'),(2085596519894974466,2085596262905774082,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2085596262905774082,\"userId\":10001,\"orderNo\":\"ORD2026080713175213900010014\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 13:18:53\",\"deleted\":0,\"createdAt\":\"2026-08-07 13:17:53\",\"updatedAt\":\"2026-08-07 13:18:53\"},\"items\":[{\"id\":2085596267225907201,\"orderId\":2085596262905774082,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 13:17:53\"}],\"timestamp\":\"2026-08-07T13:18:53.509266185\"}','2026-08-07 13:18:53'),(2085631829458649089,2085631829332819969,10001,'CREATED','{\"order\":{\"id\":2085631829332819969,\"userId\":10001,\"orderNo\":\"ORD2026080715391193100010015\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 15:39:11\",\"updatedAt\":\"2026-08-07 15:39:11\"},\"items\":[{\"id\":2085631829362180098,\"orderId\":2085631829332819969,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 15:39:11\"}],\"timestamp\":\"2026-08-07T15:39:11.965386673\"}','2026-08-07 15:39:11'),(2085631830008102913,2085631829903245313,10001,'CREATED','{\"order\":{\"id\":2085631829903245313,\"userId\":10001,\"orderNo\":\"ORD2026080715391206800010016\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 15:39:12\",\"updatedAt\":\"2026-08-07 15:39:12\"},\"items\":[{\"id\":2085631829928411138,\"orderId\":2085631829903245313,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 15:39:12\"}],\"timestamp\":\"2026-08-07T15:39:12.096008585\"}','2026-08-07 15:39:12'),(2085631830452699137,2085631829903245313,10001,'PAID','{\"order\":{\"id\":2085631829903245313,\"userId\":10001,\"orderNo\":\"ORD2026080715391206800010016\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":\"2026-08-07 15:39:12\",\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 15:39:12\",\"updatedAt\":\"2026-08-07 15:39:12\"},\"items\":[{\"id\":2085631829928411138,\"orderId\":2085631829903245313,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 15:39:12\"}],\"timestamp\":\"2026-08-07T15:39:12.202502311\"}','2026-08-07 15:39:12'),(2085631963995144194,2085631963915452418,10001,'CREATED','{\"order\":{\"id\":2085631963915452418,\"userId\":10001,\"orderNo\":\"ORD2026080715394401900010017\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 15:39:44\",\"updatedAt\":\"2026-08-07 15:39:44\"},\"items\":[{\"id\":2085631963932229633,\"orderId\":2085631963915452418,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 15:39:44\"}],\"timestamp\":\"2026-08-07T15:39:44.040998403\"}','2026-08-07 15:39:44'),(2085631972673159170,2085631963915452418,10001,'PAID','{\"order\":{\"id\":2085631963915452418,\"userId\":10001,\"orderNo\":\"ORD2026080715394401900010017\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":\"2026-08-07 15:39:46\",\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 15:39:44\",\"updatedAt\":\"2026-08-07 15:39:46\"},\"items\":[{\"id\":2085631963932229633,\"orderId\":2085631963915452418,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 15:39:44\"}],\"timestamp\":\"2026-08-07T15:39:46.109869263\"}','2026-08-07 15:39:46'),(2085632081410490370,2085631829332819969,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2085631829332819969,\"userId\":10001,\"orderNo\":\"ORD2026080715391193100010015\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 15:40:12\",\"deleted\":0,\"createdAt\":\"2026-08-07 15:39:11\",\"updatedAt\":\"2026-08-07 15:40:12\"},\"items\":[{\"id\":2085631829362180098,\"orderId\":2085631829332819969,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 15:39:11\"}],\"timestamp\":\"2026-08-07T15:40:12.035436453\"}','2026-08-07 15:40:12'),(2085632792793808897,2085632792714117122,10001,'CREATED','{\"order\":{\"id\":2085632792714117122,\"userId\":10001,\"orderNo\":\"ORD2026080715430162000010018\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 15:43:01\",\"updatedAt\":\"2026-08-07 15:43:01\"},\"items\":[{\"id\":2085632792730894337,\"orderId\":2085632792714117122,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 15:43:01\"}],\"timestamp\":\"2026-08-07T15:43:01.641871963\"}','2026-08-07 15:43:01'),(2085633044795981826,2085632792714117122,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2085632792714117122,\"userId\":10001,\"orderNo\":\"ORD2026080715430162000010018\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 15:44:01\",\"deleted\":0,\"createdAt\":\"2026-08-07 15:43:01\",\"updatedAt\":\"2026-08-07 15:44:01\"},\"items\":[{\"id\":2085632792730894337,\"orderId\":2085632792714117122,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 15:43:01\"}],\"timestamp\":\"2026-08-07T15:44:01.724520747\"}','2026-08-07 15:44:01'),(2085638178246533121,2085638172626165762,10001,'CREATED','{\"order\":{\"id\":2085638172626165762,\"userId\":10001,\"orderNo\":\"ORD2026080716042422100010019\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 16:04:25\",\"updatedAt\":\"2026-08-07 16:04:25\"},\"timestamp\":\"2026-08-07T16:04:25.627287958\",\"items\":[{\"id\":2085638177005019137,\"orderId\":2085638172626165762,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:04:25\"}]}','2026-08-07 16:04:25'),(2085638429623754754,2085638172626165762,10001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2085638172626165762,\"userId\":10001,\"orderNo\":\"ORD2026080716042422100010019\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 16:05:25\",\"deleted\":0,\"createdAt\":\"2026-08-07 16:04:25\",\"updatedAt\":\"2026-08-07 16:05:25\"},\"timestamp\":\"2026-08-07T16:05:25.566853049\",\"items\":[{\"id\":2085638177005019137,\"orderId\":2085638172626165762,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:04:25\"}]}','2026-08-07 16:05:25'),(2085638865915265025,2085638860609470466,10001,'CREATED','{\"timestamp\":\"2026-08-07T16:07:09.580522314\",\"items\":[{\"id\":2085638864900243458,\"orderId\":2085638860609470466,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:07:09\"}],\"order\":{\"id\":2085638860609470466,\"userId\":10001,\"orderNo\":\"ORD2026080716070824900010020\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 16:07:09\",\"updatedAt\":\"2026-08-07 16:07:09\"}}','2026-08-07 16:07:09'),(2085639117602865154,2085638860609470466,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T16:08:09.594001372\",\"items\":[{\"id\":2085638864900243458,\"orderId\":2085638860609470466,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:07:09\"}],\"order\":{\"id\":2085638860609470466,\"userId\":10001,\"orderNo\":\"ORD2026080716070824900010020\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 16:08:09\",\"deleted\":0,\"createdAt\":\"2026-08-07 16:07:09\",\"updatedAt\":\"2026-08-07 16:08:09\"}}','2026-08-07 16:08:09'),(2085639995588116482,2085639989166637057,10001,'CREATED','{\"timestamp\":\"2026-08-07T16:11:38.914497190\",\"order\":{\"id\":2085639989166637057,\"userId\":10001,\"orderNo\":\"ORD2026080716113731500010021\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 16:11:38\",\"updatedAt\":\"2026-08-07 16:11:38\"},\"items\":[{\"id\":2085639994279493633,\"orderId\":2085639989166637057,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:11:38\"}]}','2026-08-07 16:11:38'),(2085642388195282945,2085639989166637057,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T16:21:09.338011022\",\"order\":{\"id\":2085639989166637057,\"userId\":10001,\"orderNo\":\"ORD2026080716113731500010021\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 16:21:07\",\"deleted\":0,\"createdAt\":\"2026-08-07 16:11:38\",\"updatedAt\":\"2026-08-07 16:21:07\"},\"items\":[{\"id\":2085639994279493633,\"orderId\":2085639989166637057,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:11:38\"}]}','2026-08-07 16:21:09'),(2085642441337114626,2085642441198702594,10001,'CREATED','{\"timestamp\":\"2026-08-07T16:21:22.034778648\",\"order\":{\"id\":2085642441198702594,\"userId\":10001,\"orderNo\":\"ORD2026080716212199200010022\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 16:21:22\",\"updatedAt\":\"2026-08-07 16:21:22\"},\"items\":[{\"id\":2085642441228062721,\"orderId\":2085642441198702594,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:21:22\"}]}','2026-08-07 16:21:22'),(2085642693318316034,2085642441198702594,10001,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-08-07T16:22:22.111146577\",\"order\":{\"id\":2085642441198702594,\"userId\":10001,\"orderNo\":\"ORD2026080716212199200010022\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":\"2026-08-07 16:22:22\",\"deleted\":0,\"createdAt\":\"2026-08-07 16:21:22\",\"updatedAt\":\"2026-08-07 16:22:22\"},\"items\":[{\"id\":2085642441228062721,\"orderId\":2085642441198702594,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:21:22\"}]}','2026-08-07 16:22:22'),(2085643056792510465,2085643051075674114,10001,'CREATED','{\"items\":[{\"id\":2085643055618105345,\"orderId\":2085643051075674114,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:23:48\"}],\"order\":{\"id\":2085643051075674114,\"userId\":10001,\"orderNo\":\"ORD2026080716234728200010023\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 16:23:48\",\"updatedAt\":\"2026-08-07 16:23:48\"},\"timestamp\":\"2026-08-07T16:23:48.763517286\"}','2026-08-07 16:23:48'),(2085644617795018753,2085643051075674114,10001,'PAID','{\"items\":[{\"id\":2085643055618105345,\"orderId\":2085643051075674114,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:23:48\"}],\"order\":{\"id\":2085643051075674114,\"userId\":10001,\"orderNo\":\"ORD2026080716234728200010023\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":\"2026-08-07 16:30:00\",\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 16:23:48\",\"updatedAt\":\"2026-08-07 16:30:00\"},\"timestamp\":\"2026-08-07T16:30:00.942093781\"}','2026-08-07 16:30:00'),(2085646961110720513,2085646961035223041,10001,'CREATED','{\"items\":[{\"id\":2085646961052000257,\"orderId\":2085646961035223041,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:39:19\"}],\"order\":{\"id\":2085646961035223041,\"userId\":10001,\"orderNo\":\"ORD2026080716391961100010024\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 16:39:19\",\"updatedAt\":\"2026-08-07 16:39:19\"},\"timestamp\":\"2026-08-07T16:39:19.632407429\"}','2026-08-07 16:39:19'),(2085648642984681473,2085646961035223041,10001,'PAID','{\"items\":[{\"id\":2085646961052000257,\"orderId\":2085646961035223041,\"userId\":10001,\"skuId\":2085530413171785729,\"spuId\":2085352027803664385,\"skuName\":\"P06测试SKU\",\"skuImage\":null,\"price\":29.90,\"quantity\":1,\"totalAmount\":29.90,\"createdAt\":\"2026-08-07 16:39:19\"}],\"order\":{\"id\":2085646961035223041,\"userId\":10001,\"orderNo\":\"ORD2026080716391961100010024\",\"totalAmount\":29.90,\"payAmount\":29.90,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":\"2026-08-07 16:46:00\",\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-07 16:39:19\",\"updatedAt\":\"2026-08-07 16:46:00\"},\"timestamp\":\"2026-08-07T16:46:00.622909120\"}','2026-08-07 16:46:00');
/*!40000 ALTER TABLE `t_order_snapshot_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_1`
--

DROP TABLE IF EXISTS `t_order_snapshot_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_1` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_1`
--

LOCK TABLES `t_order_snapshot_1` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_1` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_1` VALUES (2082329123147010050,2082329118126428162,20005,'CREATED','{\"items\":[{\"id\":2082329122001965058,\"orderId\":2082329118126428162,\"userId\":20005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:55:25\"}],\"order\":{\"id\":2082329118126428162,\"userId\":20005,\"orderNo\":\"ORD2026072912552415000050005\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:55:25\",\"updatedAt\":\"2026-07-29 12:55:25\"},\"timestamp\":\"2026-07-29T12:55:25.411426679\"}','2026-07-29 12:55:25'),(2082336672332185602,2082329118126428162,20005,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2082329118126428162,\"userId\":20005,\"orderNo\":\"ORD2026072912552415000050005\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:55:25\",\"updatedAt\":\"2026-07-29 13:25:25\"},\"timestamp\":\"2026-07-29T13:25:25.285150818\",\"items\":[{\"id\":2082329122001965058,\"orderId\":2082329118126428162,\"userId\":20005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:55:25\"}]}','2026-07-29 13:25:25'),(2082354038319460353,2082354038248157185,90005,'CREATED','{\"timestamp\":\"2026-07-29T14:34:25.659533156\",\"order\":{\"id\":2082354038248157185,\"userId\":90005,\"orderNo\":\"ORD2026072914342564100050020\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354038264934401,\"orderId\":2082354038248157185,\"userId\":90005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354038504009729,2082354038248157185,90005,'PAID','{\"timestamp\":\"2026-07-29T14:34:25.703589015\",\"order\":{\"id\":2082354038248157185,\"userId\":90005,\"orderNo\":\"ORD2026072914342564100050020\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354038264934401,\"orderId\":2082354038248157185,\"userId\":90005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354557456797697,2082354557347745793,92005,'CREATED','{\"timestamp\":\"2026-07-29T14:36:29.430706010\",\"order\":{\"id\":2082354557347745793,\"userId\":92005,\"orderNo\":\"ORD2026072914362940120050035\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:29\",\"updatedAt\":\"2026-07-29 14:36:29\"},\"items\":[{\"id\":2082354557368717314,\"orderId\":2082354557347745793,\"userId\":92005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:29\"}]}','2026-07-29 14:36:29'),(2082354825221148674,2082354825120485377,94005,'CREATED','{\"timestamp\":\"2026-07-29T14:37:33.271571415\",\"order\":{\"id\":2082354825120485377,\"userId\":94005,\"orderNo\":\"ORD2026072914373324540050040\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354825137262594,\"orderId\":2082354825120485377,\"userId\":94005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33'),(2082354825435058178,2082354825120485377,94005,'PAID','{\"timestamp\":\"2026-07-29T14:37:33.322644380\",\"order\":{\"id\":2082354825120485377,\"userId\":94005,\"orderNo\":\"ORD2026072914373324540050040\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354825137262594,\"orderId\":2082354825120485377,\"userId\":94005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33'),(2082362107707297794,2082354557347745793,92005,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-07-29T15:06:29.551951681\",\"order\":{\"id\":2082354557347745793,\"userId\":92005,\"orderNo\":\"ORD2026072914362940120050035\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:29\",\"updatedAt\":\"2026-07-29 15:06:29\"},\"items\":[{\"id\":2082354557368717314,\"orderId\":2082354557347745793,\"userId\":92005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:29\"}]}','2026-07-29 15:06:29');
/*!40000 ALTER TABLE `t_order_snapshot_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_2`
--

DROP TABLE IF EXISTS `t_order_snapshot_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_2` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_2`
--

LOCK TABLES `t_order_snapshot_2` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_2` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_2` VALUES (2082354229558751234,2082354229479059458,91001,'CREATED','{\"timestamp\":\"2026-07-29T14:35:11.254529266\",\"order\":{\"id\":2082354229479059458,\"userId\":91001,\"orderNo\":\"ORD2026072914351123410010021\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354229500030977,\"orderId\":2082354229479059458,\"userId\":91001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2082354229764272130,2082354229479059458,91001,'PAID','{\"timestamp\":\"2026-07-29T14:35:11.303274386\",\"order\":{\"id\":2082354229479059458,\"userId\":91001,\"orderNo\":\"ORD2026072914351123410010021\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354229500030977,\"orderId\":2082354229479059458,\"userId\":91001,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2084534107842334721,2084534107729088513,1001,'CREATED','{\"order\":{\"id\":2084534107729088513,\"userId\":1001,\"orderNo\":\"ORD2026080414571470310010021\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 14:57:14\",\"updatedAt\":\"2026-08-04 14:57:14\"},\"items\":[{\"id\":2084534107771031554,\"orderId\":2084534107729088513,\"userId\":1001,\"skuId\":2084534106126888961,\"spuId\":2084534106126888961,\"skuName\":\"Mock商品-2084534106126888961\",\"skuImage\":\"https://img.mock.com/sku/2084534106126888961.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 14:57:14\"}],\"timestamp\":\"2026-08-04T14:57:14.736775002\"}','2026-08-04 14:57:14'),(2084534107930415105,2084534107892666369,1001,'CREATED','{\"order\":{\"id\":2084534107892666369,\"userId\":1001,\"orderNo\":\"ORD2026080414571474810010022\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 14:57:14\",\"updatedAt\":\"2026-08-04 14:57:14\"},\"items\":[{\"id\":2084534107901054977,\"orderId\":2084534107892666369,\"userId\":1001,\"skuId\":2084534106550513665,\"spuId\":2084534106550513665,\"skuName\":\"Mock商品-2084534106550513665\",\"skuImage\":\"https://img.mock.com/sku/2084534106550513665.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 14:57:14\"}],\"timestamp\":\"2026-08-04T14:57:14.758010066\"}','2026-08-04 14:57:14'),(2084534108110770177,2084534108052049921,1001,'CREATED','{\"order\":{\"id\":2084534108052049921,\"userId\":1001,\"orderNo\":\"ORD2026080414571477610010023\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 14:57:14\",\"updatedAt\":\"2026-08-04 14:57:14\"},\"items\":[{\"id\":2084534108081410050,\"orderId\":2084534108052049921,\"userId\":1001,\"skuId\":2084534106726674433,\"spuId\":2084534106726674433,\"skuName\":\"Mock商品-2084534106726674433\",\"skuImage\":\"https://img.mock.com/sku/2084534106726674433.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 14:57:14\"}],\"timestamp\":\"2026-08-04T14:57:14.800769289\"}','2026-08-04 14:57:14'),(2084541657954439169,2084534107892666369,1001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2084534107892666369,\"userId\":1001,\"orderNo\":\"ORD2026080414571474810010022\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 14:57:14\",\"updatedAt\":\"2026-08-04 15:27:14\"},\"items\":[{\"id\":2084534107901054977,\"orderId\":2084534107892666369,\"userId\":1001,\"skuId\":2084534106550513665,\"spuId\":2084534106550513665,\"skuName\":\"Mock商品-2084534106550513665\",\"skuImage\":\"https://img.mock.com/sku/2084534106550513665.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 14:57:14\"}],\"timestamp\":\"2026-08-04T15:27:14.824201776\"}','2026-08-04 15:27:14'),(2084541657962827777,2084534107729088513,1001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2084534107729088513,\"userId\":1001,\"orderNo\":\"ORD2026080414571470310010021\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 14:57:14\",\"updatedAt\":\"2026-08-04 15:27:14\"},\"items\":[{\"id\":2084534107771031554,\"orderId\":2084534107729088513,\"userId\":1001,\"skuId\":2084534106126888961,\"spuId\":2084534106126888961,\"skuName\":\"Mock商品-2084534106126888961\",\"skuImage\":\"https://img.mock.com/sku/2084534106126888961.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 14:57:14\"}],\"timestamp\":\"2026-08-04T15:27:14.826130088\"}','2026-08-04 15:27:14'),(2084541658214486018,2084534108052049921,1001,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2084534108052049921,\"userId\":1001,\"orderNo\":\"ORD2026080414571477610010023\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 14:57:14\",\"updatedAt\":\"2026-08-04 15:27:14\"},\"items\":[{\"id\":2084534108081410050,\"orderId\":2084534108052049921,\"userId\":1001,\"skuId\":2084534106726674433,\"spuId\":2084534106726674433,\"skuName\":\"Mock商品-2084534106726674433\",\"skuImage\":\"https://img.mock.com/sku/2084534106726674433.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 14:57:14\"}],\"timestamp\":\"2026-08-04T15:27:14.885773249\"}','2026-08-04 15:27:14');
/*!40000 ALTER TABLE `t_order_snapshot_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_3`
--

DROP TABLE IF EXISTS `t_order_snapshot_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_3` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_3`
--

LOCK TABLES `t_order_snapshot_3` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_3` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_3` VALUES (2082354231190335489,2082354231110643714,91005,'CREATED','{\"timestamp\":\"2026-07-29T14:35:11.643895124\",\"order\":{\"id\":2082354231110643714,\"userId\":91005,\"orderNo\":\"ORD2026072914351162210050025\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354231123226626,\"orderId\":2082354231110643714,\"userId\":91005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2082354231383273473,2082354231110643714,91005,'PAID','{\"timestamp\":\"2026-07-29T14:35:11.690267869\",\"order\":{\"id\":2082354231110643714,\"userId\":91005,\"orderNo\":\"ORD2026072914351162210050025\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354231123226626,\"orderId\":2082354231110643714,\"userId\":91005,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_snapshot_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'my_xhs_order_1'
--

--
-- Dumping routines for database 'my_xhs_order_1'
--

--
-- Current Database: `my_xhs_order_2`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `my_xhs_order_2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `my_xhs_order_2`;

--
-- Table structure for table `t_local_message_0`
--

DROP TABLE IF EXISTS `t_local_message_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_0` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_0`
--

LOCK TABLES `t_local_message_0` WRITE;
/*!40000 ALTER TABLE `t_local_message_0` DISABLE KEYS */;
INSERT INTO `t_local_message_0` VALUES (2082307221384908801,20002,'ORD2026072911282362400020003','order','ORDER_CREATED','{\"timestamp\":1785295703624,\"couponId\":0,\"orderNo\":\"ORD2026072911282362400020003\",\"userId\":20002,\"skuItems\":[{\"skuId\":999,\"quantity\":1}]}',0,0,'2026-07-29 11:28:23','2026-07-29 11:28:23','2026-07-29 11:28:23'),(2082350162379866113,50002,'ORD2026072914190155500020009','order','ORDER_CREATED','{\"timestamp\":1785305941555,\"couponId\":0,\"orderNo\":\"ORD2026072914190155500020009\",\"userId\":50002,\"skuItems\":[{\"skuId\":999,\"quantity\":1}]}',0,0,'2026-07-29 14:19:01','2026-07-29 14:19:01','2026-07-29 14:19:01'),(2082354037044391938,90002,'ORD2026072914342534300020017','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914342534300020017\",\"couponId\":0,\"timestamp\":1785306865343,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":90002}',0,0,'2026-07-29 14:34:25','2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354555724550145,92002,'ORD2026072914362900620020032','order','ORDER_CREATED','{\"couponId\":0,\"timestamp\":1785306989007,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":92002,\"orderNo\":\"ORD2026072914362900620020032\"}',0,0,'2026-07-29 14:36:29','2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354815083515906,94002,'ORD2026072914373084340020037','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914373084340020037\",\"couponId\":0,\"timestamp\":1785307050844,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":94002}',0,0,'2026-07-29 14:37:30','2026-07-29 14:37:30','2026-07-29 14:37:30'),(2082355472167374849,10002,'ORD2026072914400750800020045','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914400750800020045\",\"couponId\":0,\"timestamp\":1785307207508,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":10002}',0,0,'2026-07-29 14:40:07','2026-07-29 14:40:07','2026-07-29 14:40:07'),(2084174560158064641,2084174559629565954,'ORD2026080315083188359540011','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084174559629565954,\"orderNo\":\"ORD2026080315083188359540011\",\"couponId\":0,\"timestamp\":1785740911883}',0,0,'2026-08-03 15:08:31','2026-08-03 15:08:31','2026-08-03 15:08:31'),(2084174840660533250,2084174840186560514,'ORD2026080315093876005140012','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084174840186560514,\"orderNo\":\"ORD2026080315093876005140012\",\"couponId\":0,\"timestamp\":1785740978760}',0,0,'2026-08-03 15:09:38','2026-08-03 15:09:38','2026-08-03 15:09:38'),(2084481454542213121,2084481453887877122,'ORD2026080411280119071220002','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084481453887877122,\"orderNo\":\"ORD2026080411280119071220002\",\"couponId\":0,\"timestamp\":1785814081192}',0,0,'2026-08-04 11:28:01','2026-08-04 11:28:01','2026-08-04 11:28:01'),(2084481455515291649,2084481453887877122,'ORD2026080411280143971220003','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084481453887877122,\"orderNo\":\"ORD2026080411280143971220003\",\"couponId\":0,\"timestamp\":1785814081439}',0,0,'2026-08-04 11:28:01','2026-08-04 11:28:01','2026-08-04 11:28:01'),(2084482285572247553,2084482285106655234,'ORD2026080411311933652340006','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2,\"quantity\":1}],\"userId\":2084482285106655234,\"orderNo\":\"ORD2026080411311933652340006\",\"couponId\":0,\"timestamp\":1785814279336}',0,0,'2026-08-04 11:31:19','2026-08-04 11:31:19','2026-08-04 11:31:19'),(2084482322163355650,2084482321718734850,'ORD2026080411312806348500007','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084482321718734850,\"orderNo\":\"ORD2026080411312806348500007\",\"couponId\":0,\"timestamp\":1785814288063}',0,0,'2026-08-04 11:31:28','2026-08-04 11:31:28','2026-08-04 11:31:28'),(2084482322888970242,2084482321718734850,'ORD2026080411312823548500008','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084482321718734850,\"orderNo\":\"ORD2026080411312823548500008\",\"couponId\":0,\"timestamp\":1785814288235}',0,0,'2026-08-04 11:31:28','2026-08-04 11:31:28','2026-08-04 11:31:28'),(2084482431626301441,2084482431185874946,'ORD2026080411315416149460009','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084482431185874946,\"orderNo\":\"ORD2026080411315416149460009\",\"couponId\":0,\"timestamp\":1785814314161}',0,0,'2026-08-04 11:31:54','2026-08-04 11:31:54','2026-08-04 11:31:54'),(2084482432280612865,2084482431185874946,'ORD2026080411315431949460010','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084482431185874946,\"orderNo\":\"ORD2026080411315431949460010\",\"couponId\":0,\"timestamp\":1785814314319}',0,0,'2026-08-04 11:31:54','2026-08-04 11:31:54','2026-08-04 11:31:54'),(2084482875660488706,2084482875220062210,'ORD2026080411334002722100012','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2,\"quantity\":1}],\"userId\":2084482875220062210,\"orderNo\":\"ORD2026080411334002722100012\",\"couponId\":0,\"timestamp\":1785814420028}',0,0,'2026-08-04 11:33:40','2026-08-04 11:33:40','2026-08-04 11:33:40'),(2084482875769540609,2084482875220062210,'ORD2026080411334005422100013','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084482875220062210,\"orderNo\":\"ORD2026080411334005422100013\",\"couponId\":0,\"timestamp\":1785814420055}',0,0,'2026-08-04 11:33:40','2026-08-04 11:33:40','2026-08-04 11:33:40'),(2084483279844593666,2084483279391584258,'ORD2026080411351639242580016','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":2}],\"userId\":2084483279391584258,\"orderNo\":\"ORD2026080411351639242580016\",\"couponId\":0,\"timestamp\":1785814516392}',0,0,'2026-08-04 11:35:16','2026-08-04 11:35:16','2026-08-04 11:35:16'),(2084483280473739265,2084483279391584258,'ORD2026080411351654242580017','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":2084483279391584258,\"orderNo\":\"ORD2026080411351654242580017\",\"couponId\":0,\"timestamp\":1785814516543}',0,0,'2026-08-04 11:35:16','2026-08-04 11:35:16','2026-08-04 11:35:16'),(2084483922533601281,2084483922097369090,'ORD2026080411374962290900020','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2,\"quantity\":1}],\"userId\":2084483922097369090,\"orderNo\":\"ORD2026080411374962290900020\",\"couponId\":0,\"timestamp\":1785814669622}',0,0,'2026-08-04 11:37:49','2026-08-04 11:37:49','2026-08-04 11:37:49'),(2086000934950907906,2085982901507301378,'ORD2026080816055339313780001','order','ORDER_CREATED','{\"timestamp\":1786176353401,\"couponId\":0,\"orderNo\":\"ORD2026080816055339313780001\",\"userId\":2085982901507301378,\"skuItems\":[{\"skuId\":2085989641275572226,\"quantity\":2}]}',0,0,'2026-08-08 16:05:53','2026-08-08 16:05:53','2026-08-08 16:05:53');
/*!40000 ALTER TABLE `t_local_message_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_1`
--

DROP TABLE IF EXISTS `t_local_message_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_1` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_1`
--

LOCK TABLES `t_local_message_1` WRITE;
/*!40000 ALTER TABLE `t_local_message_1` DISABLE KEYS */;
INSERT INTO `t_local_message_1` VALUES (2082354825619607554,94006,'ORD2026072914373335540060041','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914373335540060041\",\"couponId\":0,\"timestamp\":1785307053355,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":94006}',0,0,'2026-07-29 14:37:33','2026-07-29 14:37:33','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_local_message_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_2`
--

DROP TABLE IF EXISTS `t_local_message_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_2` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_2`
--

LOCK TABLES `t_local_message_2` WRITE;
/*!40000 ALTER TABLE `t_local_message_2` DISABLE KEYS */;
INSERT INTO `t_local_message_2` VALUES (2082354229927849986,91002,'ORD2026072914351133610020022','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351133610020022\",\"couponId\":0,\"timestamp\":1785306911337,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":91002}',0,0,'2026-07-29 14:35:11','2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354233065189378,910010,'ORD2026072914351208400100030','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351208400100030\",\"couponId\":0,\"timestamp\":1785306912085,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":910010}',0,0,'2026-07-29 14:35:12','2026-07-29 14:35:12','2026-07-29 14:35:12');
/*!40000 ALTER TABLE `t_local_message_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_3`
--

DROP TABLE IF EXISTS `t_local_message_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_3` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_3`
--

LOCK TABLES `t_local_message_3` WRITE;
/*!40000 ALTER TABLE `t_local_message_3` DISABLE KEYS */;
INSERT INTO `t_local_message_3` VALUES (2082354231563628545,91006,'ORD2026072914351172410060026','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351172410060026\",\"couponId\":0,\"timestamp\":1785306911725,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":91006}',0,0,'2026-07-29 14:35:11','2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_local_message_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_0`
--

DROP TABLE IF EXISTS `t_order_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_0` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_0`
--

LOCK TABLES `t_order_0` WRITE;
/*!40000 ALTER TABLE `t_order_0` DISABLE KEYS */;
INSERT INTO `t_order_0` VALUES (2082307221355548674,20002,'ORD2026072911282362400020003',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 11:28:23','2026-07-29 11:58:23'),(2082350162350505986,50002,'ORD2026072914190155500020009',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:19:01','2026-07-29 14:49:01'),(2082354037010837506,90002,'ORD2026072914342534300020017',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354555686801409,92002,'ORD2026072914362900620020032',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354815049961473,94002,'ORD2026072914373084340020037',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:37:30','2026-07-29 14:37:30'),(2082355472142209026,10002,'ORD2026072914400750800020045',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:40:07','2026-07-29 14:40:07'),(2084174560141287426,2084174559629565954,'ORD2026080315083188359540011',99.00,99.00,0.00,NULL,5,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 15:08:31','2026-08-03 15:15:00'),(2084174840643756033,2084174840186560514,'ORD2026080315093876005140012',99.00,99.00,0.00,NULL,5,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-03 15:09:38','2026-08-03 15:15:00'),(2084481454475104257,2084481453887877122,'ORD2026080411280119071220002',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:28:01','2026-08-04 11:28:01'),(2084481455502708738,2084481453887877122,'ORD2026080411280143971220003',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:28:01','2026-08-04 11:28:01'),(2084482285542887425,2084482285106655234,'ORD2026080411311933652340006',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:31:19','2026-08-04 12:01:19'),(2084482322142384130,2084482321718734850,'ORD2026080411312806348500007',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:31:28','2026-08-04 11:31:28'),(2084482322867998721,2084482321718734850,'ORD2026080411312823548500008',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:31:28','2026-08-04 11:31:28'),(2084482431609524225,2084482431185874946,'ORD2026080411315416149460009',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:31:54','2026-08-04 11:31:54'),(2084482432268029953,2084482431185874946,'ORD2026080411315431949460010',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:31:54','2026-08-04 11:31:54'),(2084482875643711489,2084482875220062210,'ORD2026080411334002722100012',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:33:40','2026-08-04 12:03:40'),(2084482875756957697,2084482875220062210,'ORD2026080411334005422100013',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:33:40','2026-08-04 12:03:40'),(2084483279827816449,2084483279391584258,'ORD2026080411351639242580016',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:35:16','2026-08-04 11:35:16'),(2084483280456962050,2084483279391584258,'ORD2026080411351654242580017',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:35:16','2026-08-04 11:35:16'),(2084483922516824065,2084483922097369090,'ORD2026080411374962290900020',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:37:49','2026-08-04 12:07:49'),(2086000934497923073,2085982901507301378,'ORD2026080816055339313780001',198.00,198.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}','链5重测','2026-08-08 16:06:32','2026-08-08 16:06:53','2026-08-08 16:06:53',NULL,0,'2026-08-08 16:05:53','2026-08-08 16:06:53');
/*!40000 ALTER TABLE `t_order_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_1`
--

DROP TABLE IF EXISTS `t_order_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_1` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_1`
--

LOCK TABLES `t_order_1` WRITE;
/*!40000 ALTER TABLE `t_order_1` DISABLE KEYS */;
INSERT INTO `t_order_1` VALUES (2082354825581858818,94006,'ORD2026072914373335540060041',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:37:33','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_2`
--

DROP TABLE IF EXISTS `t_order_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_2` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_2`
--

LOCK TABLES `t_order_2` WRITE;
/*!40000 ALTER TABLE `t_order_2` DISABLE KEYS */;
INSERT INTO `t_order_2` VALUES (2082354229911072770,91002,'ORD2026072914351133610020022',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354233048412161,910010,'ORD2026072914351208400100030',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:12','2026-07-29 14:35:12');
/*!40000 ALTER TABLE `t_order_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_3`
--

DROP TABLE IF EXISTS `t_order_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_3` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_3`
--

LOCK TABLES `t_order_3` WRITE;
/*!40000 ALTER TABLE `t_order_3` DISABLE KEYS */;
INSERT INTO `t_order_3` VALUES (2082354231538462721,91006,'ORD2026072914351172410060026',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_0`
--

DROP TABLE IF EXISTS `t_order_event_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_0` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1292880841669427201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_0`
--

LOCK TABLES `t_order_event_0` WRITE;
/*!40000 ALTER TABLE `t_order_event_0` DISABLE KEYS */;
INSERT INTO `t_order_event_0` VALUES (1289194427958247424,2082307221355548674,20002,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-07-29T11:58:23.690937832\",\"cancelReason\":\"超时未支付\"}',1,'2026-07-29 11:58:23.699','2026-07-29 11:58:23'),(1289233693799170049,2082354037010837506,90002,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:34:25.398103016\"}',1,'2026-07-29 14:34:25.405','2026-07-29 14:34:25'),(1289234212571660289,2082354555686801409,92002,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:36:29.078467853\"}',1,'2026-07-29 14:36:29.090','2026-07-29 14:36:29'),(1289234471880310785,2082354815049961473,94002,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"支付失败\",\"cancelTime\":\"2026-07-29T14:37:30.903568539\"}',1,'2026-07-29 14:37:30.914','2026-07-29 14:37:30'),(1289235128901255168,2082355472142209026,10002,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-07-29T14:40:07.551690375\"}',1,'2026-07-29 14:40:07.560','2026-07-29 14:40:07'),(1289237368877694977,2082350162350505986,50002,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-29T14:49:01.601806150\"}',1,'2026-07-29 14:49:01.611','2026-07-29 14:49:01'),(1291054218401890304,2084174560141287426,2084174559629565954,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-03T15:08:32.284587353\"}',1,'2026-08-03 15:08:32.294','2026-08-03 15:08:32'),(1291054497377632257,2084174840643756033,2084174840186560514,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-03T15:09:38.799749295\"}',1,'2026-08-03 15:09:38.807','2026-08-03 15:09:38'),(1291055844760043520,2084174560141287426,2084174559629565954,'ORDER_REFUNDED',1,5,'{\"refundTime\":\"2026-08-03T15:15:00.041600872\"}',2,'2026-08-03 15:15:00.049','2026-08-03 15:15:00'),(1291055844919427073,2084174840643756033,2084174840186560514,'ORDER_REFUNDED',1,5,'{\"refundTime\":\"2026-08-03T15:15:00.078981899\"}',2,'2026-08-03 15:15:00.086','2026-08-03 15:15:00'),(1291361111548706817,2084481454475104257,2084481453887877122,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-04T11:28:01.308436188\"}',1,'2026-08-04 11:28:01.322','2026-08-04 11:28:01'),(1291361111791976448,2084481454475104257,2084481453887877122,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-04T11:28:01.372245664\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-04 11:28:01.381','2026-08-04 11:28:01'),(1291361111934582785,2084481454475104257,2084481453887877122,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-04T11:28:01.409241034\"}',3,'2026-08-04 11:28:01.414','2026-08-04 11:28:01'),(1291361112223989760,2084481455502708738,2084481453887877122,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-04T11:28:01.476680519\"}',1,'2026-08-04 11:28:01.483','2026-08-04 11:28:01'),(1291361979023048705,2084482322142384130,2084482321718734850,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-04T11:31:28.135639974\"}',1,'2026-08-04 11:31:28.144','2026-08-04 11:31:28'),(1291361979195015168,2084482322142384130,2084482321718734850,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-04T11:31:28.180626638\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-04 11:31:28.186','2026-08-04 11:31:28'),(1291361979312455681,2084482322142384130,2084482321718734850,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-04T11:31:28.208076004\"}',3,'2026-08-04 11:31:28.213','2026-08-04 11:31:28'),(1291361979559919616,2084482322867998721,2084482321718734850,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-04T11:31:28.265079434\"}',1,'2026-08-04 11:31:28.272','2026-08-04 11:31:28'),(1291362088444051457,2084482431609524225,2084482431185874946,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-04T11:31:54.224930211\"}',1,'2026-08-04 11:31:54.232','2026-08-04 11:31:54'),(1291362088590852096,2084482431609524225,2084482431185874946,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-04T11:31:54.262254005\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-04 11:31:54.267','2026-08-04 11:31:54'),(1291362088720875521,2084482431609524225,2084482431185874946,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-04T11:31:54.291010965\"}',3,'2026-08-04 11:31:54.296','2026-08-04 11:31:54'),(1291362088934785024,2084482432268029953,2084482431185874946,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-04T11:31:54.345030292\"}',1,'2026-08-04 11:31:54.349','2026-08-04 11:31:54'),(1291362936649760769,2084483279827816449,2084483279391584258,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-04T11:35:16.453631860\"}',1,'2026-08-04 11:35:16.461','2026-08-04 11:35:16'),(1291362936804950016,2084483279827816449,2084483279391584258,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"deliveredTime\":\"2026-08-04T11:35:16.492378677\",\"trackingNo\":\"SF00000001\"}',2,'2026-08-04 11:35:16.497','2026-08-04 11:35:16'),(1291362936914001921,2084483279827816449,2084483279391584258,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-04T11:35:16.518543247\"}',3,'2026-08-04 11:35:16.523','2026-08-04 11:35:16'),(1291362937132105728,2084483280456962050,2084483279391584258,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"用户主动取消\",\"cancelTime\":\"2026-08-04T11:35:16.570632283\"}',1,'2026-08-04 11:35:16.575','2026-08-04 11:35:16'),(1291369492250443777,2084482285542887425,2084482285106655234,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-04T12:01:19.421250503\"}',1,'2026-08-04 12:01:19.436','2026-08-04 12:01:19'),(1291370082384822273,2084482875643711489,2084482875220062210,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-04T12:03:40.130142202\"}',1,'2026-08-04 12:03:40.136','2026-08-04 12:03:40'),(1291370082418376704,2084482875756957697,2084482875220062210,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-04T12:03:40.130736320\"}',1,'2026-08-04 12:03:40.145','2026-08-04 12:03:40'),(1291371129266323457,2084483922516824065,2084483922097369090,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-04T12:07:49.725841486\"}',1,'2026-08-04 12:07:49.732','2026-08-04 12:07:49'),(1292880753261887488,2086000934497923073,2085982901507301378,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-08-08T16:06:32.076227274\"}',1,'2026-08-08 16:06:32.137','2026-08-08 16:06:32'),(1292880841484877825,2086000934497923073,2085982901507301378,'ORDER_DELIVERED',1,2,'{\"logisticsCompany\":\"SF\",\"trackingNo\":\"SF123456\",\"deliveredTime\":\"2026-08-08T16:06:53.164014686\"}',2,'2026-08-08 16:06:53.174','2026-08-08 16:06:53'),(1292880841669427200,2086000934497923073,2085982901507301378,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-08-08T16:06:53.211767341\"}',3,'2026-08-08 16:06:53.218','2026-08-08 16:06:53');
/*!40000 ALTER TABLE `t_order_event_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_1`
--

DROP TABLE IF EXISTS `t_order_event_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_1` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289234482361876482 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_1`
--

LOCK TABLES `t_order_event_1` WRITE;
/*!40000 ALTER TABLE `t_order_event_1` DISABLE KEYS */;
INSERT INTO `t_order_event_1` VALUES (1289234482361876481,2082354825581858818,94006,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:37:33.406900242\"}',1,'2026-07-29 14:37:33.413','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_event_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_2`
--

DROP TABLE IF EXISTS `t_order_event_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_2` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289233889782218753 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_2`
--

LOCK TABLES `t_order_event_2` WRITE;
/*!40000 ALTER TABLE `t_order_event_2` DISABLE KEYS */;
INSERT INTO `t_order_event_2` VALUES (1289233886644879360,2082354229911072770,91002,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:11.376871572\"}',1,'2026-07-29 14:35:11.383','2026-07-29 14:35:11'),(1289233889782218752,2082354233048412161,910010,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:12.126153858\"}',1,'2026-07-29 14:35:12.131','2026-07-29 14:35:12');
/*!40000 ALTER TABLE `t_order_event_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_3`
--

DROP TABLE IF EXISTS `t_order_event_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_3` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289233888305823745 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_3`
--

LOCK TABLES `t_order_event_3` WRITE;
/*!40000 ALTER TABLE `t_order_event_3` DISABLE KEYS */;
INSERT INTO `t_order_event_3` VALUES (1289233888305823744,2082354231538462721,91006,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:11.773179225\"}',1,'2026-07-29 14:35:11.779','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_event_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_0`
--

DROP TABLE IF EXISTS `t_order_item_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_0` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_0`
--

LOCK TABLES `t_order_item_0` WRITE;
/*!40000 ALTER TABLE `t_order_item_0` DISABLE KEYS */;
INSERT INTO `t_order_item_0` VALUES (2082307221376520194,2082307221355548674,20002,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 11:28:23'),(2082350162371477505,2082350162350505986,50002,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:19:01'),(2082354037031809026,2082354037010837506,90002,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:34:25'),(2082354555707772929,2082354555686801409,92002,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:36:29'),(2082354815070932993,2082354815049961473,94002,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:37:30'),(2082355472158986242,2082355472142209026,10002,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:40:07'),(2084174560153870337,2084174560141287426,2084174559629565954,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 15:08:31'),(2084174840652144641,2084174840643756033,2084174840186560514,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-03 15:09:38'),(2084481454508658690,2084481454475104257,2084481453887877122,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-04 11:28:01'),(2084481455511097346,2084481455502708738,2084481453887877122,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-04 11:28:01'),(2084482285559664642,2084482285542887425,2084482285106655234,2,2,'Mock商品-2','https://img.mock.com/sku/2.jpg',99.00,1,99.00,'2026-08-04 11:31:19'),(2084482322154967041,2084482322142384130,2084482321718734850,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-04 11:31:28'),(2084482322876387329,2084482322867998721,2084482321718734850,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-04 11:31:28'),(2084482431622107138,2084482431609524225,2084482431185874946,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-04 11:31:54'),(2084482432276418561,2084482432268029953,2084482431185874946,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-04 11:31:54'),(2084482875656294402,2084482875643711489,2084482875220062210,2,2,'Mock商品-2','https://img.mock.com/sku/2.jpg',99.00,1,99.00,'2026-08-04 11:33:40'),(2084482875765346305,2084482875756957697,2084482875220062210,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-04 11:33:40'),(2084483279840399362,2084483279827816449,2084483279391584258,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,2,198.00,'2026-08-04 11:35:16'),(2084483280469544962,2084483280456962050,2084483279391584258,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-08-04 11:35:16'),(2084483922529406977,2084483922516824065,2084483922097369090,2,2,'Mock商品-2','https://img.mock.com/sku/2.jpg',99.00,1,99.00,'2026-08-04 11:37:49'),(2086000934867021825,2086000934497923073,2085982901507301378,2085989641275572226,2085989545951625217,'链2SKU-红色L',NULL,99.00,2,198.00,'2026-08-08 16:05:53');
/*!40000 ALTER TABLE `t_order_item_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_1`
--

DROP TABLE IF EXISTS `t_order_item_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_1` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_1`
--

LOCK TABLES `t_order_item_1` WRITE;
/*!40000 ALTER TABLE `t_order_item_1` DISABLE KEYS */;
INSERT INTO `t_order_item_1` VALUES (2082354825607024641,2082354825581858818,94006,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_item_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_2`
--

DROP TABLE IF EXISTS `t_order_item_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_2` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_2`
--

LOCK TABLES `t_order_item_2` WRITE;
/*!40000 ALTER TABLE `t_order_item_2` DISABLE KEYS */;
INSERT INTO `t_order_item_2` VALUES (2082354229923655681,2082354229911072770,91002,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:11'),(2082354233056800770,2082354233048412161,910010,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:12');
/*!40000 ALTER TABLE `t_order_item_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_3`
--

DROP TABLE IF EXISTS `t_order_item_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_3` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_3`
--

LOCK TABLES `t_order_item_3` WRITE;
/*!40000 ALTER TABLE `t_order_item_3` DISABLE KEYS */;
INSERT INTO `t_order_item_3` VALUES (2082354231555239937,2082354231538462721,91006,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_item_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_0`
--

DROP TABLE IF EXISTS `t_order_snapshot_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_0` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_0`
--

LOCK TABLES `t_order_snapshot_0` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_0` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_0` VALUES (2082307221460406274,2082307221355548674,20002,'CREATED','{\"items\":[{\"id\":2082307221376520194,\"orderId\":2082307221355548674,\"userId\":20002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 11:28:23\"}],\"order\":{\"id\":2082307221355548674,\"userId\":20002,\"orderNo\":\"ORD2026072911282362400020003\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 11:28:23\",\"updatedAt\":\"2026-07-29 11:28:23\"},\"timestamp\":\"2026-07-29T11:28:23.650138056\"}','2026-07-29 11:28:23'),(2082314771484430337,2082307221355548674,20002,'TIMEOUT_CANCELLED','{\"items\":[{\"id\":2082307221376520194,\"orderId\":2082307221355548674,\"userId\":20002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 11:28:23\"}],\"order\":{\"id\":2082307221355548674,\"userId\":20002,\"orderNo\":\"ORD2026072911282362400020003\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 11:28:23\",\"updatedAt\":\"2026-07-29 11:58:23\"},\"timestamp\":\"2026-07-29T11:58:23.715867745\"}','2026-07-29 11:58:23'),(2082350162421809154,2082350162350505986,50002,'CREATED','{\"order\":{\"id\":2082350162350505986,\"userId\":50002,\"orderNo\":\"ORD2026072914190155500020009\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:19:01\",\"updatedAt\":\"2026-07-29 14:19:01\"},\"timestamp\":\"2026-07-29T14:19:01.574298911\",\"items\":[{\"id\":2082350162371477505,\"orderId\":2082350162350505986,\"userId\":50002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:19:01\"}]}','2026-07-29 14:19:01'),(2082354037107306497,2082354037010837506,90002,'CREATED','{\"timestamp\":\"2026-07-29T14:34:25.371120011\",\"order\":{\"id\":2082354037010837506,\"userId\":90002,\"orderNo\":\"ORD2026072914342534300020017\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354037031809026,\"orderId\":2082354037010837506,\"userId\":90002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354037304438786,2082354037010837506,90002,'PAID','{\"timestamp\":\"2026-07-29T14:34:25.417919158\",\"order\":{\"id\":2082354037010837506,\"userId\":90002,\"orderNo\":\"ORD2026072914342534300020017\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354037031809026,\"orderId\":2082354037010837506,\"userId\":90002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354555812630530,2082354555686801409,92002,'CREATED','{\"timestamp\":\"2026-07-29T14:36:29.039440099\",\"order\":{\"id\":2082354555686801409,\"userId\":92002,\"orderNo\":\"ORD2026072914362900620020032\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:29\",\"updatedAt\":\"2026-07-29 14:36:29\"},\"items\":[{\"id\":2082354555707772929,\"orderId\":2082354555686801409,\"userId\":92002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:29\"}]}','2026-07-29 14:36:29'),(2082354556123009025,2082354555686801409,92002,'PAID','{\"timestamp\":\"2026-07-29T14:36:29.113640963\",\"order\":{\"id\":2082354555686801409,\"userId\":92002,\"orderNo\":\"ORD2026072914362900620020032\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:29\",\"updatedAt\":\"2026-07-29 14:36:29\"},\"items\":[{\"id\":2082354555707772929,\"orderId\":2082354555686801409,\"userId\":92002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:29\"}]}','2026-07-29 14:36:29'),(2082354815146430466,2082354815049961473,94002,'CREATED','{\"timestamp\":\"2026-07-29T14:37:30.869974980\",\"order\":{\"id\":2082354815049961473,\"userId\":94002,\"orderNo\":\"ORD2026072914373084340020037\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:30\",\"updatedAt\":\"2026-07-29 14:37:30\"},\"items\":[{\"id\":2082354815070932993,\"orderId\":2082354815049961473,\"userId\":94002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:30\"}]}','2026-07-29 14:37:30'),(2082354815444226049,2082354815049961473,94002,'CANCELLED','{\"timestamp\":\"2026-07-29T14:37:30.940612061\",\"order\":{\"id\":2082354815049961473,\"userId\":94002,\"orderNo\":\"ORD2026072914373084340020037\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:30\",\"updatedAt\":\"2026-07-29 14:37:30\"},\"items\":[{\"id\":2082354815070932993,\"orderId\":2082354815049961473,\"userId\":94002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:30\"}]}','2026-07-29 14:37:30'),(2082355472209317889,2082355472142209026,10002,'CREATED','{\"timestamp\":\"2026-07-29T14:40:07.526167912\",\"order\":{\"id\":2082355472142209026,\"userId\":10002,\"orderNo\":\"ORD2026072914400750800020045\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:07\",\"updatedAt\":\"2026-07-29 14:40:07\"},\"items\":[{\"id\":2082355472158986242,\"orderId\":2082355472142209026,\"userId\":10002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:07\"}]}','2026-07-29 14:40:07'),(2082355472427421697,2082355472142209026,10002,'CANCELLED','{\"timestamp\":\"2026-07-29T14:40:07.578210039\",\"order\":{\"id\":2082355472142209026,\"userId\":10002,\"orderNo\":\"ORD2026072914400750800020045\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:07\",\"updatedAt\":\"2026-07-29 14:40:07\"},\"items\":[{\"id\":2082355472158986242,\"orderId\":2082355472142209026,\"userId\":10002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:07\"}]}','2026-07-29 14:40:07'),(2082357712403861505,2082350162350505986,50002,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-07-29T14:49:01.629892370\",\"order\":{\"id\":2082350162350505986,\"userId\":50002,\"orderNo\":\"ORD2026072914190155500020009\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:19:01\",\"updatedAt\":\"2026-07-29 14:49:01\"},\"items\":[{\"id\":2082350162371477505,\"orderId\":2082350162350505986,\"userId\":50002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:19:01\"}]}','2026-07-29 14:49:01'),(2084174560183230465,2084174560141287426,2084174559629565954,'CREATED','{\"order\":{\"id\":2084174560141287426,\"userId\":2084174559629565954,\"orderNo\":\"ORD2026080315083188359540011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 15:08:31\",\"updatedAt\":\"2026-08-03 15:08:31\"},\"items\":[{\"id\":2084174560153870337,\"orderId\":2084174560141287426,\"userId\":2084174559629565954,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 15:08:31\"}],\"timestamp\":\"2026-08-03T15:08:31.895843077\"}','2026-08-03 15:08:31'),(2084174561894506497,2084174560141287426,2084174559629565954,'PAID','{\"order\":{\"id\":2084174560141287426,\"userId\":2084174559629565954,\"orderNo\":\"ORD2026080315083188359540011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 15:08:31\",\"updatedAt\":\"2026-08-03 15:08:32\"},\"items\":[{\"id\":2084174560153870337,\"orderId\":2084174560141287426,\"userId\":2084174559629565954,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 15:08:31\"}],\"timestamp\":\"2026-08-03T15:08:32.303300007\"}','2026-08-03 15:08:32'),(2084174840681504769,2084174840643756033,2084174840186560514,'CREATED','{\"order\":{\"id\":2084174840643756033,\"userId\":2084174840186560514,\"orderNo\":\"ORD2026080315093876005140012\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 15:09:38\",\"updatedAt\":\"2026-08-03 15:09:38\"},\"items\":[{\"id\":2084174840652144641,\"orderId\":2084174840643756033,\"userId\":2084174840186560514,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 15:09:38\"}],\"timestamp\":\"2026-08-03T15:09:38.771551307\"}','2026-08-03 15:09:38'),(2084174840861859841,2084174840643756033,2084174840186560514,'PAID','{\"order\":{\"id\":2084174840643756033,\"userId\":2084174840186560514,\"orderNo\":\"ORD2026080315093876005140012\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 15:09:38\",\"updatedAt\":\"2026-08-03 15:09:38\"},\"items\":[{\"id\":2084174840652144641,\"orderId\":2084174840643756033,\"userId\":2084174840186560514,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 15:09:38\"}],\"timestamp\":\"2026-08-03T15:09:38.813987797\"}','2026-08-03 15:09:38'),(2084176188282019842,2084174560141287426,2084174559629565954,'REFUNDED','{\"order\":{\"id\":2084174560141287426,\"userId\":2084174559629565954,\"orderNo\":\"ORD2026080315083188359540011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":5,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 15:08:31\",\"updatedAt\":\"2026-08-03 15:15:00\"},\"items\":[{\"id\":2084174560153870337,\"orderId\":2084174560141287426,\"userId\":2084174559629565954,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 15:08:31\"}],\"timestamp\":\"2026-08-03T15:15:00.064311376\"}','2026-08-03 15:15:00'),(2084176188437209090,2084174840643756033,2084174840186560514,'REFUNDED','{\"order\":{\"id\":2084174840643756033,\"userId\":2084174840186560514,\"orderNo\":\"ORD2026080315093876005140012\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":5,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-03 15:09:38\",\"updatedAt\":\"2026-08-03 15:15:00\"},\"items\":[{\"id\":2084174840652144641,\"orderId\":2084174840643756033,\"userId\":2084174840186560514,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-03 15:09:38\"}],\"timestamp\":\"2026-08-03T15:15:00.101208904\"}','2026-08-03 15:15:00'),(2084481454579961858,2084481454475104257,2084481453887877122,'CREATED','{\"order\":{\"id\":2084481454475104257,\"userId\":2084481453887877122,\"orderNo\":\"ORD2026080411280119071220002\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:01\",\"updatedAt\":\"2026-08-04 11:28:01\"},\"items\":[{\"id\":2084481454508658690,\"orderId\":2084481454475104257,\"userId\":2084481453887877122,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:28:01\"}],\"timestamp\":\"2026-08-04T11:28:01.220552361\"}','2026-08-04 11:28:01'),(2084481455053918210,2084481454475104257,2084481453887877122,'PAID','{\"order\":{\"id\":2084481454475104257,\"userId\":2084481453887877122,\"orderNo\":\"ORD2026080411280119071220002\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:01\",\"updatedAt\":\"2026-08-04 11:28:01\"},\"items\":[{\"id\":2084481454508658690,\"orderId\":2084481454475104257,\"userId\":2084481453887877122,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:28:01\"}],\"timestamp\":\"2026-08-04T11:28:01.333936742\"}','2026-08-04 11:28:01'),(2084481455288799233,2084481454475104257,2084481453887877122,'DELIVERED','{\"order\":{\"id\":2084481454475104257,\"userId\":2084481453887877122,\"orderNo\":\"ORD2026080411280119071220002\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:01\",\"updatedAt\":\"2026-08-04 11:28:01\"},\"items\":[{\"id\":2084481454508658690,\"orderId\":2084481454475104257,\"userId\":2084481453887877122,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:28:01\"}],\"timestamp\":\"2026-08-04T11:28:01.390151146\"}','2026-08-04 11:28:01'),(2084481455431405569,2084481454475104257,2084481453887877122,'COMPLETED','{\"order\":{\"id\":2084481454475104257,\"userId\":2084481453887877122,\"orderNo\":\"ORD2026080411280119071220002\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:01\",\"updatedAt\":\"2026-08-04 11:28:01\"},\"items\":[{\"id\":2084481454508658690,\"orderId\":2084481454475104257,\"userId\":2084481453887877122,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:28:01\"}],\"timestamp\":\"2026-08-04T11:28:01.422908407\"}','2026-08-04 11:28:01'),(2084481455561428993,2084481455502708738,2084481453887877122,'CREATED','{\"order\":{\"id\":2084481455502708738,\"userId\":2084481453887877122,\"orderNo\":\"ORD2026080411280143971220003\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:01\",\"updatedAt\":\"2026-08-04 11:28:01\"},\"items\":[{\"id\":2084481455511097346,\"orderId\":2084481455502708738,\"userId\":2084481453887877122,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:28:01\"}],\"timestamp\":\"2026-08-04T11:28:01.452134598\"}','2026-08-04 11:28:01'),(2084481455787921410,2084481455502708738,2084481453887877122,'CANCELLED','{\"order\":{\"id\":2084481455502708738,\"userId\":2084481453887877122,\"orderNo\":\"ORD2026080411280143971220003\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:28:01\",\"updatedAt\":\"2026-08-04 11:28:01\"},\"items\":[{\"id\":2084481455511097346,\"orderId\":2084481455502708738,\"userId\":2084481453887877122,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:28:01\"}],\"timestamp\":\"2026-08-04T11:28:01.508716594\"}','2026-08-04 11:28:01'),(2084482285605801986,2084482285542887425,2084482285106655234,'CREATED','{\"order\":{\"id\":2084482285542887425,\"userId\":2084482285106655234,\"orderNo\":\"ORD2026080411311933652340006\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:19\",\"updatedAt\":\"2026-08-04 11:31:19\"},\"items\":[{\"id\":2084482285559664642,\"orderId\":2084482285542887425,\"userId\":2084482285106655234,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:31:19\"}],\"timestamp\":\"2026-08-04T11:31:19.353370053\"}','2026-08-04 11:31:19'),(2084482322188521474,2084482322142384130,2084482321718734850,'CREATED','{\"order\":{\"id\":2084482322142384130,\"userId\":2084482321718734850,\"orderNo\":\"ORD2026080411312806348500007\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:28\",\"updatedAt\":\"2026-08-04 11:31:28\"},\"items\":[{\"id\":2084482322154967041,\"orderId\":2084482322142384130,\"userId\":2084482321718734850,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:31:28\"}],\"timestamp\":\"2026-08-04T11:31:28.075192451\"}','2026-08-04 11:31:28'),(2084482322511482881,2084482322142384130,2084482321718734850,'PAID','{\"order\":{\"id\":2084482322142384130,\"userId\":2084482321718734850,\"orderNo\":\"ORD2026080411312806348500007\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:28\",\"updatedAt\":\"2026-08-04 11:31:28\"},\"items\":[{\"id\":2084482322154967041,\"orderId\":2084482322142384130,\"userId\":2084482321718734850,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:31:28\"}],\"timestamp\":\"2026-08-04T11:31:28.151820880\"}','2026-08-04 11:31:28'),(2084482322683449346,2084482322142384130,2084482321718734850,'DELIVERED','{\"order\":{\"id\":2084482322142384130,\"userId\":2084482321718734850,\"orderNo\":\"ORD2026080411312806348500007\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:28\",\"updatedAt\":\"2026-08-04 11:31:28\"},\"items\":[{\"id\":2084482322154967041,\"orderId\":2084482322142384130,\"userId\":2084482321718734850,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:31:28\"}],\"timestamp\":\"2026-08-04T11:31:28.193375990\"}','2026-08-04 11:31:28'),(2084482322800889858,2084482322142384130,2084482321718734850,'COMPLETED','{\"order\":{\"id\":2084482322142384130,\"userId\":2084482321718734850,\"orderNo\":\"ORD2026080411312806348500007\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:28\",\"updatedAt\":\"2026-08-04 11:31:28\"},\"items\":[{\"id\":2084482322154967041,\"orderId\":2084482322142384130,\"userId\":2084482321718734850,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:31:28\"}],\"timestamp\":\"2026-08-04T11:31:28.221273296\"}','2026-08-04 11:31:28'),(2084482322914136065,2084482322867998721,2084482321718734850,'CREATED','{\"order\":{\"id\":2084482322867998721,\"userId\":2084482321718734850,\"orderNo\":\"ORD2026080411312823548500008\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:28\",\"updatedAt\":\"2026-08-04 11:31:28\"},\"items\":[{\"id\":2084482322876387329,\"orderId\":2084482322867998721,\"userId\":2084482321718734850,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:31:28\"}],\"timestamp\":\"2026-08-04T11:31:28.248609724\"}','2026-08-04 11:31:28'),(2084482323081908226,2084482322867998721,2084482321718734850,'CANCELLED','{\"order\":{\"id\":2084482322867998721,\"userId\":2084482321718734850,\"orderNo\":\"ORD2026080411312823548500008\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:28\",\"updatedAt\":\"2026-08-04 11:31:28\"},\"items\":[{\"id\":2084482322876387329,\"orderId\":2084482322867998721,\"userId\":2084482321718734850,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:31:28\"}],\"timestamp\":\"2026-08-04T11:31:28.287848461\"}','2026-08-04 11:31:28'),(2084482431659855873,2084482431609524225,2084482431185874946,'CREATED','{\"order\":{\"id\":2084482431609524225,\"userId\":2084482431185874946,\"orderNo\":\"ORD2026080411315416149460009\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:54\",\"updatedAt\":\"2026-08-04 11:31:54\"},\"items\":[{\"id\":2084482431622107138,\"orderId\":2084482431609524225,\"userId\":2084482431185874946,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:31:54\"}],\"timestamp\":\"2026-08-04T11:31:54.175486805\"}','2026-08-04 11:31:54'),(2084482431924097026,2084482431609524225,2084482431185874946,'PAID','{\"order\":{\"id\":2084482431609524225,\"userId\":2084482431185874946,\"orderNo\":\"ORD2026080411315416149460009\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:54\",\"updatedAt\":\"2026-08-04 11:31:54\"},\"items\":[{\"id\":2084482431622107138,\"orderId\":2084482431609524225,\"userId\":2084482431185874946,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:31:54\"}],\"timestamp\":\"2026-08-04T11:31:54.238695074\"}','2026-08-04 11:31:54'),(2084482432087674881,2084482431609524225,2084482431185874946,'DELIVERED','{\"order\":{\"id\":2084482431609524225,\"userId\":2084482431185874946,\"orderNo\":\"ORD2026080411315416149460009\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:54\",\"updatedAt\":\"2026-08-04 11:31:54\"},\"items\":[{\"id\":2084482431622107138,\"orderId\":2084482431609524225,\"userId\":2084482431185874946,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:31:54\"}],\"timestamp\":\"2026-08-04T11:31:54.276929129\"}','2026-08-04 11:31:54'),(2084482432209309698,2084482431609524225,2084482431185874946,'COMPLETED','{\"order\":{\"id\":2084482431609524225,\"userId\":2084482431185874946,\"orderNo\":\"ORD2026080411315416149460009\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:54\",\"updatedAt\":\"2026-08-04 11:31:54\"},\"items\":[{\"id\":2084482431622107138,\"orderId\":2084482431609524225,\"userId\":2084482431185874946,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:31:54\"}],\"timestamp\":\"2026-08-04T11:31:54.306478763\"}','2026-08-04 11:31:54'),(2084482432301584385,2084482432268029953,2084482431185874946,'CREATED','{\"order\":{\"id\":2084482432268029953,\"userId\":2084482431185874946,\"orderNo\":\"ORD2026080411315431949460010\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:54\",\"updatedAt\":\"2026-08-04 11:31:54\"},\"items\":[{\"id\":2084482432276418561,\"orderId\":2084482432268029953,\"userId\":2084482431185874946,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:31:54\"}],\"timestamp\":\"2026-08-04T11:31:54.328723471\"}','2026-08-04 11:31:54'),(2084482432460967937,2084482432268029953,2084482431185874946,'CANCELLED','{\"order\":{\"id\":2084482432268029953,\"userId\":2084482431185874946,\"orderNo\":\"ORD2026080411315431949460010\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:54\",\"updatedAt\":\"2026-08-04 11:31:54\"},\"items\":[{\"id\":2084482432276418561,\"orderId\":2084482432268029953,\"userId\":2084482431185874946,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:31:54\"}],\"timestamp\":\"2026-08-04T11:31:54.365743510\"}','2026-08-04 11:31:54'),(2084482875689848833,2084482875643711489,2084482875220062210,'CREATED','{\"order\":{\"id\":2084482875643711489,\"userId\":2084482875220062210,\"orderNo\":\"ORD2026080411334002722100012\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:40\",\"updatedAt\":\"2026-08-04 11:33:40\"},\"items\":[{\"id\":2084482875656294402,\"orderId\":2084482875643711489,\"userId\":2084482875220062210,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:33:40\"}],\"timestamp\":\"2026-08-04T11:33:40.039663740\"}','2026-08-04 11:33:40'),(2084482875798900738,2084482875756957697,2084482875220062210,'CREATED','{\"order\":{\"id\":2084482875756957697,\"userId\":2084482875220062210,\"orderNo\":\"ORD2026080411334005422100013\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:40\",\"updatedAt\":\"2026-08-04 11:33:40\"},\"items\":[{\"id\":2084482875765346305,\"orderId\":2084482875756957697,\"userId\":2084482875220062210,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:33:40\"}],\"timestamp\":\"2026-08-04T11:33:40.066573376\"}','2026-08-04 11:33:40'),(2084483279869759489,2084483279827816449,2084483279391584258,'CREATED','{\"order\":{\"id\":2084483279827816449,\"userId\":2084483279391584258,\"orderNo\":\"ORD2026080411351639242580016\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:35:16\",\"updatedAt\":\"2026-08-04 11:35:16\"},\"items\":[{\"id\":2084483279840399362,\"orderId\":2084483279827816449,\"userId\":2084483279391584258,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:35:16\"}],\"timestamp\":\"2026-08-04T11:35:16.404478267\"}','2026-08-04 11:35:16'),(2084483280138194946,2084483279827816449,2084483279391584258,'PAID','{\"order\":{\"id\":2084483279827816449,\"userId\":2084483279391584258,\"orderNo\":\"ORD2026080411351639242580016\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:35:16\",\"updatedAt\":\"2026-08-04 11:35:16\"},\"items\":[{\"id\":2084483279840399362,\"orderId\":2084483279827816449,\"userId\":2084483279391584258,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:35:16\"}],\"timestamp\":\"2026-08-04T11:35:16.468449672\"}','2026-08-04 11:35:16'),(2084483280293384193,2084483279827816449,2084483279391584258,'DELIVERED','{\"order\":{\"id\":2084483279827816449,\"userId\":2084483279391584258,\"orderNo\":\"ORD2026080411351639242580016\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:35:16\",\"updatedAt\":\"2026-08-04 11:35:16\"},\"items\":[{\"id\":2084483279840399362,\"orderId\":2084483279827816449,\"userId\":2084483279391584258,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:35:16\"}],\"timestamp\":\"2026-08-04T11:35:16.505382692\"}','2026-08-04 11:35:16'),(2084483280398241793,2084483279827816449,2084483279391584258,'COMPLETED','{\"order\":{\"id\":2084483279827816449,\"userId\":2084483279391584258,\"orderNo\":\"ORD2026080411351639242580016\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:35:16\",\"updatedAt\":\"2026-08-04 11:35:16\"},\"items\":[{\"id\":2084483279840399362,\"orderId\":2084483279827816449,\"userId\":2084483279391584258,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-04 11:35:16\"}],\"timestamp\":\"2026-08-04T11:35:16.530651461\"}','2026-08-04 11:35:16'),(2084483280494710786,2084483280456962050,2084483279391584258,'CREATED','{\"order\":{\"id\":2084483280456962050,\"userId\":2084483279391584258,\"orderNo\":\"ORD2026080411351654242580017\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:35:16\",\"updatedAt\":\"2026-08-04 11:35:16\"},\"items\":[{\"id\":2084483280469544962,\"orderId\":2084483280456962050,\"userId\":2084483279391584258,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:35:16\"}],\"timestamp\":\"2026-08-04T11:35:16.553485446\"}','2026-08-04 11:35:16'),(2084483280658288642,2084483280456962050,2084483279391584258,'CANCELLED','{\"order\":{\"id\":2084483280456962050,\"userId\":2084483279391584258,\"orderNo\":\"ORD2026080411351654242580017\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:35:16\",\"updatedAt\":\"2026-08-04 11:35:16\"},\"items\":[{\"id\":2084483280469544962,\"orderId\":2084483280456962050,\"userId\":2084483279391584258,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:35:16\"}],\"timestamp\":\"2026-08-04T11:35:16.591824689\"}','2026-08-04 11:35:16'),(2084483922558767105,2084483922516824065,2084483922097369090,'CREATED','{\"order\":{\"id\":2084483922516824065,\"userId\":2084483922097369090,\"orderNo\":\"ORD2026080411374962290900020\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:37:49\",\"updatedAt\":\"2026-08-04 11:37:49\"},\"items\":[{\"id\":2084483922529406977,\"orderId\":2084483922516824065,\"userId\":2084483922097369090,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:37:49\"}],\"timestamp\":\"2026-08-04T11:37:49.632793955\"}','2026-08-04 11:37:49'),(2084489835801792513,2084482285542887425,2084482285106655234,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2084482285542887425,\"userId\":2084482285106655234,\"orderNo\":\"ORD2026080411311933652340006\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:31:19\",\"updatedAt\":\"2026-08-04 12:01:19\"},\"items\":[{\"id\":2084482285559664642,\"orderId\":2084482285542887425,\"userId\":2084482285106655234,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:31:19\"}],\"timestamp\":\"2026-08-04T12:01:19.459834728\"}','2026-08-04 12:01:19'),(2084490425902616577,2084482875643711489,2084482875220062210,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2084482875643711489,\"userId\":2084482875220062210,\"orderNo\":\"ORD2026080411334002722100012\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:40\",\"updatedAt\":\"2026-08-04 12:03:40\"},\"items\":[{\"id\":2084482875656294402,\"orderId\":2084482875643711489,\"userId\":2084482875220062210,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:33:40\"}],\"timestamp\":\"2026-08-04T12:03:40.151559174\"}','2026-08-04 12:03:40'),(2084490425927782402,2084482875756957697,2084482875220062210,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2084482875756957697,\"userId\":2084482875220062210,\"orderNo\":\"ORD2026080411334005422100013\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:40\",\"updatedAt\":\"2026-08-04 12:03:40\"},\"items\":[{\"id\":2084482875765346305,\"orderId\":2084482875756957697,\"userId\":2084482875220062210,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:33:40\"}],\"timestamp\":\"2026-08-04T12:03:40.157717844\"}','2026-08-04 12:03:40'),(2084491472779923457,2084483922516824065,2084483922097369090,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2084483922516824065,\"userId\":2084483922097369090,\"orderNo\":\"ORD2026080411374962290900020\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:37:49\",\"updatedAt\":\"2026-08-04 12:07:49\"},\"items\":[{\"id\":2084483922529406977,\"orderId\":2084483922516824065,\"userId\":2084483922097369090,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:37:49\"}],\"timestamp\":\"2026-08-04T12:07:49.746102900\"}','2026-08-04 12:07:49'),(2086000935106097154,2086000934497923073,2085982901507301378,'CREATED','{\"order\":{\"id\":2086000934497923073,\"userId\":2085982901507301378,\"orderNo\":\"ORD2026080816055339313780001\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":\"链5重测\",\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-08 16:05:53\",\"updatedAt\":\"2026-08-08 16:05:53\"},\"timestamp\":\"2026-08-08T16:05:53.603399217\",\"items\":[{\"id\":2086000934867021825,\"orderId\":2086000934497923073,\"userId\":2085982901507301378,\"skuId\":2085989641275572226,\"spuId\":2085989545951625217,\"skuName\":\"链2SKU-红色L\",\"skuImage\":null,\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-08 16:05:53\"}]}','2026-08-08 16:05:53'),(2086001096926539778,2086000934497923073,2085982901507301378,'PAID','{\"order\":{\"id\":2086000934497923073,\"userId\":2085982901507301378,\"orderNo\":\"ORD2026080816055339313780001\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":\"链5重测\",\"paidAt\":\"2026-08-08 16:06:32\",\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-08 16:05:53\",\"updatedAt\":\"2026-08-08 16:06:32\"},\"timestamp\":\"2026-08-08T16:06:32.191043678\",\"items\":[{\"id\":2086000934867021825,\"orderId\":2086000934497923073,\"userId\":2085982901507301378,\"skuId\":2085989641275572226,\"spuId\":2085989545951625217,\"skuName\":\"链2SKU-红色L\",\"skuImage\":null,\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-08 16:05:53\"}]}','2026-08-08 16:06:32'),(2086001184990146561,2086000934497923073,2085982901507301378,'DELIVERED','{\"order\":{\"id\":2086000934497923073,\"userId\":2085982901507301378,\"orderNo\":\"ORD2026080816055339313780001\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":\"链5重测\",\"paidAt\":\"2026-08-08 16:06:32\",\"deliveredAt\":\"2026-08-08 16:06:53\",\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-08 16:05:53\",\"updatedAt\":\"2026-08-08 16:06:53\"},\"timestamp\":\"2026-08-08T16:06:53.187339570\",\"items\":[{\"id\":2086000934867021825,\"orderId\":2086000934497923073,\"userId\":2085982901507301378,\"skuId\":2085989641275572226,\"spuId\":2085989545951625217,\"skuName\":\"链2SKU-红色L\",\"skuImage\":null,\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-08 16:05:53\"}]}','2026-08-08 16:06:53'),(2086001185166307330,2086000934497923073,2085982901507301378,'COMPLETED','{\"order\":{\"id\":2086000934497923073,\"userId\":2085982901507301378,\"orderNo\":\"ORD2026080816055339313780001\",\"totalAmount\":198.00,\"payAmount\":198.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":\"链5重测\",\"paidAt\":\"2026-08-08 16:06:32\",\"deliveredAt\":\"2026-08-08 16:06:53\",\"completedAt\":\"2026-08-08 16:06:53\",\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-08 16:05:53\",\"updatedAt\":\"2026-08-08 16:06:53\"},\"timestamp\":\"2026-08-08T16:06:53.228992461\",\"items\":[{\"id\":2086000934867021825,\"orderId\":2086000934497923073,\"userId\":2085982901507301378,\"skuId\":2085989641275572226,\"spuId\":2085989545951625217,\"skuName\":\"链2SKU-红色L\",\"skuImage\":null,\"price\":99.00,\"quantity\":2,\"totalAmount\":198.00,\"createdAt\":\"2026-08-08 16:05:53\"}]}','2026-08-08 16:06:53');
/*!40000 ALTER TABLE `t_order_snapshot_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_1`
--

DROP TABLE IF EXISTS `t_order_snapshot_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_1` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_1`
--

LOCK TABLES `t_order_snapshot_1` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_1` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_1` VALUES (2082354825665744897,2082354825581858818,94006,'CREATED','{\"timestamp\":\"2026-07-29T14:37:33.378368756\",\"order\":{\"id\":2082354825581858818,\"userId\":94006,\"orderNo\":\"ORD2026072914373335540060041\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354825607024641,\"orderId\":2082354825581858818,\"userId\":94006,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33'),(2082354825854488577,2082354825581858818,94006,'PAID','{\"timestamp\":\"2026-07-29T14:37:33.423524814\",\"order\":{\"id\":2082354825581858818,\"userId\":94006,\"orderNo\":\"ORD2026072914373335540060041\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354825607024641,\"orderId\":2082354825581858818,\"userId\":94006,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_snapshot_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_2`
--

DROP TABLE IF EXISTS `t_order_snapshot_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_2` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_2`
--

LOCK TABLES `t_order_snapshot_2` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_2` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_2` VALUES (2082354229969793026,2082354229911072770,91002,'CREATED','{\"timestamp\":\"2026-07-29T14:35:11.352460758\",\"order\":{\"id\":2082354229911072770,\"userId\":91002,\"orderNo\":\"ORD2026072914351133610020022\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354229923655681,\"orderId\":2082354229911072770,\"userId\":91002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2082354230137565185,2082354229911072770,91002,'PAID','{\"timestamp\":\"2026-07-29T14:35:11.392966764\",\"order\":{\"id\":2082354229911072770,\"userId\":91002,\"orderNo\":\"ORD2026072914351133610020022\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354229923655681,\"orderId\":2082354229911072770,\"userId\":91002,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2082354233107132417,2082354233048412161,910010,'CREATED','{\"timestamp\":\"2026-07-29T14:35:12.100756052\",\"order\":{\"id\":2082354233048412161,\"userId\":910010,\"orderNo\":\"ORD2026072914351208400100030\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:12\",\"updatedAt\":\"2026-07-29 14:35:12\"},\"items\":[{\"id\":2082354233056800770,\"orderId\":2082354233048412161,\"userId\":910010,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:12\"}]}','2026-07-29 14:35:12'),(2082354233287487489,2082354233048412161,910010,'PAID','{\"timestamp\":\"2026-07-29T14:35:12.143533866\",\"order\":{\"id\":2082354233048412161,\"userId\":910010,\"orderNo\":\"ORD2026072914351208400100030\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:12\",\"updatedAt\":\"2026-07-29 14:35:12\"},\"items\":[{\"id\":2082354233056800770,\"orderId\":2082354233048412161,\"userId\":910010,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:12\"}]}','2026-07-29 14:35:12');
/*!40000 ALTER TABLE `t_order_snapshot_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_3`
--

DROP TABLE IF EXISTS `t_order_snapshot_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_3` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_3`
--

LOCK TABLES `t_order_snapshot_3` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_3` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_3` VALUES (2082354231613960194,2082354231538462721,91006,'CREATED','{\"timestamp\":\"2026-07-29T14:35:11.745164200\",\"order\":{\"id\":2082354231538462721,\"userId\":91006,\"orderNo\":\"ORD2026072914351172410060026\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354231555239937,\"orderId\":2082354231538462721,\"userId\":91006,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2082354231794315265,2082354231538462721,91006,'PAID','{\"timestamp\":\"2026-07-29T14:35:11.787968974\",\"order\":{\"id\":2082354231538462721,\"userId\":91006,\"orderNo\":\"ORD2026072914351172410060026\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354231555239937,\"orderId\":2082354231538462721,\"userId\":91006,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_snapshot_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'my_xhs_order_2'
--

--
-- Dumping routines for database 'my_xhs_order_2'
--

--
-- Current Database: `my_xhs_order_3`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `my_xhs_order_3` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `my_xhs_order_3`;

--
-- Table structure for table `t_local_message_0`
--

DROP TABLE IF EXISTS `t_local_message_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_0` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_0`
--

LOCK TABLES `t_local_message_0` WRITE;
/*!40000 ALTER TABLE `t_local_message_0` DISABLE KEYS */;
INSERT INTO `t_local_message_0` VALUES (2082328529069985793,20003,'ORD2026072912530375500030004','order','ORDER_CREATED','{\"timestamp\":1785300783755,\"couponId\":0,\"orderNo\":\"ORD2026072912530375500030004\",\"userId\":20003,\"skuItems\":[{\"skuId\":999,\"quantity\":1}]}',0,0,'2026-07-29 12:53:03','2026-07-29 12:53:03','2026-07-29 12:53:03'),(2082354037480599554,90003,'ORD2026072914342545100030018','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914342545100030018\",\"couponId\":0,\"timestamp\":1785306865452,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":90003}',0,0,'2026-07-29 14:34:25','2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354556315947009,92003,'ORD2026072914362915020030033','order','ORDER_CREATED','{\"couponId\":0,\"timestamp\":1785306989150,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":92003,\"orderNo\":\"ORD2026072914362915020030033\"}',0,0,'2026-07-29 14:36:29','2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354824134823938,94003,'ORD2026072914373300140030038','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914373300140030038\",\"couponId\":0,\"timestamp\":1785307053002,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":94003}',0,0,'2026-07-29 14:37:33','2026-07-29 14:37:33','2026-07-29 14:37:33'),(2082355537841786881,10003,'ORD2026072914402316600030046','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914402316600030046\",\"couponId\":0,\"timestamp\":1785307223167,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":10003}',0,0,'2026-07-29 14:40:23','2026-07-29 14:40:23','2026-07-29 14:40:23'),(2084463160561029121,55555,'ORD2026080410151950355550001','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2,\"quantity\":1}],\"userId\":55555,\"orderNo\":\"ORD2026080410151950355550001\",\"couponId\":0,\"timestamp\":1785809719507}',0,0,'2026-08-04 10:15:19','2026-08-04 10:15:19','2026-08-04 10:15:19');
/*!40000 ALTER TABLE `t_local_message_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_1`
--

DROP TABLE IF EXISTS `t_local_message_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_1` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_1`
--

LOCK TABLES `t_local_message_1` WRITE;
/*!40000 ALTER TABLE `t_local_message_1` DISABLE KEYS */;
INSERT INTO `t_local_message_1` VALUES (2082354826047426562,94007,'ORD2026072914373345940070042','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914373345940070042\",\"couponId\":0,\"timestamp\":1785307053459,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":94007}',0,0,'2026-07-29 14:37:33','2026-07-29 14:37:33','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_local_message_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_2`
--

DROP TABLE IF EXISTS `t_local_message_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_2` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_2`
--

LOCK TABLES `t_local_message_2` WRITE;
/*!40000 ALTER TABLE `t_local_message_2` DISABLE KEYS */;
INSERT INTO `t_local_message_2` VALUES (2082354230309531650,91003,'ORD2026072914351142610030023','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351142610030023\",\"couponId\":0,\"timestamp\":1785306911426,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":91003}',0,0,'2026-07-29 14:35:11','2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_local_message_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_local_message_3`
--

DROP TABLE IF EXISTS `t_local_message_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_local_message_3` (
  `id` bigint NOT NULL COMMENT 'æ¶ˆæ¯ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹åŠ¡ID',
  `service_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æœåŠ¡å',
  `operation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ“ä½œå‚æ•°JSON',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…å¤„ç† 1-æˆåŠŸ 2-å¤±è´¥ 3-æ­»ä¿¡',
  `retry_count` int NOT NULL DEFAULT '0' COMMENT 'é‡è¯•æ¬¡æ•°',
  `next_retry_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'ä¸‹æ¬¡é‡è¯•æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æœ¬åœ°æ¶ˆæ¯è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_local_message_3`
--

LOCK TABLES `t_local_message_3` WRITE;
/*!40000 ALTER TABLE `t_local_message_3` DISABLE KEYS */;
INSERT INTO `t_local_message_3` VALUES (2082354231949504513,91007,'ORD2026072914351181810070027','order','ORDER_CREATED','{\"orderNo\":\"ORD2026072914351181810070027\",\"couponId\":0,\"timestamp\":1785306911818,\"skuItems\":[{\"skuId\":999,\"quantity\":1}],\"userId\":91007}',0,0,'2026-07-29 14:35:11','2026-07-29 14:35:11','2026-07-29 14:35:11'),(2084482723394670593,99999,'ORD2026080411330372499990011','order','ORDER_CREATED','{\"skuItems\":[{\"skuId\":2,\"quantity\":1}],\"userId\":99999,\"orderNo\":\"ORD2026080411330372499990011\",\"couponId\":0,\"timestamp\":1785814383724}',0,0,'2026-08-04 11:33:03','2026-08-04 11:33:03','2026-08-04 11:33:03');
/*!40000 ALTER TABLE `t_local_message_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_0`
--

DROP TABLE IF EXISTS `t_order_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_0` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_0`
--

LOCK TABLES `t_order_0` WRITE;
/*!40000 ALTER TABLE `t_order_0` DISABLE KEYS */;
INSERT INTO `t_order_0` VALUES (2082328528973516802,20003,'ORD2026072912530375500030004',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 12:53:03','2026-07-29 13:23:03'),(2082354037455433729,90003,'ORD2026072914342545100030018',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354556286586881,92003,'ORD2026072914362915020030033',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:36:29','2026-07-29 15:06:29'),(2082354824101269505,94003,'ORD2026072914373300140030038',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:37:33','2026-07-29 14:37:33'),(2082355537820815361,10003,'ORD2026072914402316600030046',99.00,99.00,0.00,NULL,3,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:40:23','2026-07-29 14:40:23'),(2084463160384868354,55555,'ORD2026080410151950355550001',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 10:15:19','2026-08-04 10:45:19');
/*!40000 ALTER TABLE `t_order_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_1`
--

DROP TABLE IF EXISTS `t_order_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_1` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_1`
--

LOCK TABLES `t_order_1` WRITE;
/*!40000 ALTER TABLE `t_order_1` DISABLE KEYS */;
INSERT INTO `t_order_1` VALUES (2082354826018066433,94007,'ORD2026072914373345940070042',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:37:33','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_2`
--

DROP TABLE IF EXISTS `t_order_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_2` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_2`
--

LOCK TABLES `t_order_2` WRITE;
/*!40000 ALTER TABLE `t_order_2` DISABLE KEYS */;
INSERT INTO `t_order_2` VALUES (2082354230284365825,91003,'ORD2026072914351142610030023',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:11','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_3`
--

DROP TABLE IF EXISTS `t_order_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_3` (
  `id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `order_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å·',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'è®¢å•æ€»é‡‘é¢',
  `pay_amount` decimal(10,2) NOT NULL COMMENT 'å®žä»˜é‡‘é¢',
  `discount_amount` decimal(10,2) DEFAULT '0.00' COMMENT 'ä¼˜æƒ é‡‘é¢',
  `coupon_id` bigint DEFAULT NULL COMMENT 'ä½¿ç”¨çš„ä¼˜æƒ åˆ¸ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `address_snapshot` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'æ”¶è´§åœ°å€å¿«ç…§(JSON)',
  `remark` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'è®¢å•å¤‡æ³¨',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æ—¶é—´',
  `delivered_at` datetime DEFAULT NULL COMMENT 'å‘è´§æ—¶é—´',
  `completed_at` datetime DEFAULT NULL COMMENT 'å®Œæˆæ—¶é—´',
  `cancelled_at` datetime DEFAULT NULL COMMENT 'å–æ¶ˆæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status_created` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_3`
--

LOCK TABLES `t_order_3` WRITE;
/*!40000 ALTER TABLE `t_order_3` DISABLE KEYS */;
INSERT INTO `t_order_3` VALUES (2082354231928532994,91007,'ORD2026072914351181810070027',99.00,99.00,0.00,NULL,1,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2084482723373699074,99999,'ORD2026080411330372499990011',99.00,99.00,0.00,NULL,4,'{\"name\":\"测试用户\",\"phone\":\"13800138000\",\"address\":\"北京市朝阳区xxx路xxx号\"}',NULL,NULL,NULL,NULL,NULL,0,'2026-08-04 11:33:03','2026-08-04 12:03:03');
/*!40000 ALTER TABLE `t_order_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_0`
--

DROP TABLE IF EXISTS `t_order_event_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_0` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1291350367327305729 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_0`
--

LOCK TABLES `t_order_event_0` WRITE;
/*!40000 ALTER TABLE `t_order_event_0` DISABLE KEYS */;
INSERT INTO `t_order_event_0` VALUES (1289215735693656064,2082328528973516802,20003,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelTime\":\"2026-07-29T13:23:03.844494893\",\"cancelReason\":\"超时未支付\"}',1,'2026-07-29 13:23:03.859','2026-07-29 13:23:03'),(1289233694235377664,2082354037455433729,90003,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:34:25.502676900\"}',1,'2026-07-29 14:34:25.509','2026-07-29 14:34:25'),(1289234480927424512,2082354824101269505,94003,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:37:33.058382524\"}',1,'2026-07-29 14:37:33.071','2026-07-29 14:37:33'),(1289235194584055809,2082355537820815361,10003,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:40:23.212010546\"}',1,'2026-07-29 14:40:23.220','2026-07-29 14:40:23'),(1289235194764410880,2082355537820815361,10003,'ORDER_DELIVERED',1,2,'{\"deliveredTime\":\"2026-07-29T14:40:23.253473315\",\"trackingNo\":\"TRACK001\",\"logisticsCompany\":\"SF\"}',2,'2026-07-29 14:40:23.263','2026-07-29 14:40:23'),(1289235194915405825,2082355537820815361,10003,'ORDER_COMPLETED',2,3,'{\"completeTime\":\"2026-07-29T14:40:23.293830055\"}',3,'2026-07-29 14:40:23.300','2026-07-29 14:40:23'),(1289241762834759681,2082354556286586881,92003,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-07-29T15:06:29.205709399\"}',1,'2026-07-29 15:06:29.213','2026-07-29 15:06:29'),(1291350367327305728,2084463160384868354,55555,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-04T10:45:19.617045039\"}',1,'2026-08-04 10:45:19.697','2026-08-04 10:45:19');
/*!40000 ALTER TABLE `t_order_event_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_1`
--

DROP TABLE IF EXISTS `t_order_event_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_1` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289234482827444225 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_1`
--

LOCK TABLES `t_order_event_1` WRITE;
/*!40000 ALTER TABLE `t_order_event_1` DISABLE KEYS */;
INSERT INTO `t_order_event_1` VALUES (1289234482827444224,2082354826018066433,94007,'ORDER_CANCELLED',0,4,'{\"cancelReason\":\"支付失败\",\"cancelTime\":\"2026-07-29T14:37:33.515595966\"}',1,'2026-07-29 14:37:33.523','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_event_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_2`
--

DROP TABLE IF EXISTS `t_order_event_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_2` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1289233887060115458 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_2`
--

LOCK TABLES `t_order_event_2` WRITE;
/*!40000 ALTER TABLE `t_order_event_2` DISABLE KEYS */;
INSERT INTO `t_order_event_2` VALUES (1289233887060115457,2082354230284365825,91003,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:11.477118097\"}',1,'2026-07-29 14:35:11.482','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_event_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_event_3`
--

DROP TABLE IF EXISTS `t_order_event_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_event_3` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'äº‹ä»¶ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'äº‹ä»¶ç±»åž‹',
  `from_status` tinyint DEFAULT NULL COMMENT 'å˜æ›´å‰çŠ¶æ€',
  `to_status` tinyint NOT NULL COMMENT 'å˜æ›´åŽçŠ¶æ€',
  `payload` text COLLATE utf8mb4_unicode_ci COMMENT 'äº‹ä»¶è½½è·ï¼ˆJSONï¼‰',
  `event_seq` int NOT NULL COMMENT 'äº‹ä»¶åºå·',
  `event_time` datetime(3) NOT NULL COMMENT 'äº‹ä»¶å‘ç”Ÿæ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_event_seq` (`order_id`,`event_seq`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1291369930014146561 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•äº‹ä»¶æµ(Event Sourcing)_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_event_3`
--

LOCK TABLES `t_order_event_3` WRITE;
/*!40000 ALTER TABLE `t_order_event_3` DISABLE KEYS */;
INSERT INTO `t_order_event_3` VALUES (1289233888658145281,2082354231928532994,91007,'ORDER_PAID',0,1,'{\"paidTime\":\"2026-07-29T14:35:11.858030546\"}',1,'2026-07-29 14:35:11.863','2026-07-29 14:35:11'),(1291369930014146560,2084482723373699074,99999,'ORDER_TIMEOUT_CANCELLED',0,4,'{\"cancelReason\":\"超时未支付\",\"cancelTime\":\"2026-08-04T12:03:03.801169804\"}',1,'2026-08-04 12:03:03.808','2026-08-04 12:03:03');
/*!40000 ALTER TABLE `t_order_event_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_0`
--

DROP TABLE IF EXISTS `t_order_item_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_0` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_0`
--

LOCK TABLES `t_order_item_0` WRITE;
/*!40000 ALTER TABLE `t_order_item_0` DISABLE KEYS */;
INSERT INTO `t_order_item_0` VALUES (2082328529049014273,2082328528973516802,20003,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 12:53:03'),(2082354037468016641,2082354037455433729,90003,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:34:25'),(2082354556307558402,2082354556286586881,92003,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:36:29'),(2082354824122241025,2082354824101269505,94003,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:37:33'),(2082355537833398273,2082355537820815361,10003,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:40:23'),(2084463160540057601,2084463160384868354,55555,2,2,'Mock商品-2','https://img.mock.com/sku/2.jpg',99.00,1,99.00,'2026-08-04 10:15:19');
/*!40000 ALTER TABLE `t_order_item_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_1`
--

DROP TABLE IF EXISTS `t_order_item_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_1` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_1`
--

LOCK TABLES `t_order_item_1` WRITE;
/*!40000 ALTER TABLE `t_order_item_1` DISABLE KEYS */;
INSERT INTO `t_order_item_1` VALUES (2082354826034843649,2082354826018066433,94007,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_item_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_2`
--

DROP TABLE IF EXISTS `t_order_item_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_2` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_2`
--

LOCK TABLES `t_order_item_2` WRITE;
/*!40000 ALTER TABLE `t_order_item_2` DISABLE KEYS */;
INSERT INTO `t_order_item_2` VALUES (2082354230301143042,2082354230284365825,91003,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_item_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_item_3`
--

DROP TABLE IF EXISTS `t_order_item_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_item_3` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `sku_id` bigint NOT NULL COMMENT 'SKU ID',
  `spu_id` bigint NOT NULL COMMENT 'SPU ID',
  `sku_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SKUåç§°å¿«ç…§',
  `sku_image` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SKUå›¾ç‰‡å¿«ç…§',
  `price` decimal(10,2) NOT NULL COMMENT 'å•ä»·å¿«ç…§',
  `quantity` int NOT NULL COMMENT 'æ•°é‡',
  `total_amount` decimal(10,2) NOT NULL COMMENT 'å°è®¡é‡‘é¢',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•æ˜Žç»†è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_item_3`
--

LOCK TABLES `t_order_item_3` WRITE;
/*!40000 ALTER TABLE `t_order_item_3` DISABLE KEYS */;
INSERT INTO `t_order_item_3` VALUES (2082354231941115905,2082354231928532994,91007,999,999,'Mock商品-999','https://img.mock.com/sku/999.jpg',99.00,1,99.00,'2026-07-29 14:35:11'),(2084482723386281985,2084482723373699074,99999,2,2,'Mock商品-2','https://img.mock.com/sku/2.jpg',99.00,1,99.00,'2026-08-04 11:33:03');
/*!40000 ALTER TABLE `t_order_item_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_0`
--

DROP TABLE IF EXISTS `t_order_snapshot_0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_0` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_0`
--

LOCK TABLES `t_order_snapshot_0` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_0` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_0` VALUES (2082328529149677569,2082328528973516802,20003,'CREATED','{\"items\":[{\"id\":2082328529049014273,\"orderId\":2082328528973516802,\"userId\":20003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:53:03\"}],\"order\":{\"id\":2082328528973516802,\"userId\":20003,\"orderNo\":\"ORD2026072912530375500030004\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:53:03\",\"updatedAt\":\"2026-07-29 12:53:03\"},\"timestamp\":\"2026-07-29T12:53:03.799730896\"}','2026-07-29 12:53:03'),(2082336079219851265,2082328528973516802,20003,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2082328528973516802,\"userId\":20003,\"orderNo\":\"ORD2026072912530375500030004\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 12:53:03\",\"updatedAt\":\"2026-07-29 13:23:03\"},\"timestamp\":\"2026-07-29T13:23:03.877370666\",\"items\":[{\"id\":2082328529049014273,\"orderId\":2082328528973516802,\"userId\":20003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 12:53:03\"}]}','2026-07-29 13:23:03'),(2082354037543514114,2082354037455433729,90003,'CREATED','{\"timestamp\":\"2026-07-29T14:34:25.474151124\",\"order\":{\"id\":2082354037455433729,\"userId\":90003,\"orderNo\":\"ORD2026072914342545100030018\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354037468016641,\"orderId\":2082354037455433729,\"userId\":90003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354037736452097,2082354037455433729,90003,'PAID','{\"timestamp\":\"2026-07-29T14:34:25.520989620\",\"order\":{\"id\":2082354037455433729,\"userId\":90003,\"orderNo\":\"ORD2026072914342545100030018\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:34:25\",\"updatedAt\":\"2026-07-29 14:34:25\"},\"items\":[{\"id\":2082354037468016641,\"orderId\":2082354037455433729,\"userId\":90003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:34:25\"}]}','2026-07-29 14:34:25'),(2082354556395638786,2082354556286586881,92003,'CREATED','{\"timestamp\":\"2026-07-29T14:36:29.177880326\",\"order\":{\"id\":2082354556286586881,\"userId\":92003,\"orderNo\":\"ORD2026072914362915020030033\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:29\",\"updatedAt\":\"2026-07-29 14:36:29\"},\"items\":[{\"id\":2082354556307558402,\"orderId\":2082354556286586881,\"userId\":92003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:29\"}]}','2026-07-29 14:36:29'),(2082354824193544194,2082354824101269505,94003,'CREATED','{\"timestamp\":\"2026-07-29T14:37:33.026773258\",\"order\":{\"id\":2082354824101269505,\"userId\":94003,\"orderNo\":\"ORD2026072914373300140030038\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354824122241025,\"orderId\":2082354824101269505,\"userId\":94003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33'),(2082354824449396738,2082354824101269505,94003,'PAID','{\"timestamp\":\"2026-07-29T14:37:33.086823442\",\"order\":{\"id\":2082354824101269505,\"userId\":94003,\"orderNo\":\"ORD2026072914373300140030038\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354824122241025,\"orderId\":2082354824101269505,\"userId\":94003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33'),(2082355537883729922,2082355537820815361,10003,'CREATED','{\"timestamp\":\"2026-07-29T14:40:23.183626498\",\"order\":{\"id\":2082355537820815361,\"userId\":10003,\"orderNo\":\"ORD2026072914402316600030046\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:23\",\"updatedAt\":\"2026-07-29 14:40:23\"},\"items\":[{\"id\":2082355537833398273,\"orderId\":2082355537820815361,\"userId\":10003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:23\"}]}','2026-07-29 14:40:23'),(2082355538076667905,2082355537820815361,10003,'PAID','{\"timestamp\":\"2026-07-29T14:40:23.230285048\",\"order\":{\"id\":2082355537820815361,\"userId\":10003,\"orderNo\":\"ORD2026072914402316600030046\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:23\",\"updatedAt\":\"2026-07-29 14:40:23\"},\"items\":[{\"id\":2082355537833398273,\"orderId\":2082355537820815361,\"userId\":10003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:23\"}]}','2026-07-29 14:40:23'),(2082355538257022977,2082355537820815361,10003,'DELIVERED','{\"timestamp\":\"2026-07-29T14:40:23.273383975\",\"order\":{\"id\":2082355537820815361,\"userId\":10003,\"orderNo\":\"ORD2026072914402316600030046\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":2,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:23\",\"updatedAt\":\"2026-07-29 14:40:23\"},\"items\":[{\"id\":2082355537833398273,\"orderId\":2082355537820815361,\"userId\":10003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:23\"}]}','2026-07-29 14:40:23'),(2082355538408017921,2082355537820815361,10003,'COMPLETED','{\"timestamp\":\"2026-07-29T14:40:23.308742281\",\"order\":{\"id\":2082355537820815361,\"userId\":10003,\"orderNo\":\"ORD2026072914402316600030046\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":3,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:40:23\",\"updatedAt\":\"2026-07-29 14:40:23\"},\"items\":[{\"id\":2082355537833398273,\"orderId\":2082355537820815361,\"userId\":10003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:40:23\"}]}','2026-07-29 14:40:23'),(2082362106352537602,2082354556286586881,92003,'TIMEOUT_CANCELLED','{\"timestamp\":\"2026-07-29T15:06:29.228909358\",\"order\":{\"id\":2082354556286586881,\"userId\":92003,\"orderNo\":\"ORD2026072914362915020030033\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:36:29\",\"updatedAt\":\"2026-07-29 15:06:29\"},\"items\":[{\"id\":2082354556307558402,\"orderId\":2082354556286586881,\"userId\":92003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:36:29\"}]}','2026-07-29 15:06:29'),(2084463160804298753,2084463160384868354,55555,'CREATED','{\"order\":{\"id\":2084463160384868354,\"userId\":55555,\"orderNo\":\"ORD2026080410151950355550001\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 10:15:19\",\"updatedAt\":\"2026-08-04 10:15:19\"},\"items\":[{\"id\":2084463160540057601,\"orderId\":2084463160384868354,\"userId\":55555,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 10:15:19\"}],\"timestamp\":\"2026-08-04T10:15:19.639327082\"}','2026-08-04 10:15:19'),(2084470712090808321,2084463160384868354,55555,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2084463160384868354,\"userId\":55555,\"orderNo\":\"ORD2026080410151950355550001\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 10:15:19\",\"updatedAt\":\"2026-08-04 10:45:19\"},\"items\":[{\"id\":2084463160540057601,\"orderId\":2084463160384868354,\"userId\":55555,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 10:15:19\"}],\"timestamp\":\"2026-08-04T10:45:20.011445305\"}','2026-08-04 10:45:20');
/*!40000 ALTER TABLE `t_order_snapshot_0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_1`
--

DROP TABLE IF EXISTS `t_order_snapshot_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_1` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_1`
--

LOCK TABLES `t_order_snapshot_1` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_1` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_1` VALUES (2082354826110341121,2082354826018066433,94007,'CREATED','{\"timestamp\":\"2026-07-29T14:37:33.483879142\",\"order\":{\"id\":2082354826018066433,\"userId\":94007,\"orderNo\":\"ORD2026072914373345940070042\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354826034843649,\"orderId\":2082354826018066433,\"userId\":94007,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33'),(2082354826366193665,2082354826018066433,94007,'CANCELLED','{\"timestamp\":\"2026-07-29T14:37:33.544614753\",\"order\":{\"id\":2082354826018066433,\"userId\":94007,\"orderNo\":\"ORD2026072914373345940070042\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:37:33\",\"updatedAt\":\"2026-07-29 14:37:33\"},\"items\":[{\"id\":2082354826034843649,\"orderId\":2082354826018066433,\"userId\":94007,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:37:33\"}]}','2026-07-29 14:37:33');
/*!40000 ALTER TABLE `t_order_snapshot_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_2`
--

DROP TABLE IF EXISTS `t_order_snapshot_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_2` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_2`
--

LOCK TABLES `t_order_snapshot_2` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_2` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_2` VALUES (2082354230372446210,2082354230284365825,91003,'CREATED','{\"timestamp\":\"2026-07-29T14:35:11.448538453\",\"order\":{\"id\":2082354230284365825,\"userId\":91003,\"orderNo\":\"ORD2026072914351142610030023\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354230301143042,\"orderId\":2082354230284365825,\"userId\":91003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2082354230573772802,2082354230284365825,91003,'PAID','{\"timestamp\":\"2026-07-29T14:35:11.496535087\",\"order\":{\"id\":2082354230284365825,\"userId\":91003,\"orderNo\":\"ORD2026072914351142610030023\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354230301143042,\"orderId\":2082354230284365825,\"userId\":91003,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11');
/*!40000 ALTER TABLE `t_order_snapshot_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_order_snapshot_3`
--

DROP TABLE IF EXISTS `t_order_snapshot_3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_order_snapshot_3` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·IDï¼ˆåˆ†ç‰‡é”®ï¼‰',
  `event` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è§¦å‘äº‹ä»¶',
  `snapshot_data` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'è®¢å•å®Œæ•´å¿«ç…§(JSON)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='è®¢å•å¿«ç…§è¡¨_0';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_order_snapshot_3`
--

LOCK TABLES `t_order_snapshot_3` WRITE;
/*!40000 ALTER TABLE `t_order_snapshot_3` DISABLE KEYS */;
INSERT INTO `t_order_snapshot_3` VALUES (2082354231987253249,2082354231928532994,91007,'CREATED','{\"timestamp\":\"2026-07-29T14:35:11.833691110\",\"order\":{\"id\":2082354231928532994,\"userId\":91007,\"orderNo\":\"ORD2026072914351181810070027\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354231941115905,\"orderId\":2082354231928532994,\"userId\":91007,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2082354232155025410,2082354231928532994,91007,'PAID','{\"timestamp\":\"2026-07-29T14:35:11.873544800\",\"order\":{\"id\":2082354231928532994,\"userId\":91007,\"orderNo\":\"ORD2026072914351181810070027\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":1,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-07-29 14:35:11\",\"updatedAt\":\"2026-07-29 14:35:11\"},\"items\":[{\"id\":2082354231941115905,\"orderId\":2082354231928532994,\"userId\":91007,\"skuId\":999,\"spuId\":999,\"skuName\":\"Mock商品-999\",\"skuImage\":\"https://img.mock.com/sku/999.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-07-29 14:35:11\"}]}','2026-07-29 14:35:11'),(2084482723428225026,2084482723373699074,99999,'CREATED','{\"order\":{\"id\":2084482723373699074,\"userId\":99999,\"orderNo\":\"ORD2026080411330372499990011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":0,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:03\",\"updatedAt\":\"2026-08-04 11:33:03\"},\"items\":[{\"id\":2084482723386281985,\"orderId\":2084482723373699074,\"userId\":99999,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:33:03\"}],\"timestamp\":\"2026-08-04T11:33:03.737697864\"}','2026-08-04 11:33:03'),(2084490273531940866,2084482723373699074,99999,'TIMEOUT_CANCELLED','{\"order\":{\"id\":2084482723373699074,\"userId\":99999,\"orderNo\":\"ORD2026080411330372499990011\",\"totalAmount\":99.00,\"payAmount\":99.00,\"discountAmount\":0.00,\"couponId\":null,\"status\":4,\"addressSnapshot\":\"{\\\"name\\\":\\\"测试用户\\\",\\\"phone\\\":\\\"13800138000\\\",\\\"address\\\":\\\"北京市朝阳区xxx路xxx号\\\"}\",\"remark\":null,\"paidAt\":null,\"deliveredAt\":null,\"completedAt\":null,\"cancelledAt\":null,\"deleted\":0,\"createdAt\":\"2026-08-04 11:33:03\",\"updatedAt\":\"2026-08-04 12:03:03\"},\"items\":[{\"id\":2084482723386281985,\"orderId\":2084482723373699074,\"userId\":99999,\"skuId\":2,\"spuId\":2,\"skuName\":\"Mock商品-2\",\"skuImage\":\"https://img.mock.com/sku/2.jpg\",\"price\":99.00,\"quantity\":1,\"totalAmount\":99.00,\"createdAt\":\"2026-08-04 11:33:03\"}],\"timestamp\":\"2026-08-04T12:03:03.822853170\"}','2026-08-04 12:03:03');
/*!40000 ALTER TABLE `t_order_snapshot_3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'my_xhs_order_3'
--

--
-- Dumping routines for database 'my_xhs_order_3'
--

--
-- Current Database: `my_xhs_payment`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `my_xhs_payment` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `my_xhs_payment`;

--
-- Table structure for table `t_payment`
--

DROP TABLE IF EXISTS `t_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_payment` (
  `id` bigint NOT NULL COMMENT 'ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `payment_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'æ”¯ä»˜æµæ°´å·',
  `amount` decimal(10,2) NOT NULL COMMENT 'æ”¯ä»˜é‡‘é¢',
  `pay_type` tinyint NOT NULL COMMENT 'æ”¯ä»˜æ–¹å¼ï¼š1-æ”¯ä»˜å®(Mock) 2-å¾®ä¿¡(Mock)',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-å¾…æ”¯ä»˜ 1-æ”¯ä»˜æˆåŠŸ 2-æ”¯ä»˜å¤±è´¥ 3-å·²é€€æ¬¾',
  `paid_at` datetime DEFAULT NULL COMMENT 'æ”¯ä»˜æˆåŠŸæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_payment_no` (`payment_no`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='æ”¯ä»˜è®°å½•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_payment`
--

LOCK TABLES `t_payment` WRITE;
/*!40000 ALTER TABLE `t_payment` DISABLE KEYS */;
INSERT INTO `t_payment` VALUES (2076173965342023681,2076173837361258497,10001,'PAY20260712000001',99.00,1,0,NULL,0,'2026-07-12 13:17:01','2026-07-12 13:17:01'),(2076175113264373761,2076175112224153601,10001,'PAY20260712000002',99.00,99,1,'2026-07-12 13:21:35',0,'2026-07-12 13:21:35','2026-07-12 13:21:35'),(2076175588143427586,2076175587065503746,10001,'PAY20260712000003',99.00,99,3,'2026-07-12 13:23:28',0,'2026-07-12 13:23:28','2026-07-12 13:49:00'),(2082329776053354497,2082329775684255745,40001,'MOCK_PAY_1785301081085',99.00,1,1,'2026-07-29 12:58:01',0,'2026-07-29 12:58:01','2026-07-29 12:58:01'),(2082350633043689474,2082350632766865409,60001,'MOCK_PAY_1785306053779',198.00,1,1,'2026-07-29 14:20:54',0,'2026-07-29 14:20:53','2026-07-29 14:20:53'),(2082351000729006082,2082350994844397570,70001,'MOCK_PAY_1785306141441',99.00,1,1,'2026-07-29 14:22:21',0,'2026-07-29 14:22:21','2026-07-29 14:22:21'),(2082351796526886914,2082351748510494721,80001,'MOCK_PAY_1785306331175',89.00,1,1,'2026-07-29 14:25:31',0,'2026-07-29 14:25:31','2026-07-29 14:25:31'),(2082353976482836481,2082353976164069378,90001,'MOCK_PAY_1785306850917',99.00,2,1,'2026-07-29 14:34:11',0,'2026-07-29 14:34:10','2026-07-29 14:34:10'),(2082354036826288130,2082354036532686850,90001,'MOCK_PAY_1785306865303',99.00,2,1,'2026-07-29 14:34:25',0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354037321216001,2082354037010837506,90002,'MOCK_PAY_1785306865421',99.00,2,1,'2026-07-29 14:34:25',0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354037753229314,2082354037455433729,90003,'MOCK_PAY_1785306865524',99.00,2,1,'2026-07-29 14:34:26',0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354038118133762,2082354037879058433,90004,'MOCK_PAY_1785306865612',99.00,2,1,'2026-07-29 14:34:26',0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354038516592641,2082354038248157185,90005,'MOCK_PAY_1785306865706',99.00,2,1,'2026-07-29 14:34:26',0,'2026-07-29 14:34:25','2026-07-29 14:34:25'),(2082354229772660737,2082354229479059458,91001,'MOCK_PAY_1785306911305',99.00,2,1,'2026-07-29 14:35:11',0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354230150148098,2082354229911072770,91002,'MOCK_PAY_1785306911395',99.00,2,1,'2026-07-29 14:35:11',0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354230582161410,2082354230284365825,91003,'MOCK_PAY_1785306911499',99.00,2,1,'2026-07-29 14:35:11',0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354230976425986,2082354230712184833,91004,'MOCK_PAY_1785306911592',99.00,2,1,'2026-07-29 14:35:12',0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354231395856385,2082354231110643714,91005,'MOCK_PAY_1785306911692',99.00,2,1,'2026-07-29 14:35:12',0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354231802703874,2082354231538462721,91006,'MOCK_PAY_1785306911790',99.00,2,1,'2026-07-29 14:35:12',0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354232163414017,2082354231928532994,91007,'MOCK_PAY_1785306911876',99.00,2,1,'2026-07-29 14:35:12',0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354232536707073,2082354232293437442,91008,'MOCK_PAY_1785306911964',99.00,2,1,'2026-07-29 14:35:12',0,'2026-07-29 14:35:11','2026-07-29 14:35:11'),(2082354232918388737,2082354232675119105,91009,'MOCK_PAY_1785306912056',99.00,2,1,'2026-07-29 14:35:12',0,'2026-07-29 14:35:12','2026-07-29 14:35:12'),(2082354233295876098,2082354233048412161,910010,'MOCK_PAY_1785306912146',99.00,2,1,'2026-07-29 14:35:12',0,'2026-07-29 14:35:12','2026-07-29 14:35:12'),(2082354555527417857,2082354549059801089,92001,'MOCK_PAY_1785306988971',99.00,2,1,'2026-07-29 14:36:29',0,'2026-07-29 14:36:28','2026-07-29 14:36:28'),(2082354556143980546,2082354555686801409,92002,'MOCK_PAY_1785306989118',99.00,2,1,'2026-07-29 14:36:29',0,'2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354556521467906,2082354556286586881,92003,'MOCK_FAIL_1785306989208',99.00,2,2,NULL,0,'2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354557200945153,2082354556827652097,92004,'MOCK_PAY_1785306989370',99.00,2,1,'2026-07-29 14:36:29',0,'2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354557578432513,2082354557347745793,92005,'MOCK_FAIL_1785306989460',99.00,2,2,NULL,0,'2026-07-29 14:36:29','2026-07-29 14:36:29'),(2082354805549862913,2082354799459733506,94001,'MOCK_FAIL_1785307048582',99.00,2,2,NULL,0,'2026-07-29 14:37:28','2026-07-29 14:37:28'),(2082354815259676674,2082354815049961473,94002,'MOCK_FAIL_1785307050897',99.00,2,2,NULL,0,'2026-07-29 14:37:30','2026-07-29 14:37:30'),(2082354824466173953,2082354824101269505,94003,'MOCK_PAY_1785307053091',99.00,2,1,'2026-07-29 14:37:33',0,'2026-07-29 14:37:33','2026-07-29 14:37:33'),(2082354824977879041,2082354824617168897,94004,'MOCK_PAY_1785307053214',99.00,2,1,'2026-07-29 14:37:33',0,'2026-07-29 14:37:33','2026-07-29 14:37:33'),(2082354825447641090,2082354825120485377,94005,'MOCK_PAY_1785307053326',99.00,2,1,'2026-07-29 14:37:33',0,'2026-07-29 14:37:33','2026-07-29 14:37:33'),(2082354825867071489,2082354825581858818,94006,'MOCK_PAY_1785307053426',99.00,2,1,'2026-07-29 14:37:33',0,'2026-07-29 14:37:33','2026-07-29 14:37:33'),(2082354826219393025,2082354826018066433,94007,'MOCK_FAIL_1785307053510',99.00,2,2,NULL,0,'2026-07-29 14:37:33','2026-07-29 14:37:33'),(2082354835199397889,2082354835010654210,94008,'MOCK_FAIL_1785307055651',99.00,2,2,NULL,0,'2026-07-29 14:37:35','2026-07-29 14:37:35'),(2082355538085056514,2082355537820815361,10003,'MOCK_PAY_1785307223232',99.00,1,1,'2026-07-29 14:40:23',0,'2026-07-29 14:40:23','2026-07-29 14:40:23'),(2082355590530633730,2082355590371250177,20001,'MOCK_FAIL_1785307235736',99.00,2,2,NULL,0,'2026-07-29 14:40:35','2026-07-29 14:40:35'),(2082355657077460994,2082355656792248321,30001,'MOCK_PAY_1785307251602',99.00,1,1,'2026-07-29 14:40:52',0,'2026-07-29 14:40:51','2026-07-29 14:40:51'),(2082367778142085121,2082367690804072449,10001,'PAY20260729000001',99.00,1,3,'2026-07-29 15:44:48',0,'2026-07-29 15:29:01','2026-07-29 15:46:14'),(2084171332376895490,2084171330690785282,2084171328232906753,'MOCK_PAY_1785740142326',198.00,1,1,'2026-08-03 14:55:42',0,'2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171334432104450,2084171334209806338,2084171328232906753,'MOCK_PAY_1785740142816',99.00,1,1,'2026-08-03 14:55:43',0,'2026-08-03 14:55:42','2026-08-03 14:55:42'),(2084171442880028673,2084171442498347010,2084171442041151489,'MOCK_PAY_1785740168672',198.00,1,1,'2026-08-03 14:56:09',0,'2026-08-03 14:56:08','2026-08-03 14:56:08'),(2084171444251566082,2084171444050239489,2084171442041151489,'MOCK_PAY_1785740168999',99.00,1,1,'2026-08-03 14:56:09',0,'2026-08-03 14:56:09','2026-08-03 14:56:09'),(2084174561642844161,2084174560141287426,2084174559629565954,'PAY20260803000001',99.00,99,3,'2026-08-03 15:08:32',0,'2026-08-03 15:08:32','2026-08-03 15:08:32'),(2084174562724974593,999999999999,2084174559629565954,'PAY20260803000002',99.00,99,1,'2026-08-03 15:08:33',0,'2026-08-03 15:08:33','2026-08-03 15:08:33'),(2084174840756998146,2084174840643756033,2084174840186560514,'PAY20260803000003',99.00,99,3,'2026-08-03 15:09:39',0,'2026-08-03 15:09:39','2026-08-03 15:09:39'),(2084212479631618049,2084212478574653441,2084212477404413953,'MOCK_PAY_1785749952596',198.00,1,1,'2026-08-03 17:39:13',0,'2026-08-03 17:39:12','2026-08-03 17:39:12'),(2084464494899134465,999,55555,'PAY20260804000003',99.00,1,0,NULL,0,'2026-08-04 10:20:38','2026-08-04 10:20:38'),(2084464571621343233,2084463160384868354,66666,'PAY20260804000004',99.00,1,0,NULL,0,'2026-08-04 10:20:56','2026-08-04 10:20:56'),(2084468840021958658,88888,77777,'PAY20260804000005',199.00,99,1,'2026-08-04 10:37:54',0,'2026-08-04 10:37:54','2026-08-04 10:37:54'),(2084481455066501121,2084481454475104257,2084481453887877122,'MOCK_PAY_1785814081336',198.00,1,1,'2026-08-04 11:28:01',0,'2026-08-04 11:28:01','2026-08-04 11:28:01'),(2084481541838262273,2084481541477552129,2084481541045514241,'MOCK_PAY_1785814102025',198.00,1,1,'2026-08-04 11:28:22',0,'2026-08-04 11:28:22','2026-08-04 11:28:22'),(2084482322528260097,2084482322142384130,2084482321718734850,'MOCK_PAY_1785814288156',198.00,1,1,'2026-08-04 11:31:28',0,'2026-08-04 11:31:28','2026-08-04 11:31:28'),(2084482431932485633,2084482431609524225,2084482431185874946,'MOCK_PAY_1785814314240',198.00,1,1,'2026-08-04 11:31:54',0,'2026-08-04 11:31:54','2026-08-04 11:31:54'),(2084482909865037826,2084482909516910593,2084482909093261313,'MOCK_PAY_1785814428188',198.00,1,1,'2026-08-04 11:33:48',0,'2026-08-04 11:33:48','2026-08-04 11:33:48'),(2084483280146583554,2084483279827816449,2084483279391584258,'MOCK_PAY_1785814516470',198.00,1,1,'2026-08-04 11:35:16',0,'2026-08-04 11:35:16','2026-08-04 11:35:16'),(2084483584309121026,2084483583981965313,2084483583558316033,'MOCK_PAY_1785814588988',198.00,1,1,'2026-08-04 11:36:29',0,'2026-08-04 11:36:28','2026-08-04 11:36:28'),(2085588669038608385,2085588519922712577,10001,'MOCK_PAY_1786078061719',59.80,99,1,'2026-08-07 12:47:42',0,'2026-08-07 12:47:41','2026-08-07 12:47:41'),(2085590381883293697,2085590374643924993,10001,'MOCK_PAY_1786078470094',29.90,99,1,'2026-08-07 12:54:30',0,'2026-08-07 12:54:30','2026-08-07 12:54:30'),(2085631830473670658,2085631829903245313,10001,'MOCK_PAY_1786088352206',29.90,99,1,'2026-08-07 15:39:12',0,'2026-08-07 15:39:12','2026-08-07 15:39:12'),(2085631972685742082,2085631963915452418,10001,'MOCK_PAY_1786088386113',29.90,99,1,'2026-08-07 15:39:46',0,'2026-08-07 15:39:46','2026-08-07 15:39:46'),(2085634666351599617,2085632792714117122,10001,'PAY20260807000001',29.90,1,1,'2026-08-07 15:55:29',0,'2026-08-07 15:50:28','2026-08-07 15:55:29'),(2085639263115833345,2085638860609470466,10001,'PAY20260807000002',29.90,1,0,NULL,0,'2026-08-07 16:08:44','2026-08-07 16:08:44'),(2085642544286298114,2085642441198702594,10001,'PAY20260807000003',29.90,1,0,NULL,0,'2026-08-07 16:21:47','2026-08-07 16:21:47'),(2085643065713782785,2085643051075674114,10001,'PAY20260807000004',29.90,1,1,'2026-08-07 16:24:40',0,'2026-08-07 16:23:51','2026-08-07 16:24:40'),(2085646969713225729,2085646961035223041,10001,'PAY20260807000005',29.90,1,1,'2026-08-07 16:39:21',0,'2026-08-07 16:39:22','2026-08-07 16:39:21'),(2086001096205082625,2086000934497923073,2085982901507301378,'PAY20260808000001',198.00,99,1,'2026-08-08 16:06:32',0,'2026-08-08 16:06:32','2026-08-08 16:06:32');
/*!40000 ALTER TABLE `t_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_refund`
--

DROP TABLE IF EXISTS `t_refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `t_refund` (
  `id` bigint NOT NULL COMMENT 'é€€æ¬¾å•ID',
  `payment_id` bigint NOT NULL COMMENT 'å…³è”æ”¯ä»˜å•ID',
  `order_id` bigint NOT NULL COMMENT 'è®¢å•ID',
  `user_id` bigint NOT NULL COMMENT 'ç”¨æˆ·ID',
  `refund_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'é€€æ¬¾å•å·',
  `refund_amount` decimal(10,2) NOT NULL COMMENT 'é€€æ¬¾é‡‘é¢',
  `reason` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'é€€æ¬¾åŽŸå› ',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0-é€€æ¬¾ä¸­ 1-é€€æ¬¾æˆåŠŸ 2-é€€æ¬¾å¤±è´¥ 3-é€€æ¬¾å…³é—­',
  `refund_type` tinyint NOT NULL DEFAULT '1' COMMENT 'é€€æ¬¾ç±»åž‹ï¼š1-ä»…é€€æ¬¾ 2-é€€è´§é€€æ¬¾',
  `refund_channel` tinyint NOT NULL DEFAULT '1' COMMENT 'é€€æ¬¾æ¸ é“ï¼š1-åŽŸè·¯é€€å›ž 2-é€€åˆ°ä½™é¢',
  `success_at` datetime DEFAULT NULL COMMENT 'é€€æ¬¾æˆåŠŸæ—¶é—´',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT 'é€»è¾‘åˆ é™¤',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_refund_no` (`refund_no`),
  KEY `idx_payment_id` (`payment_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='é€€æ¬¾å•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_refund`
--

LOCK TABLES `t_refund` WRITE;
/*!40000 ALTER TABLE `t_refund` DISABLE KEYS */;
INSERT INTO `t_refund` VALUES (2076182014253363202,2076175588143427586,2076175587065503746,10001,'REFUND20260712000001',99.00,'测试退款',1,1,1,'2026-07-12 13:49:00',0,'2026-07-12 13:49:00','2026-07-12 13:49:00'),(2082371808490754049,2082367778142085121,2082367690804072449,10001,'REFUND20260729000001',99.00,'测试退款',1,1,1,'2026-07-29 15:46:14',0,'2026-07-29 15:45:02','2026-07-29 15:46:14'),(2084174562448150529,2084174561642844161,2084174560141287426,2084174559629565954,'REFUND20260803000001',99.00,'测试退款',1,1,1,'2026-08-03 15:08:32',0,'2026-08-03 15:08:32','2026-08-03 15:08:32'),(2084174841029627905,2084174840756998146,2084174840643756033,2084174840186560514,'REFUND20260803000002',99.00,'测试退款',1,1,1,'2026-08-03 15:09:39',0,'2026-08-03 15:09:39','2026-08-03 15:09:39'),(2085635929474625538,2085634666351599617,2085632792714117122,10001,'REFUND20260807000001',29.90,'refund test',0,1,1,NULL,0,'2026-08-07 15:55:29','2026-08-07 15:55:29'),(2085643273466048514,2085643065713782785,2085643051075674114,10001,'REFUND20260807000002',29.90,'refund test',0,1,1,NULL,0,'2026-08-07 16:24:40','2026-08-07 16:24:40'),(2085646978441572354,2085646969713225729,2085646961035223041,10001,'REFUND20260807000003',29.90,'retest',0,1,1,NULL,0,'2026-08-07 16:39:24','2026-08-07 16:39:24');
/*!40000 ALTER TABLE `t_refund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'my_xhs_payment'
--

--
-- Dumping routines for database 'my_xhs_payment'
--
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-08 21:54:33
